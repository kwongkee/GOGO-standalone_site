// order.js
const app = getApp();
const u = require('../../utils/util.js');

Page({
  data: {
    orderInfos:[],
    is_seller: 0,
    is_show_online_pay:0, //不显示在线支付
    order_id: 0,
    orderData: null,           // 订单数据
    orderItems: [],           // 商品列表
    totalPrice: 0,            // 总价
    totalQuantity: 0,         // 总数量

    activeMethod: 'scan_phone',     // 当前选择的支付方式
    showScanModal: false,     // 显示扫码支付弹窗
    showOnlineModal: false,   // 显示在线支付弹窗
    showResultModal: false,   // 显示结果弹窗
    showPhoneScanModal: false,      // 新增：手机扫描收款码弹窗
    
    paymentSuccess: false,    // 支付是否成功
    resultMessage: '',        // 结果信息
    paymentTime: '',          // 支付时间
    
    ctx: null,                // canvas上下文
    qrCodeTimer: null,        // 二维码轮询定时器

    isScanning: false,           // 是否正在扫码
    scanErrorCount: 0,          // 扫码错误次数
    scanTimer: null,            // 扫码相关定时器
  },

  onLoad(options) {
    var orderId = options.orderId || wx.getStorageSync('currentOrderId');
    if (options.scene) {
      // 解码scene参数（微信会对scene进行URL编码）
      const scene = decodeURIComponent(options.scene);
      console.log('解码后的scene:', scene);

      if (scene.includes('orderId=')) {
        // 方法1: 使用正则表达式提取
        const match = scene.match(/orderId=(\d+)/);
        if (match && match[1]) {
            orderId = match[1];
        }
      }
    }
    var is_seller = options.is_seller ? options.is_seller : 0;
    
    this.loadOrderData(orderId);
    this.setData({
      order_id: orderId,
      is_seller: is_seller
    });
    console.log('订单ID',orderId);
    // 初始化canvas上下文
    this.initCanvas();
  },

  // 隐藏手机扫描收款码弹窗
  hidePhoneScanModal() {
    this.setData({ showPhoneScanModal: false });
  },

  //确认手机扫描收款码
  confirmPhoneScan(){
    // wx.showToast({
    //   title: '确认支付成功',
    //   icon: 'none',
    //   duration: 2000
    // });
    
    // 2秒后允许重新扫码
    // setTimeout(() => {
      this.submitScanPayment();
    // }, 2000);
  },

  //选择扫码方式支付
  scanMethod(e){
    let t = this;
    let type = e.currentTarget.dataset.type;

    if(type=='scan_phone'){
      t.setData({
        activeMethod: 'scan_phone'
      });
    }else{
      t.setData({
        activeMethod: 'scan_online'
      });
    }

    //检测是否已支付
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'check_paid','id':t.data.order_id}).then(res => {
      if(res.data.is_paid==0){
        //未支付
        if(type=='scan_phone'){
          t.setData({
            showPhoneScanModal:true,
            activeMethod: 'scan_phone'
          });
        }else{
          t.setData({
            showPhoneScanModal:false,
            activeMethod: 'scan_online'
          });
    
          t.handleScanPayment();
        }

        t.requestSubscribe();
      }
      else{
        wx.showToast({
          title: '订单已支付',
          icon: 'none'
        });
      }
    });
  },

  //请求订阅
  requestSubscribe() {
    const tmplIds = [
      'iicuy2l4iE94TS6AbdmQzARSz8og-Le7Ns5WTpMIDzA',  // 订单取消
      'J6G1aaydThPCF7QwfhilwaEkeru-5vvA12RmEK1sJXc',   // 接受订单
      '1Ep-NilkEGx-VA9taJ2qDtJPoFHkd9sYkPJlK89WtXU'    // 发货通知
    ];

    wx.requestSubscribeMessage({
      tmplIds: tmplIds,
      success: (res) => {
        console.log('订阅结果:', res);
        
        // 1. 保存本地记录
        wx.setStorageSync('hasRequestedSubscribe', true);
        wx.setStorageSync('lastSubscribeTime', Date.now());
        
        // 2. 解析订阅结果并更新页面状态
        // this.handleSubscribeResult(res, tmplIds);
        
        // 3. 根据结果给用户反馈
        // this.showSubscribeFeedback(res);
        
        // 4. 发送到后端记录
        // this.sendSubscribeToServer(res);
      },
      fail: (err) => {
        console.error('订阅失败:', err);
        
        // 详细错误处理
        let errorMsg = '订阅失败';
        if (err.errCode === 20004) {
          errorMsg = '用户拒绝授权';
        } else if (err.errCode === 10001) {
          errorMsg = '网络异常，请稍后重试';
        }
        
        wx.showToast({
          title: errorMsg,
          icon: 'none',
          duration: 2000
        });
        
        // 记录失败时间，避免频繁请求
        wx.setStorageSync('subscribeFailTime', Date.now());
      }
    });
  },

  onShow() {
    let t = this;
    //判断有无登录，无登录则登录
    t.is_login();

    // 页面显示时重新计算价格
    t.calculateTotal();

    // 检查是否需要执行支付
    if (wx.getStorageSync('shouldExecutePayment')) {
      const scanResult = wx.getStorageSync('scanResultForPayment');
      if (scanResult) {
        this.submitScanPayment();
      }
      
      // 清除标记
      wx.removeStorageSync('shouldExecutePayment');
      wx.removeStorageSync('scanResultForPayment');
    }
  },

  // 初始化canvas
  initCanvas() {
    const ctx = wx.createCanvasContext('qrcodeCanvas', this);
    this.setData({ ctx });
  },

  // 加载订单数据
  loadOrderData(orderId) {
    let t = this;
    if (!orderId) {
      wx.showToast({
        title: '订单不存在',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }
    
    // 显示加载中
    wx.showLoading({
      title: '加载中...',
    });
    
    // 从接口获取订单数据
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_cart_info','cart_id':orderId}).then(res => {
      console.log(res);
      t.setData({
        //activeMethod: res.data.is_show_online_pay==0?'scan':'online',
        is_show_online_pay: res.data.is_show_online_pay,
        orderItems: res.data.orderItems,
        orderInfos: res.data.orderInfos
      }, () => {
        wx.hideLoading();
        t.calculateTotal();
      });
    });
  },

  // 计算总价和总数
  calculateTotal() {
    let t = this;
    let totalQuantity = 0;
    let totalPrice = 0;
    wx.showLoading({
      title: '更新中',
    })
    // 根据数量决定价格（创建所有请求的 Promise 数组）
    const promises = t.data.orderItems.map((item, index) => {
      return u.post(app.globalData.url + 'api/miniprogram/index', {
        'method': 'get_quantity_price',
        'id': item.id,
        'quantity': item.quantity,
        'spec_id': item.specifications[item.selectedSpecIndex].id
      }).then(res => {
        if (res.data.code == 0) {
          // 返回修改后的数据和索引
          return { index, data: res.data.price };
        }
        return { index, data: null };
      });
    });

    // 等待所有请求完成
    Promise.all(promises).then(results => {
      // 创建 orderItems 的深拷贝
      const newOrderItems = [...t.data.orderItems];
      
      results.forEach(result => {
        if (result.data) {
          // 根据索引更新对应的 item
          // 假设接口返回的数据中有 price, total 等字段
          newOrderItems[result.index]['price'] = result.data;
        }
      });
      
      // 一次性更新数据
      t.setData({
        orderItems: newOrderItems
      });

      newOrderItems.forEach(item => {
        totalQuantity = parseInt(totalQuantity) + parseInt(item.quantity);
        totalPrice += (item.price || 0) * (item.quantity || 0);
      });

      t.setData({
        totalQuantity,
        totalPrice: totalPrice.toFixed(2)
      });
      wx.hideLoading();
    });
  },

  // 增加数量
  increaseQuantity(e) {
    const index = e.currentTarget.dataset.index;
    let orderItems = this.data.orderItems;
    const max = e.currentTarget.dataset.max;
    
    if (orderItems[index]) {
      orderItems[index].quantity = parseInt(orderItems[index].quantity) + 1;
      if(orderItems[index].quantity > max){
        orderItems[index].quantity = max;
      }
      this.setData({ orderItems }, () => {
        this.calculateTotal();
        this.updateOrderQuantity(index, orderItems[index].quantity);
      });
    }
  },

  // 减少数量
  decreaseQuantity(e) {
    const index = e.currentTarget.dataset.index;
    let orderItems = this.data.orderItems;
    
    if (orderItems[index] && orderItems[index].quantity > 1) {
      orderItems[index].quantity -= 1;
      this.setData({ orderItems }, () => {
        this.calculateTotal();
        this.updateOrderQuantity(index, orderItems[index].quantity);
      });
    }
  },

  // 输入数量
  onQuantityInput(e) {
    const index = e.currentTarget.dataset.index;
    var value = parseInt(e.detail.value) || 1;
    const max = parseInt(e.currentTarget.dataset.max);

    if (value < 1) return;

    if (value > max){
      value = max;
    }

    let orderItems = this.data.orderItems;
    if (orderItems[index]) {
      orderItems[index].quantity = value;
      this.setData({ orderItems }, () => {
        this.calculateTotal();
        this.updateOrderQuantity(index, value);
      });
    }
  },

  // 更新订单数量到后端
  updateOrderQuantity(index, quantity) {
    if (!this.data.order_id) return;
    
    const item = this.data.orderItems[index];
    if (!item) return;
    
    // 调用接口更新数量
    u.post(app.globalData.url + 'api/miniprogram/index', {
      method: 'update_order_quantity',
      order_id: this.data.order_id,
      goods_id: item.id,
      spec_id: item.specifications[item.selectedSpecIndex].id,
      quantity: quantity
    }).then(res => {
      if (res.code !== 200) {
        wx.showToast({
          title: res.msg || '更新失败',
          icon: 'none'
        });
      }
    });
  },

  // 选择支付方式
  selectPaymentMethod(e) {
    const method = e.currentTarget.dataset.method;
    this.setData({ activeMethod: method });
    this.handlePayment();
  },

  // 处理支付
  handlePayment() {
    let t = this;
    if (t.data.totalQuantity === 0) {
      wx.showToast({
        title: '请选择商品',
        icon: 'none'
      });
      return;
    }

    //判断有无登录，无登录则登录
    t.is_login();
    
    if(wx.getStorageSync('sns_openid')!=''){
      if (t.data.activeMethod === 'scan') {
        // 直接跳转识别公众号跳转支付
        // t.handleScanPayment();
      } else if (t.data.activeMethod === 'online') {
        // 在线支付
        t.showOnlineModal();
      } else if (t.data.activeMethod === 'cash') {
        // 现金支付
        t.handleCashPayment();
      }
    }
  },

  // 处理订购码
  handleCode (){
    let t = this;

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'generate_other_code','id':t.data.order_id}).then(res => {
      if(res.data.code == 0){
        // 预览图片
        wx.previewImage({
          urls: [res.data.img], // 需要预览的图片链接数组
          current: res.data.img, // 当前显示图片的链接
          success: () => console.log('预览成功'),
          fail: (err) => console.log('预览失败', err)
        });
      }
    });
  },

  // 显示扫码支付弹窗
  // showScanModal() {
  //   this.setData({ showScanModal: true });
  // },

  // 隐藏扫码支付弹窗
  hideScanModal() {
    this.setData({ showScanModal: false });
  },

  // ==================== 新增扫码支付核心函数 ====================
  // 扫码支付（改成：直接跳转公众号支付）
  handleScanPayment() {
    let t = this;

    // 检查订单信息
    if (!t.data.order_id) {
      wx.showToast({
        title: '订单信息异常',
        icon: 'none'
      });
      return;
    }

    // 检查是否正在扫码中
    // if (this.data.isScanning) {
    //   return;
    // }

    wx.setStorageSync('shouldExecutePayment', true);
    wx.setStorageSync('scanResultForPayment', true);
    let tz_url = `https://www.gogo198.net/?s=index/of_qrcode`;
    wx.navigateTo({
      url: `/pages/agreement/index?url=${encodeURIComponent(tz_url)}`
    });
    return;

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'jiami_data','url':scanResult}).then(res => {
      if(res.data.code==0){
        let sr = res.data.data;
        
        // ${encodeURIComponent(scanResult)}
        let tz_url = `https://www.gogo198.net/?s=index/of_qrcode&url=${sr}`;
        // console.log(tz_url ,123);
        
        // 这是用于打开收钱吧的专用码
        wx.navigateTo({
          url: `/pages/agreement/index?url=${encodeURIComponent(tz_url)}`
        });
        return;
      }
    });

    // 设置扫码状态
    // this.setData({ isScanning: true });

    // 显示扫码引导
    // wx.showModal({
    //   title: '扫码支付',
    //   content: '请扫描店铺收款码',
    //   confirmText: '开始扫码',
    //   cancelText: '取消',
    //   success: (res) => {
    //     if (res.confirm) {
    //       // 开始扫码流程
    //       this.startScanCode();
    //     } else {
    //       this.setData({ isScanning: false });
    //     }
    //   },
    //   fail: () => {
    //     this.setData({ isScanning: false });
    //   }
    // });
  },

  //现金支付
  handleCashPayment(){
    let t = this;
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'submit_scan_payment','id':t.data.order_id,'uid':wx.getStorageSync('uid'),'pay_type': 'cash'}).then(res => {
      if(res.data.code == 0){
        t.requestSubscribe();

        setTimeout(() => {
          wx.navigateTo({
            url: '/pages/orderfood/order_list?tab=pending',
          })
        }, 2000);
      }
    });
  },

  // 启动扫码（废弃）
  startScanCode() {
    let t = this;
    // 调用微信扫一扫API
    wx.scanCode({
      onlyFromCamera: true,      // 只允许从相机扫码
      scanType: ['barCode', 'qrCode'], // 支持条形码和二维码
      success: async (res) => {
        const scanResult = res.result;
        console.log('扫码结果:', scanResult);
        
        // 1. 判断是否为“收钱吧启动码”
        if (scanResult.includes('qr.shouqianba.com')) {
          // 存储标记和扫码结果
          wx.setStorageSync('shouldExecutePayment', true);
          wx.setStorageSync('scanResultForPayment', scanResult);
          
          if(scanResult){
            u.post(app.globalData.url+'api/miniprogram/index',{'method':'jiami_data','url':scanResult}).then(res => {
              if(res.data.code==0){
                let sr = res.data.data;
                
                // ${encodeURIComponent(scanResult)}
                let tz_url = `https://www.gogo198.net/?s=index/of_qrcode&url=${sr}`;
                // console.log(tz_url ,123);
                
                // 这是用于打开收钱吧的专用码
                wx.navigateTo({
                  url: `/pages/agreement/index?url=${encodeURIComponent(tz_url)}`
                });
                return;
              }
            });
          }
        }
        
        //2.立即支付
        // await this.submitScanPayment();
      },
      fail: (err) => {
        let errMsg = '扫码失败';
        if (err.errMsg.includes('cancel')) {
          errMsg = '已取消扫码';
        } else if (err.errMsg.includes('permission')) {
          errMsg = '请授予相机权限';
        }
        this.handleScanError(errMsg);
      },
      complete: () => {
        // 扫码界面关闭后，重置状态
        setTimeout(() => {
          this.setData({ isScanning: false });
        }, 500);
      }
    });
  },

  // 提交扫码支付
  async submitScanPayment() {
    let t = this;
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'submit_scan_payment','id':t.data.order_id,'uid':wx.getStorageSync('uid'),'pay_type': 'scan_code'}).then(res => {
      if(res.data.code == 0){
        setTimeout(() => {
          wx.navigateTo({
            url: '/pages/orderfood/order_list?tab=pending',
          })
        },2000);
      }
    });

    if(1>2){
      try {
        // 调用后端接口提交支付
        const result = await u.post(app.globalData.url + 'api/miniprogram/index', {
          method: 'submit_scan_payment',
          order_id: t.data.order_id,
          total_amount: t.data.totalPrice,
          uid: wx.getStorageSync('uid'),
          pay_type: 'scan_code'       // 扫码支付类型
        });
        console.log(result,'扫码支付结果....');
        wx.hideLoading();
  
        if (result.code === 200) {
          // 支付提交成功，开始轮询支付结果
          wx.showToast({
            title: '支付请求已提交',
            icon: 'success'
          });
          
          this.startScanPaymentPolling();
          
        } else {
          // 支付提交失败
          wx.showModal({
            title: '支付失败',
            content: result.msg || '支付请求提交失败，请重试',
            showCancel: false,
            success: () => {
              // 可以重新扫码
              setTimeout(() => {
                this.startScanCode();
              }, 1000);
            }
          });
        }
      } catch (error) {
        wx.hideLoading();
        this.handleScanError('网络异常，请重试');
      }
    }
  },

  // 启动扫码支付轮询（废弃）
  startScanPaymentPolling() {
    // 先清除之前的定时器
    if (this.data.scanTimer) {
      clearInterval(this.data.scanTimer);
    }

    let pollCount = 0;
    const maxPollCount = 20; // 最多轮询20次（约60秒）
    
    const timer = setInterval(async () => {
      pollCount++;
      
      if (pollCount >= maxPollCount) {
        clearInterval(timer);
        this.setData({ scanTimer: null });
        
        // 轮询超时
        this.handlePaymentTimeout();
        return;
      }

      try {
        const result = await u.post(app.globalData.url + 'api/miniprogram/index', {
          method: 'check_scan_payment',
          order_id: this.data.order_id
        });

        if (result.code === 200) {
          const paymentStatus = result.data.status;
          
          if (paymentStatus === 'paid') {
            // 支付成功
            clearInterval(timer);
            this.setData({ scanTimer: null });
            this.handlePaymentSuccess();
            
          } else if (paymentStatus === 'failed') {
            // 支付失败
            clearInterval(timer);
            this.setData({ scanTimer: null });
            
            wx.showModal({
              title: '支付失败',
              content: result.data.msg || '支付失败，请重试',
              success: (res) => {
                if (res.confirm) {
                  this.handleScanPayment(); // 重新扫码
                }
              }
            });
          }
          // 其他状态（如processing）继续轮询
        }
      } catch (error) {
        console.error('轮询失败:', error);
      }
    }, 3000); // 每3秒查询一次

    this.setData({ scanTimer: timer });
  },

  // 处理扫码错误（废弃）
  handleScanError(message) {
    this.setData({
      scanErrorCount: this.data.scanErrorCount + 1
    });

    // 如果连续错误3次，建议切换支付方式
    if (this.data.scanErrorCount >= 3) {
      wx.showModal({
        title: '扫码遇到问题',
        content: '扫码多次失败，建议切换在线支付方式',
        confirmText: '在线支付',
        cancelText: '继续扫码',
        success: (res) => {
          if (res.confirm) {
            this.setData({ activeMethod: 'online' });
            this.showOnlineModal();
          } else {
            this.startScanCode();
          }
        }
      });
      this.setData({ scanErrorCount: 0 });
    } else {
      wx.showToast({
        title: message,
        icon: 'none',
        duration: 2000
      });
      
      // 2秒后允许重新扫码
      setTimeout(() => {
        if (this.data.isScanning) {
          this.startScanCode();
        }
      }, 2000);
    }
  },

  // 处理支付超时（废弃）
  handlePaymentTimeout() {
    wx.showModal({
      title: '支付超时',
      content: '支付确认超时，请询问顾客是否支付成功？',
      confirmText: '支付成功',
      cancelText: '重新支付',
      success: async (res) => {
        if (res.confirm) {
          // 手动确认支付成功
          try {
            const result = await u.post(app.globalData.url + 'api/miniprogram/index', {
              method: 'confirm_payment_manually',
              order_id: this.data.order_id
            });
            
            if (result.code === 200) {
              this.handlePaymentSuccess();
            } else {
              wx.showToast({
                title: '确认失败，请稍后重试',
                icon: 'none'
              });
            }
          } catch (error) {
            wx.showToast({
              title: '网络异常',
              icon: 'none'
            });
          }
        } else {
          // 重新扫码支付
          this.handleScanPayment();
        }
      }
    });
  },

  // 清理定时器（在onUnload中补充）
  onUnload() {
    // 清理原来的定时器
    if (this.data.qrCodeTimer) {
      clearInterval(this.data.qrCodeTimer);
    }
    
    // 清理扫码定时器
    if (this.data.scanTimer) {
      clearInterval(this.data.scanTimer);
    }

    // 清除标记
    wx.removeStorageSync('shouldExecutePayment');
    wx.removeStorageSync('scanResultForPayment');
  },

  //检测用户有无登录
  is_login(){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/orderfood/order?orderId='+t.data.order_id);

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  // 显示在线支付弹窗
  showOnlineModal() {
    // this.setData({ showOnlineModal: true });
    // 开始轮询支付状态
    // this.startPaymentPolling();
    let t = this;

    wx.showLoading({
      title: '支付中...',
      mask: true
    });
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'createWechatPaymentOrder','cart_id':t.data.order_id,'uid':wx.getStorageSync('uid')}).then(res => {
      try {
        if (res.data.code === 0) {
          const paymentParams = res.data.data;
          
          // 调用微信支付
          wx.requestPayment({
            ...paymentParams,
            success: (res) => {
              wx.hideLoading();
              console.log('支付成功', res);
              t.requestSubscribe();
              t.handlePaymentSuccess();
            },
            fail: (err) => {
              wx.hideLoading();
              console.error('支付失败', err);
              
              if (err.errMsg.includes('cancel')) {
                wx.showToast({
                  title: '支付已取消',
                  icon: 'none'
                });
              } else {
                wx.showToast({
                  title: '支付失败，请重试',
                  icon: 'none'
                });
              }
            }
          });
        } else {
          wx.hideLoading();
          wx.showToast({
            title: result.msg || '支付订单创建失败',
            icon: 'none'
          });
        }
      } catch (error) {
        wx.hideLoading();
        wx.showToast({
          title: '网络异常，请重试',
          icon: 'none'
        });
      }
    });
  },

  // 隐藏在线支付弹窗
  hideOnlineModal() {
    this.setData({ showOnlineModal: false });
    // 停止轮询
    if (this.data.qrCodeTimer) {
      clearInterval(this.data.qrCodeTimer);
      this.setData({ qrCodeTimer: null });
    }
  },

  // 处理支付成功
  handlePaymentSuccess() {
    // 停止轮询
    if (this.data.qrCodeTimer) {
      clearInterval(this.data.qrCodeTimer);
      this.setData({ qrCodeTimer: null });
    }
    
    // 更新支付状态到后端
    this.updatePaymentStatus();
    
    // 获取当前时间
    const now = new Date();
    const paymentTime = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()} ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
    
    // 显示成功结果
    this.setData({
      paymentSuccess: true,
      resultMessage: '支付成功，订单已确认！',
      paymentTime: paymentTime,
      showScanModal: false,
      showOnlineModal: false,
      showResultModal: true
    });
    
    // 清除本地订单数据
    wx.removeStorageSync('orderItems');
    wx.removeStorageSync('currentOrderId');
    wx.removeStorageSync('orderData');
  },

  // 更新支付状态到后端
  updatePaymentStatus() {
    if (!this.data.order_id) return;
    
    u.post(app.globalData.url + 'api/miniprogram/index', {
      method: 'update_payment_status',
      order_id: this.data.order_id,
      status: 'paid',
      payment_method: this.data.activeMethod
    }).then(res => {
      if (res.code !== 0) {
        console.error('更新支付状态失败:', res.msg);
      }
    });
  },

  // 隐藏结果弹窗
  hideResultModal() {
    this.setData({ showResultModal: false });
  },

  //支付成功后的跳转
  handleResultAction(e){
    let t = this;
    let action = e.currentTarget.dataset.action;
    
    if(action=='back'){
      wx.navigateTo({
        url: '/pages/orderfood/index',
      })
    }
    else if(action=='detail'){
      wx.navigateTo({
        url: '/pages/orderfood/order_list?tab=pending',
      })
    }
  },
});