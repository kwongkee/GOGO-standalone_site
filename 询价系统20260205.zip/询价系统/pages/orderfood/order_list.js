// pages/orderList/orderList.js
const app = getApp();
const { formatTime, formatCurrency } = require('../../utils/util.js');
var u = require('../../utils/util.js');

Page({
  data: {
    // 状态选项卡
    statusTabs: [
      { id: 'unpaid', name: '待支付', count: 0 },
      // { id: 'paid', name: '已支付', count: 0 },
      { id: 'pending', name: '待接单', count: 0 },
      { id: 'delivering', name: '待交付', count: 0 },
      { id: 'completed', name: '已完成', count: 0 },
      { id: 'returning', name: '待退货', count: 0 },
      { id: 'returned', name: '已退货', count: 0 },
      { id: 'canceled', name: '已取消', count: 0 }
    ],
    activeTab: 0, // 默认待支付
    scrollTop: 0,

    // 订单列表数据
    orderList: [],
    loading: false,
    refreshing: false,
    page: 1,
    pageSize: 10,
    hasMore: true,
    
    // 筛选相关
    showFilter: false,
    timeFilter: 'all',
    priceFilter: 'all',
    sortBy: 'time',
    
    // 定时器
    countdownTimers: []
  },

  onLoad(options) {
    // 页面显示时检查登录状态
    this.checkLogin();

    // 可以从参数中指定初始tab
    if (options.tab) {
      const tabIndex = this.data.statusTabs.findIndex(tab => tab.id === options.tab);
      if (tabIndex !== -1) {
        this.setData({ activeTab: tabIndex });
      }
    }
    
    // 加载订单数据
    this.loadOrders();
    
    // 启动倒计时更新
    this.startCountdownUpdate();
  },

  onShow() {
    
    // 更新订单状态计数
    this.updateOrderCounts();
    
    // 重新开始倒计时
    this.startCountdownUpdate();
  },

  onUnload() {
    // 清理定时器
    this.clearAllCountdowns();
  },

  onPullDownRefresh() {
    this.onRefresh();
  },

  // 检查登录状态
  checkLogin() {
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/orderfood/order_list');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  // 更新各状态订单数量
  updateOrderCounts() {
    let t = this;
    if(wx.getStorageSync('sns_openid')!=''){
      // 这里应该调用接口获取各状态订单数量
      let orderData = {method:'get_order_status_count',uid: wx.getStorageSync('uid')};
      //请求当前状态下的订单信息
      u.post(app.globalData.url + 'api/miniprogram/index', orderData).then(res => {
        if (res.data.code === 0) {
          const counts = res.data.list;
          const statusTabs = this.data.statusTabs.map((tab, index) => ({
            ...tab,
            count: counts[index]
          }));
          
          this.setData({ statusTabs });
        } else {
          wx.showToast({
            title: res.data.msg || '提交失败',
            icon: 'none'
          });
        }
      }).catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误',
          icon: 'none'
        });
      });
    }
  },

  // 加载订单数据
  loadOrders(isRefresh = false) {
    let t = this;

    if (t.data.loading && !isRefresh) return;
    const currentStatus = t.data.statusTabs[t.data.activeTab].id;
    t.setData({ loading: true });
    
    // const mockOrders = t.generateMockOrders(currentStatus, t.data.page);
    let orderData = {status:currentStatus,page:t.data.page,method:'get_order_list',uid: wx.getStorageSync('uid')};
    //请求当前状态下的订单信息
    u.post(app.globalData.url + 'api/miniprogram/index', orderData).then(res => {
      if (res.data.code === 0) {
        t.setData({
          orderList: res.data.list,
          page: 1,
          hasMore: false,
          loading: false,
          refreshing: false,
        });
        
        wx.stopPullDownRefresh();
      } else {
        wx.showToast({
          title: res.data.msg || '提交失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '网络错误',
        icon: 'none'
      });
    });

    // if (isRefresh) {
      // this.setData({
      //   orderList: mockOrders,
      //   page: 1,
      //   hasMore: true,
      //   loading: false,
      //   refreshing: false
      // });
      
      // wx.stopPullDownRefresh();
    // } else {
    //   this.setData({
    //     orderList: this.data.orderList.concat(mockOrders),
    //     page: this.data.page + 1,
    //     hasMore: mockOrders.length >= this.data.pageSize,
    //     loading: false
    //   });
    // }
      
    // 更新倒计时
    this.updateCountdowns();
  },

  // 生成模拟订单数据
  generateMockOrders(status, page) {
    const statusTextMap = {
      unpaid: '待支付',
      paid: '已支付',
      pending: '待接单',
      delivering: '待交付',
      completed: '已完成',
      returning: '待退货',
      returned: '已退货'
    };
    
    const mockOrders = [];
    const count = page === 1 ? 5 : 3; // 模拟分页
    
    for (let i = 0; i < count; i++) {
      const orderNo = `DD${Date.now()}${Math.floor(Math.random() * 10000)}`;
      const createTime = this.formatMockTime(page, i);
      const totalPrice = (Math.random() * 200 + 20).toFixed(2);
      
      // 生成商品列表
      const goodsCount = Math.floor(Math.random() * 3) + 1;
      const goodsList = [];
      let totalQuantity = 0;
      
      for (let j = 0; j < goodsCount; j++) {
        const quantity = Math.floor(Math.random() * 3) + 1;
        totalQuantity += quantity;
        
        goodsList.push({
          id: j + 1,
          name: ['经典汉堡套餐', '香辣鸡腿堡', '薯条大份', '可乐中杯', '冰淇淋'][j],
          image: `https://shop.gogo198.cn/collect_website/public/miniprogram/img/food${j + 1}.jpg`,
          price: (Math.random() * 40 + 10).toFixed(2),
          quantity: quantity,
          spec: j === 0 ? '套餐A' : null
        });
      }
      
      // 如果是待支付订单，添加倒计时
      let countdownTime = null;
      if (status === 'unpaid') {
        const minutes = 15 - ((page - 1) * count + i) * 2;
        countdownTime = `${Math.max(0, minutes)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`;
      }
      
      mockOrders.push({
        order_no: orderNo,
        create_time: createTime,
        status: status,
        status_text: statusTextMap[status],
        store_name: Math.random() > 0.5 ? '汉堡王（人民广场店）' : '肯德基（南京东路店）',
        goods_list: goodsList,
        total_quantity: totalQuantity,
        total_price: totalPrice,
        countdown_time: countdownTime
      });
    }
    
    return mockOrders;
  },

  // 格式化模拟时间
  formatMockTime(page, index) {
    const now = new Date();
    const date = new Date(now.getTime() - ((page - 1) * 10 + index) * 3600000);
    
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    return `${month}-${day} ${hours}:${minutes}`;
  },

  // 切换选项卡
  switchTab(e) {
    const index = e.currentTarget.dataset.index;
    
    if (this.data.activeTab !== index) {
      this.setData({
        activeTab: index,
        orderList: [],
        page: 1,
        hasMore: true
      }, () => {
        // 滚动到顶部
        this.scrollToTop();
        // 加载新数据
        this.loadOrders(true);
      });
    }
  },

  // 下拉刷新
  onRefresh() {
    this.setData({ refreshing: true,scrollTop:0 });
    this.loadOrders(true);
  },

  // 上拉加载更多
  loadMore() {
    if (!this.data.hasMore || this.data.loading) return;
    this.loadOrders();
  },

  // 滚动到顶部
  scrollToTop() {
    this.setData({scrollTop:0 });
    this.loadOrders(true);
    // wx.pageScrollTo({
    //   scrollTop: 0,
    //   duration: 300
    // });
  },

  // 显示筛选弹窗
  showFilterModal() {
    this.setData({ showFilter: true });
  },

  // 隐藏筛选弹窗
  hideFilterModal() {
    this.setData({ showFilter: false });
  },

  // 选择时间筛选
  selectTimeFilter(e) {
    this.setData({
      timeFilter: e.currentTarget.dataset.value
    });
  },

  // 选择价格筛选
  selectPriceFilter(e) {
    this.setData({
      priceFilter: e.currentTarget.dataset.value
    });
  },

  // 选择排序方式
  selectSort(e) {
    this.setData({
      sortBy: e.currentTarget.dataset.value
    });
  },

  // 重置筛选
  resetFilter() {
    this.setData({
      timeFilter: 'all',
      priceFilter: 'all',
      sortBy: 'time'
    });
  },

  // 应用筛选
  applyFilter() {
    this.hideFilterModal();
    this.onRefresh();
  },

  // 去下单
  goToIndex() {
    wx.navigateTo({
      url: '/pages/orderfood/index'
    });
  },

  //查看订单
  goToOrder(e){
    const order = e.currentTarget.dataset.order;
    
    wx.navigateTo({
      url: '/pages/orderfood/order?orderId='+order.cart_id
    });
  },

  // 去支付
  goToPay(e) {
    const order = e.currentTarget.dataset.order;
    
    wx.navigateTo({
      url: '/pages/orderfood/order?orderId='+order.cart_id
    });
  },

  // 取消订单
  cancelOrder(e) {
    const order = e.currentTarget.dataset.order;
    
    wx.showModal({
      title: '确认取消',
      content: `确定要取消订单 ${order.order_no} 吗？`,
      confirmColor: '#ff6b6b',
      success: (res) => {
        if (res.confirm) {
          // 调用取消订单接口
          this.cancelOrderRequest(order);
        }
      }
    });
  },

  // 取消订单请求
  cancelOrderRequest(order) {
    let t = this;
    wx.showLoading({ title: '处理中...' });
    
    // 模拟API调用
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'cancel_order','id':order.id,'uid':wx.getStorageSync('uid')}).then(res => {
      wx.hideLoading();

      // 更新本地数据
      const orderList = this.data.orderList.filter(item => item.order_no !== order.order_no);
      t.setData({ orderList });

      // 更新订单计数
      t.updateOrderCounts();
    });
  },

  // 联系商家
  contactStore(e) {
    const order = e.currentTarget.dataset.order;
    
    wx.makePhoneCall({
      phoneNumber: '400-123-4567',
      success: () => {
        console.log('拨打电话成功');
      }
    });
  },

  // 催单
  remindOrder(e) {
    wx.showToast({
      title: '已提醒商家加快处理',
      icon: 'success',
      duration: 2000
    });
  },

  // 确认送达
  confirmDelivery(e) {
    wx.showModal({
      title: '确认送达',
      content: '请确认您已收到商品？',
      success: (res) => {
        if (res.confirm) {
          this.updateOrderStatus(e.currentTarget.dataset.order, 'completed');
        }
      }
    });
  },

  // 再来一单
  reorder(e) {
    const order = e.currentTarget.dataset.order;
    
    wx.showLoading({ title: '加入购物车...' });
    
    setTimeout(() => {
      wx.hideLoading();
      wx.showToast({
        title: '商品已加入购物车',
        icon: 'success'
      });
      
      // 跳转到购物车
      setTimeout(() => {
        wx.switchTab({
          url: '/pages/cart/cart'
        });
      }, 1500);
    }, 1000);
  },

  // 去评价
  goToComment(e) {
    const order = e.currentTarget.dataset.order;
    wx.navigateTo({
      url: `/pages/comment/comment?orderId=${order.order_no}`
    });
  },

  // 联系客服
  contactService() {
    wx.navigateTo({
      url: '/pages/service/service'
    });
  },

  // 查看退货进度
  viewReturnDetail(e) {
    const order = e.currentTarget.dataset.order;
    wx.navigateTo({
      url: `/pages/returnDetail/returnDetail?orderId=${order.order_no}`
    });
  },

  // 重新申请退货
  applyReturnAgain(e) {
    const order = e.currentTarget.dataset.order;
    wx.navigateTo({
      url: `/pages/applyReturn/applyReturn?orderId=${order.order_no}`
    });
  },

  // 更新订单状态
  updateOrderStatus(order, newStatus) {
    wx.showLoading({ title: '处理中...' });
    
    setTimeout(() => {
      wx.hideLoading();
      
      // 更新本地数据
      const orderList = this.data.orderList.map(item => {
        if (item.order_no === order.order_no) {
          const statusTextMap = {
            unpaid: '待支付',
            paid: '已支付',
            pending: '待接单',
            delivering: '待交付',
            completed: '已完成',
            returning: '待退货',
            returned: '已退货'
          };
          
          return {
            ...item,
            status: newStatus,
            status_text: statusTextMap[newStatus]
          };
        }
        return item;
      });
      
      this.setData({ orderList }, () => {
        wx.showToast({
          title: '操作成功',
          icon: 'success'
        });
        
        // 更新订单计数
        this.updateOrderCounts();
      });
    }, 1000);
  },

  // 启动倒计时更新
  startCountdownUpdate() {
    // 清理之前的定时器
    this.clearAllCountdowns();
    
    // 每秒更新一次倒计时
    const timer = setInterval(() => {
      this.updateCountdowns();
    }, 1000);
    
    this.data.countdownTimers.push(timer);
  },

  // 更新所有订单的倒计时
  updateCountdowns() {
    const currentTab = this.data.statusTabs[this.data.activeTab];
    if (currentTab.id !== 'unpaid') return;
    
    const now = Date.now();
    let hasChanges = false;
    
    const orderList = this.data.orderList.map(order => {
      if (order.status === 'unpaid' && order.countdown_time) {
        const [minutes, seconds] = order.countdown_time.split(':').map(Number);
        const totalSeconds = minutes * 60 + seconds - 1;
        
        if (totalSeconds > 0) {
          const newMinutes = Math.floor(totalSeconds / 60);
          const newSeconds = totalSeconds % 60;
          
          hasChanges = true;
          return {
            ...order,
            countdown_time: `${newMinutes}:${newSeconds.toString().padStart(2, '0')}`
          };
        } else {
          // 倒计时结束，订单自动取消
          hasChanges = true;
          return {
            ...order,
            status: 'cancelled',
            status_text: '已取消'
          };
        }
      }
      return order;
    });
    
    if (hasChanges) {
      this.setData({ orderList });
    }
  },

  // 清理所有定时器
  clearAllCountdowns() {
    this.data.countdownTimers.forEach(timer => {
      clearInterval(timer);
    });
    this.data.countdownTimers = [];
  },

  // 分享功能
  onShareAppMessage() {
    return {
      title: '我的订单',
      path: '/pages/orderList/orderList'
    };
  }
});