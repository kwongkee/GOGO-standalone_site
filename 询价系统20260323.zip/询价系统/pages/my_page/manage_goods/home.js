var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    t.checkLogin();
  },
  // 检查登录状态
  checkLogin() {
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/manage_goods/home');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },
  go_add(){
    let t = this;
    t.checkLogin();

    wx.navigateTo({
      url: '/pages/my_page/manage_goods/save_info',
    });
  },
  go_manage(){
    let t = this;
    t.checkLogin();

    wx.navigateTo({
      url: '/pages/my_page/manage_goods/home3',
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})