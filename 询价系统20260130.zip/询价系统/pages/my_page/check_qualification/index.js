// pages/my_page/check_qualification/index.js
// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    campaign_id: 0,
    is_loading: 0,
    number: '',
    is_reject: 0,
    progressWidth: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    
    // 显示加载动画
    wx.showLoading({
      title: '检测资格中...',
      mask: true
    });

    // 检测资格
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'scan_check_qualification',
      'uid': wx.getStorageSync('uid'),
      'method2': 0
    }).then(res => {
      wx.hideLoading();
      if (res.data.code == 0) {
        t.setData({
          campaign_id: res.data.data.campaign_id
        })

        if (res.data.data.status == 2) {
          // 参与中
          t.setData({
            is_loading: 1
          })
          t.get_number();
        }
      } else {
        // API调用失败的处理
        wx.showToast({
          title: res.data.message || '检测失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '网络连接失败',
        icon: 'none'
      });
      console.error('API调用失败:', err);
    });
  },

  // 确定免费食
  sure_join(e) {
    let t = this;
    
    // 按钮点击反馈
    wx.showLoading({
      title: '提交中...',
      mask: true
    });
    
    // 检测资格
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'scan_check_qualification',
      'uid': wx.getStorageSync('uid'),
      'method2': 1,
      'campaign_id': t.data.campaign_id
    }).then(res => {
      wx.hideLoading();
      if (res.data.code == 0) {
        t.setData({
          is_loading: 1
        });
        
        // 显示成功提示
        wx.showToast({
          title: '参与成功',
          icon: 'success'
        });
        
        t.get_number();
      } else {
        wx.showToast({
          title: res.data.message || '参与失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '提交失败，请重试',
        icon: 'none'
      });
    });
  },

  // 获取取餐号
  get_number() {
    let t = this;
    
    // 开始进度条动画
    t.startProgressAnimation();

    var interval = setInterval(function() {
      u.post(app.globalData.url + 'api/miniprogram/index', {
        'method': 'scan_check_qualification',
        'uid': wx.getStorageSync('uid'),
        'method2': 2,
        'campaign_id': t.data.campaign_id
      }).then(res2 => {
        if (res2.data.code == 0) {
          if (res2.data.data.is_reject == 0) {
            // 已接受订单
            t.setData({
              number: res2.data.data.number,
              is_loading: 1,
              is_reject: 0
            })

            clearInterval(interval);
            t.stopProgressAnimation();
            
            // 播放成功音效（可选）
            wx.vibrateShort({
              type: 'light'
            });
            
            // 显示取餐码通知
            wx.showToast({
              title: '已获取取餐码',
              icon: 'success'
            });
          } else if (res2.data.data.is_reject == 1) {
            // 已拒绝订单
            t.setData({
              number: '',
              is_loading: 0,
              is_reject: 1
            })

            clearInterval(interval);
            t.stopProgressAnimation();
            
            // 显示拒绝通知
            wx.showModal({
              title: '订单被拒绝',
              content: '商家暂时无法为您提供服务',
              showCancel: false,
              confirmText: '我知道了'
            });
          }
        }
      }).catch(err => {
        console.error('获取取餐号失败:', err);
      });
    }, 1000);
  },

  // 开始进度条动画
  startProgressAnimation() {
    let t = this;
    let width = 0;
    
    const progressInterval = setInterval(() => {
      width += 2;
      if (width > 100) width = 0;
      
      t.setData({
        progressWidth: width
      });
    }, 50);
    
    // 保存interval ID，用于停止
    t.progressInterval = progressInterval;
  },

  // 停止进度条动画
  stopProgressAnimation() {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.setData({
        progressWidth: 100
      });
    }
  },

  // 重新尝试
  onRetry() {
    wx.showLoading({
      title: '重新检测中...',
      mask: true
    });
    
    setTimeout(() => {
      wx.hideLoading();
      this.onLoad();
    }, 1000);
  },

  // 返回首页
  onBack() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  },

  // 查看详细要求
  onCheckRequirements() {
    wx.showModal({
      title: '参与资格要求',
      content: '1. 完成实名认证\n2. 位于活动服务区域\n3. 首次参与本活动\n4. 活动时间内参与\n5. 每个用户限参与一次',
      showCancel: false,
      confirmText: '我知道了'
    });
  },

  // 联系客服
  onContactSupport() {
    wx.showActionSheet({
      itemList: ['在线客服', '拨打客服电话', '联系商家'],
      success: (res) => {
        switch(res.tapIndex) {
          case 0:
            // 在线客服
            wx.navigateTo({
              url: '/pages/customerService/index'
            });
            break;
          case 1:
            // 拨打客服电话
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 2:
            // 联系商家
            wx.navigateTo({
              url: '/pages/storeContact/index'
            });
            break;
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    // 清理定时器
    this.stopProgressAnimation();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // 清理定时器
    this.stopProgressAnimation();
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    // wx.showNavigationBarLoading();
    // this.onLoad();
    // setTimeout(() => {
    //   wx.hideNavigationBarLoading();
    //   wx.stopPullDownRefresh();
    // }, 1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    // return {
    //   title: '免费美食活动，快来参与吧！',
    //   path: '/pages/my_page/check_qualification/index'
    // };
  }
});