// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    currentIndex2: 0,
    currentIndex3: 0,
    imgList: [
      'https://dtc.gogo198.net/uploads/merch_file/goods_files/692022ffd216a.jpg',
      'https://img.alicdn.com/bao/uploaded/i2/2213637590456/O1CN01yjSE2n1FEtgbEqHtz_!!2213637590456.jpg'
      // 可以添加更多图片
    ],
    showNavigation: true,  // 是否显示导航按钮
    showIndicator: true,
    type1_info:[],
    type2_info:[],
    type3_info:[],
    type1_background:{'param1':'','param2':'','param3':''},
    type2_background:{'param1':'','param2':'','param3':''},
    type3_background:{'param1':'','param2':'','param3':''}
  },

  // 预约免费食 滑动时触发
  swiperChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },
  // 好食才付款 滑动时触发
  swiperChange2(e) {
    this.setData({
      currentIndex2: e.detail.current
    });
  },
  // 买一送一 滑动时触发
  swiperChange3(e) {
    this.setData({
      currentIndex3: e.detail.current
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    console.log(options);
    // 可以根据图片数量决定是否显示导航按钮
    if (this.data.imgList.length <= 1) {
      this.setData({
        showNavigation: false
      });
    }

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_campaign_list'}).then(res => {
      t.setData({
        type1_info:res.data.data.type1_info,
        type2_info:res.data.data.type2_info,
        type3_info:res.data.data.type3_info,
        type1_background:res.data.data.type1_background,
        type2_background:res.data.data.type2_background,
        type3_background:res.data.data.type3_background
      });
    });
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack();
  },

  //检测有无登录微信小程序
  goto_login: function(){
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  // 跳转到预约免费食页面
  navigateToReserve: function() {
    // this.goto_login();
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    wx.navigateTo({
      url: '/pages/my_page/reserve/index'
    })
  },

  //分享活动（废弃）
  navigateToShare(e){
    let t = this;
    let id = e.currentTarget.dataset.id;
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_campaign_list','campaign_id':id}).then(res => {
      
    });
  },

  //活动详情
  navigateToDetail(e){
    let t = this;
    
    wx.navigateTo({
      url: '/pages/my_page/campaign_detail/index?id='+e.currentTarget.dataset.id+"&type="+e.currentTarget.dataset.type,
    })
  },

  //参与活动
  join_activity(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/my_page/reserve/index?id='+e.currentTarget.dataset.id+"&type="+e.currentTarget.dataset.type,
    })
  },

  //管理活动页面
  navigateToActivityManage: function(e) {
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
    
    wx.navigateTo({
      url: '/pages/my_page/activity_manage/index?type='+e.currentTarget.dataset.type
    });
  },

  // 跳转到好食才付款页面
  navigateToPayAfter: function() {
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    wx.navigateTo({
      url: '/pages/my_page/payafter/index'
    })
  },

  // 跳转到买一送一页面
  navigateToBuyOne: function() {
    // this.goto_login();

    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
    
    wx.navigateTo({
      url: '/pages/my_page/buyone/index'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  // 关键：配置分享内容
  onShareAppMessage(res) {
    console.log(res);
    // 动态生成分享参数（例如：从当前页面数据获取）
    const shareParams = {
      userId: '12345',  // 从当前页面数据获取（如用户ID）
      scene: 'home'      // 自定义场景标识
    };

    // 拼接分享路径（关键！）
    const sharePath = '/pages/my_page/campaign_detail/index?id='+res.target.dataset.id+'&type='+res.target.dataset.type;

    return {
      title: '快来参与这个超值活动！',  // 分享标题
      path: sharePath,                      // 指定分享到的页面路径（带参数）
      imageUrl: res.target.dataset.image,         // 分享卡片图片（必须是本地路径）
      success: (res) => {
        console.log('分享成功', res);
      },
      fail: (res) => {
        console.log('分享失败', res);
      }
    };
  }
})