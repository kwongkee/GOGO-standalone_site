// pages/seller/index.js
const app = getApp();
const u = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_merchant:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;

    //检测是否有企业的卖家
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'check_seller',
      'id': wx.getStorageSync('uid'),
    }).then(res => {
      if(res.data.code==0){
        t.setData({
          is_merchant: res.data.is_merchant
        })
      }
    });
  },

  is_login(){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/seller/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  /**
   * 跳转到交易管理页面
   */
  goToTrade: function() {
    wx.navigateTo({
      url: '/pages/seller/trade',
      success: function(res) {
        console.log('跳转到交易管理页面成功');
      },
      fail: function(err) {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 跳转到上架管理页面
   */
  goToListing: function() {
    wx.navigateTo({
      url: '/pages/seller/listing',
      success: function(res) {
        console.log('跳转到上架管理页面成功');
      },
      fail: function(err) {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let t = this;
    //检测有无登录
    t.is_login();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})