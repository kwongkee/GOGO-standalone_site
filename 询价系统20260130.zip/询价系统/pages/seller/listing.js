const app = getApp();
const u = require('../../utils/util.js');

Page({
  data: {
    jieti:[],
    jieti_edit:[],

    // 搜索相关
    searchKeyword: '',
    currentFilter: 'all',
    
    // 商品数据
    allProducts: [],
    groupedProducts: [],
    filteredProducts: [],
    
    // 分页相关
    currentPage: 1,
    pageSize: 20,
    hasMore: false,
    isLoading: false,
    
    // 编辑相关
    showEditModal: false,
    editType: 'stock', // stock | price
    modalTitle: '编辑库存',
    currentEditItem: null,
    operationType: 'set', // set | add | reduce
    editValue: '',
    
    // 快速操作面板
    showQuickActions: false,
    
    // Toast提示
    showToast: false,
    toastMessage: '',
    
    // 原始数据备份
    originalData: []
  },

  onLoad() {
    this.initData();
  },

  onShow() {
    // 页面显示时刷新数据
    this.refreshData();
  },

  // 初始化数据
  initData() {
    let t = this;
    t.setData({ isLoading: true });
    
    try {
      // 从服务器获取数据
      u.post(app.globalData.url + 'api/miniprogram/index', {
        'method': 'get_shelf_info',
        'page': t.data.currentPage,
        'pageSize': t.data.pageSize
      }).then(res => {
        if (res.data.code == 0 && res.data.list) {
          var products = res.data.list;
          
          // 备份原始数据
          // this.data.originalData = JSON.parse(JSON.stringify(products));
          
          // 分组商品数据
          var groupedProducts = t.groupProducts(products);
          
          t.setData({
            allProducts: products,
            groupedProducts: groupedProducts,
            filteredProducts: groupedProducts,
            hasMore: res.data.hasMore || false,
            isLoading: false
          });
          
          t.showSuccessToast('数据加载成功');
        } else {
          throw new Error(res.msg || '数据加载失败');
        }
      });
    } catch (error) {
      console.error('初始化数据失败:', error);
      
      // 使用模拟数据
      // const mockProducts = t.getMockData();
      // const groupedProducts = t.groupProducts(mockProducts);
      
      // t.setData({
      //   allProducts: mockProducts,
      //   groupedProducts: groupedProducts,
      //   filteredProducts: groupedProducts,
      //   isLoading: false
      // });
      
      // t.showErrorToast('使用模拟数据');
    }
  },

  // 获取模拟数据 - 交错显示有规格和无规格商品
  getMockData() {
    return [
      // 第一个商品：无规格商品
      {
        productId: 'P001',
        productName: '经典牛肉汉堡',
        hasSpecs: false,
        defaultImage: 'https://img.freepik.com/premium-photo/juicy-beef-burger-with-tomatoes-lettuce-cheese-dark-background_89816-3094.jpg',
        specs: [{
          specId: 'S001',
          specName: '经典牛肉汉堡',
          specDesc: '新鲜牛肉饼配生菜番茄',
          specCode: 'BURGER-001',
          image: 'https://img.freepik.com/premium-photo/juicy-beef-burger-with-tomatoes-lettuce-cheese-dark-background_89816-3094.jpg',
          price: 38.0,
          stock: 45,
          stockWarning: 10,
          lastModified: '2024-01-15'
        }]
      },
      
      // 第二个商品：有规格商品（披萨）
      {
        productId: 'P002',
        productName: '手工披萨系列',
        hasSpecs: true,
        defaultImage: 'https://img.freepik.com/premium-photo/pizza-with-salami-sausage-mushrooms-olives-cheese-dark-wooden-table_126277-1045.jpg',
        specs: [
          {
            specId: 'S002',
            specName: '玛格丽特披萨(9寸)',
            specDesc: '经典意式番茄芝士',
            specCode: 'PIZZA-SM-MAR',
            image: 'https://img.freepik.com/premium-photo/homemade-margherita-pizza-dark-background_1339-83885.jpg',
            price: 68.0,
            stock: 25,
            stockWarning: 5,
            lastModified: '2024-01-14'
          },
          {
            specId: 'S003',
            specName: '玛格丽特披萨(12寸)',
            specDesc: '经典意式-大份装',
            specCode: 'PIZZA-LG-MAR',
            image: 'https://img.freepik.com/premium-photo/homemade-margherita-pizza-dark-background_1339-83885.jpg',
            price: 98.0,
            stock: 15,
            stockWarning: 5,
            lastModified: '2024-01-14'
          }
        ]
      },
      
      // 第三个商品：无规格商品
      {
        productId: 'P003',
        productName: '香脆薯条',
        hasSpecs: false,
        defaultImage: 'https://img.freepik.com/premium-photo/french-fries-with-ketchup-dark-background_1339-71196.jpg',
        specs: [{
          specId: 'S004',
          specName: '大份薯条',
          specDesc: '金黄酥脆现炸薯条',
          specCode: 'FRIES-LG',
          image: 'https://img.freepik.com/premium-photo/french-fries-with-ketchup-dark-background_1339-71196.jpg',
          price: 18.0,
          stock: 120,
          stockWarning: 30,
          lastModified: '2024-01-15'
        }]
      },
      
      // 第四个商品：有规格商品（咖啡）
      {
        productId: 'P004',
        productName: '现磨咖啡',
        hasSpecs: true,
        defaultImage: 'https://img.freepik.com/premium-photo/coffee-beans-dark-background_35913-3668.jpg',
        specs: [
          {
            specId: 'S005',
            specName: '美式咖啡(大杯)',
            specDesc: '经典美式黑咖啡',
            specCode: 'COFFEE-LG-AME',
            image: 'https://img.freepik.com/premium-photo/cup-coffee-dark-background_1339-51192.jpg',
            price: 25.0,
            stock: 100,
            stockWarning: 20,
            lastModified: '2024-01-15'
          },
          {
            specId: 'S006',
            specName: '拿铁咖啡(大杯)',
            specDesc: '香浓拿铁加奶泡',
            specCode: 'COFFEE-LG-LAT',
            image: 'https://img.freepik.com/premium-photo/latte-coffee-cup-dark-background_1339-51191.jpg',
            price: 32.0,
            stock: 80,
            stockWarning: 15,
            lastModified: '2024-01-15'
          },
          {
            specId: 'S007',
            specName: '卡布奇诺(大杯)',
            specDesc: '丰富奶泡卡布奇诺',
            specCode: 'COFFEE-LG-CAP',
            image: 'https://img.freepik.com/premium-photo/cappuccino-cup-dark-background_1339-51189.jpg',
            price: 35.0,
            stock: 65,
            stockWarning: 15,
            lastModified: '2024-01-15'
          }
        ]
      },
      
      // 第五个商品：无规格商品
      {
        productId: 'P005',
        productName: '新奥尔良烤翅',
        hasSpecs: false,
        defaultImage: 'https://img.freepik.com/premium-photo/chicken-wings-barbecue-sauce-dark-background_1339-3962.jpg',
        specs: [{
          specId: 'S008',
          specName: '新奥尔良烤翅(6只)',
          specDesc: '秘制新奥尔良风味',
          specCode: 'WINGS-6',
          image: 'https://img.freepik.com/premium-photo/chicken-wings-barbecue-sauce-dark-background_1339-3962.jpg',
          price: 32.0,
          stock: 55,
          stockWarning: 10,
          lastModified: '2024-01-14'
        }]
      },
      
      // 第六个商品：有规格商品（甜品）
      {
        productId: 'P006',
        productName: '精选甜品',
        hasSpecs: true,
        defaultImage: 'https://img.freepik.com/premium-photo/chocolate-cake-dark-background_1339-380.jpg',
        specs: [
          {
            specId: 'S009',
            specName: '巧克力慕斯蛋糕',
            specDesc: '浓郁巧克力慕斯',
            specCode: 'DESSERT-CHO',
            image: 'https://img.freepik.com/premium-photo/chocolate-mousse-cake-dark-background_1339-381.jpg',
            price: 48.0,
            stock: 30,
            stockWarning: 5,
            lastModified: '2024-01-15'
          },
          {
            specId: 'S010',
            specName: '提拉米苏',
            specDesc: '意大利经典甜品',
            specCode: 'DESSERT-TIR',
            image: 'https://img.freepik.com/premium-photo/tiramisu-dark-background_1339-382.jpg',
            price: 45.0,
            stock: 28,
            stockWarning: 5,
            lastModified: '2024-01-15'
          }
        ]
      },
      
      // 第七个商品：无规格商品
      {
        productId: 'P007',
        productName: '田园蔬菜沙拉',
        hasSpecs: false,
        defaultImage: 'https://img.freepik.com/premium-photo/fresh-vegetable-salad-dark-background_1339-388.jpg',
        specs: [{
          specId: 'S011',
          specName: '田园蔬菜沙拉',
          specDesc: '新鲜蔬菜配特调酱汁',
          specCode: 'SALAD-VEG',
          image: 'https://img.freepik.com/premium-photo/fresh-vegetable-salad-dark-background_1339-388.jpg',
          price: 28.0,
          stock: 40,
          stockWarning: 10,
          lastModified: '2024-01-15'
        }]
      },
      
      // 第八个商品：有规格商品（饮料）
      {
        productId: 'P008',
        productName: '特色饮品',
        hasSpecs: true,
        defaultImage: 'https://img.freepik.com/premium-photo/fresh-fruit-juice-dark-background_1339-2645.jpg',
        specs: [
          {
            specId: 'S012',
            specName: '鲜榨橙汁(大杯)',
            specDesc: '新鲜橙子现榨',
            specCode: 'DRINK-ORA',
            image: 'https://img.freepik.com/premium-photo/fresh-orange-juice-dark-background_1339-2646.jpg',
            price: 22.0,
            stock: 75,
            stockWarning: 15,
            lastModified: '2024-01-15'
          },
          {
            specId: 'S013',
            specName: '柠檬冰茶(大杯)',
            specDesc: '清爽柠檬红茶',
            specCode: 'DRINK-LEM',
            image: 'https://img.freepik.com/premium-photo/iced-lemon-tea-dark-background_1339-2647.jpg',
            price: 18.0,
            stock: 90,
            stockWarning: 20,
            lastModified: '2024-01-15'
          },
          {
            specId: 'S014',
            specName: '草莓奶昔',
            specDesc: '新鲜草莓制作',
            specCode: 'DRINK-STR',
            image: 'https://img.freepik.com/premium-photo/strawberry-milkshake-dark-background_1339-2648.jpg',
            price: 25.0,
            stock: 60,
            stockWarning: 12,
            lastModified: '2024-01-15'
          }
        ]
      }
    ];
  },

  // 分组商品数据
  groupProducts(products) {
    return products;
    // .map(product => ({
    //   ...product,
    //   // 确保specs数组存在
    //   specs: product.specs || []
    // })).filter(product => product.specs.length > 0);
  },

  // 搜索输入
  onSearchInput(e) {
    const keyword = e.detail.value;
    this.setData({ searchKeyword: keyword });
    
    // 防抖处理，300ms后执行搜索
    clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => {
      this.performSearch(keyword);
    }, 300);
  },

  // 搜索确认
  onSearchConfirm(e) {
    const keyword = e.detail.value;
    this.performSearch(keyword);
  },

  // 执行搜索
  performSearch(keyword) {
    let t = this;
    // console.log('搜索词：',keyword);
    if (!keyword.trim()) {
      // t.applyFilter(t.data.currentFilter);
      let product = t.data.allProducts;
      t.setData({ groupedProducts: product,filteredProducts:product });
      return;
    }
    
    var searchLower = keyword;
    var filtered = t.data.allProducts.map(product => {
      // 深拷贝产品
      
      var productCopy = JSON.parse(JSON.stringify(product));
      
      // 过滤规格
      productCopy.specs = productCopy.specs.filter(spec => {
        const productName = productCopy.productName;
        const specName = spec.specName;
        const specCode = spec.specCode;
        const specDesc = spec.specDesc;
        
        return productName.includes(searchLower);
      });
      
      return productCopy;
    }).filter(product => product.specs.length > 0);
    
    t.setData({ groupedProducts: filtered });
  },

  // 清空搜索
  onClearSearch() {
    this.setData({ searchKeyword: '' });
    this.applyFilter(this.data.currentFilter);
  },

  // 筛选改变
  onFilterChange(e) {
    const filterType = e.currentTarget.dataset.type;
    this.setData({ currentFilter: filterType });
    this.applyFilter(filterType);
  },

  // 应用筛选
  applyFilter(filterType) {
    let filtered = this.data.groupedProducts;
    
    switch (filterType) {
      case 'lowStock':
        filtered = filtered.map(product => {
          const productCopy = JSON.parse(JSON.stringify(product));
          productCopy.specs = productCopy.specs.filter(
            spec => spec.stock <= spec.stockWarning
          );
          return productCopy;
        }).filter(product => product.specs.length > 0);
        break;
        
      case 'withSpecs':
        filtered = filtered.filter(product => product.hasSpecs);
        break;
        
      case 'noSpecs':
        filtered = filtered.filter(product => !product.hasSpecs);
        break;
        
      case 'all':
      default:
        // 显示全部
        break;
    }
    
    this.setData({ filteredProducts: filtered });
  },

  // 编辑库存
  onEditStock(e) {
    const { productId, specId, index } = e.currentTarget.dataset;
    console.log('编辑库存:', { productId, specId, index });
    
    // 找到对应的产品
    const product = this.data.allProducts.find(p => p.productId === productId);
    
    if (!product) {
      console.error('未找到商品:', productId);
      return;
    }
    
    // 找到对应的规格
    const spec = product.specs.find(s => s.specId === specId) || product.specs[index];
    
    if (!spec) {
      console.error('未找到规格:', specId);
      return;
    }
    
    this.setData({
      showEditModal: true,
      editType: 'stock',
      modalTitle: '编辑库存',
      currentEditItem: {
        productId: product.productId,
        productName: product.productName,
        specId: spec.specId,
        specName: spec.specName,
        specCode: spec.specCode,
        image: spec.image || product.defaultImage,
        stock: spec.stock,
        price: spec.price
      },
      operationType: 'set',
      editValue: ''
    });
  },

  // 编辑价格
  onEditPrice(e) {
    let t = this;
    const { productId, specId, index } = e.currentTarget.dataset;
    console.log('编辑价格:', { productId, specId, index });
    
    //获取当前商品下得规格下的价格
    u.post(app.globalData.url + 'api/miniprogram/index', {'method':'edit_stock_price','id':productId,'specid':specId,'type':'get_goods_jieti_price','value':0}).then(res => {
      if(res.data.code==0){
        console.log(res);
        t.setData({
          jieti:res.data.data,
          jieti_edit:res.data.data
        })
      }
    });

    // 找到对应的产品
    const product = this.data.allProducts.find(p => p.productId === productId);
    
    if (!product) {
      console.error('未找到商品:', productId);
      return;
    }
    
    // 找到对应的规格
    const spec = product.specs.find(s => s.specId === specId) || product.specs[index];
    
    if (!spec) {
      console.error('未找到规格:', specId);
      return;
    }
    
    this.setData({
      showEditModal: true,
      editType: 'price',
      modalTitle: '编辑价格',
      currentEditItem: {
        productId: product.productId,
        productName: product.productName,
        specId: spec.specId,
        specName: spec.specName,
        specCode: spec.specCode,
        image: spec.image || product.defaultImage,
        stock: spec.stock,
        price: spec.price
      },
      operationType: 'set',
      editValue: ''
    });
  },

  // 操作类型改变
  onOperationTypeChange(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({ operationType: type });
  },

  // 编辑值输入
  onEditValueInput(e) {
    this.setData({ editValue: e.detail.value });
  },
  // 编辑值输入
  onEditPriceValueInput(e) {
    let t = this;
    t.data.jieti_edit[e.currentTarget.dataset.index].price = e.detail.value;
    let jieti_edit = t.data.jieti_edit;
    t.setData({ 
      jieti_edit: jieti_edit 
    });
  },
  // 数字减少
  onNumberMinus() {
    let value = parseFloat(this.data.editValue) || 0;
    if (value > 0) {
      value = this.data.editType === 'price' ? 
        parseFloat((value - 0.01).toFixed(2)) : 
        Math.max(0, value - 1);
      this.setData({ editValue: value.toString() });
    }
  },

  // 数字增加
  onNumberPlus() {
    let value = parseFloat(this.data.editValue) || 0;
    value = this.data.editType === 'price' ? 
      parseFloat((value + 0.01).toFixed(2)) : 
      value + 1;
    this.setData({ editValue: value.toString() });
  },

  // 计算库存结果
  calculateStockResult() {
    const { currentEditItem, operationType, editValue } = this.data;
    if (!currentEditItem || !editValue) return currentEditItem ? currentEditItem.stock : 0;
    
    const value = parseInt(editValue) || 0;
    let result = currentEditItem.stock;
    
    switch (operationType) {
      case 'set':
        result = Math.max(0, value);
        break;
      case 'add':
        result = currentEditItem.stock + value;
        break;
      case 'reduce':
        result = Math.max(0, currentEditItem.stock - value);
        break;
    }
    
    return result;
  },

  // 计算价格结果
  calculatePriceResult() {
    const { currentEditItem, operationType, editValue } = this.data;
    if (!currentEditItem || !editValue) return currentEditItem ? currentEditItem.price : 0;
    
    const value = parseFloat(editValue) || 0;
    let result = currentEditItem.price;
    
    switch (operationType) {
      case 'set':
        result = Math.max(0, value);
        break;
      case 'add':
        result = parseFloat((currentEditItem.price + value).toFixed(2));
        break;
      case 'reduce':
        result = parseFloat((Math.max(0, currentEditItem.price - value)).toFixed(2));
        break;
    }
    
    return result;
  },

  // 确认编辑
  async onConfirmEdit() {
    let t = this;
    const { currentEditItem, editType, operationType, editValue, jieti_edit } = t.data;
    
    if(editType=='stock'){
      if (!editValue || isNaN(parseFloat(editValue)) || parseFloat(editValue) < 0) {
        t.showErrorToast('请输入有效的数值');
        return;
      }
    }
    
    // console.log(currentEditItem, editType, operationType, editValue);return;
    try {
      // 更新本地数据
      // this.updateLocalData(currentEditItem, editType, operationType, editValue);
      u.post(app.globalData.url + 'api/miniprogram/index', {'method':'edit_stock_price','id':currentEditItem.productId,'specid':currentEditItem.specId,'value':editValue,'type':editType,'jieti_edit':JSON.stringify(jieti_edit)}).then(res => {
        if(res.data.code==0){
          t.refreshData();
        }
      });
      t.onCloseModal();

      // t.showSuccessToast(`${editType === 'stock' ? '库存' : '价格'}更新成功`);
      
      // // 重新应用当前筛选
      // t.applyFilter(t.data.currentFilter);
      
    } catch (error) {
      console.error('更新失败:', error);
      t.showErrorToast('更新失败，请重试');
    }
  },

  // 更新本地数据
  updateLocalData(item, editType, operationType, editValue) {
    const { allProducts, groupedProducts } = this.data;
    
    // 更新allProducts
    const updatedAllProducts = allProducts.map(product => {
      if (product.productId === item.productId) {
        const productCopy = JSON.parse(JSON.stringify(product));
        productCopy.specs = productCopy.specs.map(spec => {
          if (spec.specId === item.specId) {
            const specCopy = { ...spec };
            const value = editType === 'price' ? 
              parseFloat(editValue) : parseInt(editValue);
            
            switch (operationType) {
              case 'set':
                specCopy[editType] = value;
                break;
              case 'add':
                specCopy[editType] = editType === 'price' ? 
                  parseFloat((spec[editType] + value).toFixed(2)) : 
                  spec[editType] + value;
                break;
              case 'reduce':
                specCopy[editType] = editType === 'price' ? 
                  parseFloat((Math.max(0, spec[editType] - value)).toFixed(2)) : 
                  Math.max(0, spec[editType] - value);
                break;
            }
            
            specCopy.lastModified = new Date().toISOString();
            return specCopy;
          }
          return spec;
        });
        return productCopy;
      }
      return product;
    });
    
    // 更新groupedProducts
    const updatedGroupedProducts = this.groupProducts(updatedAllProducts);
    
    this.setData({
      allProducts: updatedAllProducts,
      groupedProducts: updatedGroupedProducts
    });
  },

  // 关闭模态框
  onCloseModal() {
    this.setData({
      showEditModal: false,
      currentEditItem: null,
      editValue: ''
    });
  },

  // 切换快速操作面板
  onToggleQuickActions() {
    this.setData({ showQuickActions: !this.data.showQuickActions });
  },

  // 关闭快速操作面板
  onCloseQuickActions() {
    this.setData({ showQuickActions: false });
  },

  // 批量更新库存
  onBatchUpdateStock() {
    this.onCloseQuickActions();
    wx.showModal({
      title: '批量更新库存',
      content: '此功能正在开发中',
      showCancel: false
    });
  },

  // 批量更新价格
  onBatchUpdatePrice() {
    this.onCloseQuickActions();
    wx.showModal({
      title: '批量更新价格',
      content: '此功能正在开发中',
      showCancel: false
    });
  },

  // 导出数据
  onExportData() {
    this.onCloseQuickActions();
    wx.showModal({
      title: '导出数据',
      content: '此功能正在开发中',
      showCancel: false
    });
  },

  // 同步数据
  onSyncData() {
    this.onCloseQuickActions();
    this.refreshData();
  },

  // 刷新数据
  refreshData() {
    this.setData({ 
      isLoading: true 
    });
    
    // 模拟网络请求延迟
    setTimeout(() => {
      const mockProducts = this.initData();
      const groupedProducts = this.groupProducts(mockProducts);
      
      this.setData({
        allProducts: mockProducts,
        groupedProducts: groupedProducts,
        filteredProducts: groupedProducts,
        isLoading: false
      });
      
      this.showSuccessToast('数据刷新成功');
    }, 800);
  },

  // 下拉刷新
  onRefresh() {
    this.refreshData();
    wx.stopPullDownRefresh();
  },

  // 显示成功提示
  showSuccessToast(message) {
    this.setData({
      showToast: true,
      toastMessage: message
    });
    
    setTimeout(() => {
      this.setData({ showToast: false });
    }, 2000);
  },

  // 显示错误提示
  showErrorToast(message) {
    this.setData({
      showToast: true,
      toastMessage: message
    });
    
    setTimeout(() => {
      this.setData({ showToast: false });
    }, 2000);
  },

  // 页面卸载
  onUnload() {
    // 清理定时器
    clearTimeout(this.searchTimer);
  },

  // 阻止事件冒泡
  stopPropagation() {
    // 空函数，用于阻止事件冒泡
  }
});