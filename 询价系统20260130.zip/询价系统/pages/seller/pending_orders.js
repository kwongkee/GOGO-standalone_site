const app = getApp();
const u = require('../../utils/util.js');

Page({
  data: {
    searchKeyword: '',
    activeFilter: 'all',
    orders: [
      {
        orderId: 'DD20230415001',
        pickupCode: 'A102',
        amount: '68.50',
        paymentMethod: 'wechat',
        orderTime: '14:30',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415002',
        pickupCode: 'B205',
        amount: '125.00',
        paymentMethod: 'cash',
        orderTime: '14:45',
        isUrgent: true,
        isToday: true
      },
      {
        orderId: 'DD20230414015',
        pickupCode: 'C301',
        amount: '42.00',
        paymentMethod: 'wechat',
        orderTime: '昨日 19:20',
        isUrgent: false,
        isToday: false
      },
      {
        orderId: 'DD20230415003',
        pickupCode: 'A105',
        amount: '89.00',
        paymentMethod: 'wechat',
        orderTime: '15:10',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415004',
        pickupCode: 'D401',
        amount: '156.80',
        paymentMethod: 'cash',
        orderTime: '15:25',
        isUrgent: true,
        isToday: true
      }
    ],
    filteredOrders: []
  },

  onLoad: function() {
    let t = this;

    // 清理可能存在的旧定时器
    t.clearTimers();

    let timeoutId = setTimeout(function(){
      t.getOrder();
    },1);

    let intervalId = setInterval(function(){
      t.getOrder();
    },5000);

    t.setData({
      timeoutId: timeoutId,
      intervalId: intervalId
    });
  },

  onUnload: function() {
    // 页面卸载时清理定时器
    this.clearTimers();
  },

  onHide: function() {
    // 页面隐藏时也可以清理，防止后台运行
    this.clearTimers();
  },

  onShow: function() {
    // 页面显示时重新启动定时器
    if (this.data.intervalId === null) {
      let t = this;
      let intervalId = setInterval(function() {
        t.getOrder();
      }, 5000);
      this.setData({ intervalId: intervalId });
    }
  },

  clearTimers: function() {
    // 清理timeout
    if (this.data.timeoutId) {
      clearTimeout(this.data.timeoutId);
      this.setData({ timeoutId: null });
    }
    
    // 清理interval
    if (this.data.intervalId) {
      clearInterval(this.data.intervalId);
      this.setData({ intervalId: null });
    }
  },

  getOrder(){
    let t = this;
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_orders_list',
      'status': '1'
    }).then(res => {
      t.setData({
        orders: res.data.data,
        filteredOrders:res.data.data
      });
    });
  },

  gotoOrder(e){
    let cart_id = e.currentTarget.dataset.cart_id;
    wx.navigateTo({
      url: '/pages/orderfood/order?orderId='+cart_id,
    })
  },

  onSearchInput: function(e) {
    this.setData({
      searchKeyword: e.detail.value
    });
    this.filterOrders();
  },

  onSearch: function() {
    this.filterOrders();
  },

  clearSearch: function() {
    this.setData({
      searchKeyword: ''
    });
    this.filterOrders();
  },

  changeFilter: function(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({
      activeFilter: filter
    });
    this.filterOrders();
  },

  filterOrders: function() {
    const { searchKeyword, activeFilter, orders } = this.data;
    
    let filtered = orders.filter(order => {
      // 搜索筛选
      if (searchKeyword && !order.orderNo.includes(searchKeyword)) {
        return false;
      }
      
      return true;
    });
    
    this.setData({
      filteredOrders: filtered
    });
  },

  acceptOrder: function(e) {
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '确认接单',
      content: `确定要接受订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '2'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '接单成功',
                  icon: 'success',
                  duration: 2000
                });
                // 从列表中移除已接单的订单
                const orders = this.data.orders.filter(order => order.orderId !== orderId);
                this.setData({ orders, filteredOrders: orders });
              }
            });
          }, 500);
        }
      }
    });
  },

  confirmPayment: function(e) {
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '确认支付',
      content: '请确认顾客已完成支付',
      success: (res) => {
        if (res.confirm) {
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '1'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '支付已确认',
                  icon: 'success',
                  duration: 2000
                });
                // t.getOrder();
              }
            });
          }, 500);
        }
      }
    });
  },

  rejectOrder: function(e) {
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '拒绝订单',
      content: `确定要拒绝订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          // 在实际应用中，这里应该调用API更新订单状态
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '-1'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '订单已拒绝',
                  icon: 'success',
                  duration: 2000
                });
              }
            });
            const orders = this.data.orders.filter(order => order.orderId !== orderId);
            this.setData({ orders, filteredOrders: orders });
          }, 500);
        }
      }
    });
  }
});