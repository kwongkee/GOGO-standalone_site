// pages/index/index.js
Page({
  data: {
    
  },

  onLoad: function() {
    
  },

  navigateToPendingOrders: function() {
    wx.navigateTo({
      url: '/pages/seller/pending_orders'
    });
  },

  navigateToPendingDelivery: function() {
    wx.navigateTo({
      url: '/pages/seller/pending_delivery'
    });
  },

  navigateToPendedDelivered: function() {
    wx.navigateTo({
      url: '/pages/seller/pended_delivered'
    });
  }
});