const app = getApp();
const u = require('../../utils/util.js');

Page({
  data: {
    searchKeyword: '',
    activeFilter: 'all',
    orders: [
      {
        orderId: 'DD20230415001',
        pickupCode: 'A102',
        amount: '68.50',
        paymentMethod: 'wechat',
        orderTime: '14:30',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415002',
        pickupCode: 'B205',
        amount: '125.00',
        paymentMethod: 'cash',
        orderTime: '14:45',
        isUrgent: true,
        isToday: true
      },
      {
        orderId: 'DD20230414015',
        pickupCode: 'C301',
        amount: '42.00',
        paymentMethod: 'wechat',
        orderTime: '昨日 19:20',
        isUrgent: false,
        isToday: false
      },
      {
        orderId: 'DD20230415003',
        pickupCode: 'A105',
        amount: '89.00',
        paymentMethod: 'wechat',
        orderTime: '15:10',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415004',
        pickupCode: 'D401',
        amount: '156.80',
        paymentMethod: 'cash',
        orderTime: '15:25',
        isUrgent: true,
        isToday: true
      }
    ],
    filteredOrders: [],
    // 分页相关参数
    currentPage: 1,      // 当前页码
    pageSize: 10,        // 每页显示数量
    totalPages: 0,       // 总页数
    isLoading: false,    // 是否正在加载
    hasMore: true,       // 是否还有更多数据
    totalCount: 0        // 总数据量
  },

  onLoad: function() {
    let t = this;

    t.getOrder();
  },

  getOrder(isLoadMore = false){
    let t = this;

    // 防止重复加载
    console.log(t.data.isLoading,!isLoadMore,!t.data.hasMore,123);
    if (t.data.isLoading || (!isLoadMore && !t.data.hasMore)) {
      return;
    }
    
    // 计算当前页码
    const page = isLoadMore ? t.data.currentPage + 1 : 1;

    // 显示加载状态
    if (isLoadMore) {
      wx.showLoading({
        title: '加载中...',
      });
    }
    
    t.setData({
      isLoading: true
    });

    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_orders_list',
      'status': '3',
      'company_id': wx.getStorageSync('default_company_id'),
      'page': page,           // 添加分页参数
      'page_size': t.data.pageSize  // 添加每页数量参数
    }).then(res => {
      wx.hideLoading();

      if (res.data.code === 0) {
        const orderList = res.data.data || [];
        const totalCount = res.data.total || 0;
        
        // 计算总页数
        const totalPages = Math.ceil(totalCount / t.data.pageSize);
        
        let filteredOrders = [];
        if (isLoadMore) {
          // 加载更多：合并新旧数据
          filteredOrders = [...t.data.filteredOrders, ...orderList];
        } else {
          // 刷新：使用新数据
          filteredOrders = orderList;
        }
        
        // 更新数据
        t.setData({
          orders: orderList,
          filteredOrders: filteredOrders,
          currentPage: page,
          totalPages: totalPages,
          hasMore: page < totalPages,
          totalCount: totalCount,
          isLoading: false
        });
        
        // 如果没有更多数据了，可以给用户提示
        if (page >= totalPages && isLoadMore) {
          wx.showToast({
            title: '没有更多了',
            icon: 'none',
            duration: 2000
          });
        }
      } else {
        t.setData({
          isLoading: false
        });
        wx.showToast({
          title: res.data.msg || '加载失败',
          icon: 'none'
        });
      }

      // t.setData({
      //   orders: res.data.data,
      //   filteredOrders:res.data.data
      // });
    });
  },

  // 监听页面滚动到底部
  onReachBottom: function() {
    let t = this;
    
    // 检查是否还有更多数据可以加载
    console.log(!t.data.isLoading,t.data.hasMore,234);
    if (!t.data.isLoading && t.data.hasMore) {
      console.log('滚动到底部，加载更多数据...');
      t.getOrder(true);  // 加载更多数据
    } else if (!t.data.hasMore) {
      // 可以给用户一个提示，表示没有更多数据了
      wx.showToast({
        title: '已加载全部数据',
        icon: 'none',
        duration: 1500
      });
    }
  },

  // 下拉刷新
  onPullDownRefresh: function() {
    let t = this;
    
    // 重置分页参数
    t.setData({
      currentPage: 1,
      hasMore: true,
      isLoading: false
    });
    
    // 重新加载第一页数据
    t.getOrder(false);
    
    // 停止下拉刷新
    wx.stopPullDownRefresh();
  },

  gotoOrder(e){
    let cart_id = e.currentTarget.dataset.cart_id;
    wx.navigateTo({
      url: '/pages/orderfood/order?orderId='+cart_id,
    })
  },

  onSearchInput: function(e) {
    this.setData({
      searchKeyword: e.detail.value
    });
    this.filterOrders();
  },

  onSearch: function() {
    this.filterOrders();
  },

  clearSearch: function() {
    this.setData({
      searchKeyword: ''
    });
    this.filterOrders();
  },

  changeFilter: function(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({
      activeFilter: filter
    });
    this.filterOrders();
  },

  filterOrders: function() {
    const { searchKeyword, activeFilter, orders } = this.data;
    
    let filtered = orders.filter(order => {
      // 搜索筛选
      if (searchKeyword && !order.orderNo.includes(searchKeyword)) {
        return false;
      }
      
      return true;
    });
    
    this.setData({
      filteredOrders: filtered
    });
  },

  acceptPrint: function(e){
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;

    wx.showModal({
      title: '打印面单',
      content: `确定要打印面单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'print_order',
              'id': orderId,
              'ordersn': orderSn,
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '打印成功',
                  icon: 'success',
                  duration: 2000
                });
              }
            });
          }, 500);
        }
      }
    });
  },

  acceptOrder: function(e) {
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '确认交付',
      content: `确定要交付订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '3'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '交付成功',
                  icon: 'success',
                  duration: 2000
                });
                // 从列表中移除已接单的订单
                const orders = this.data.orders.filter(order => order.orderId !== orderId);
                this.setData({ orders, filteredOrders: orders });
              }
            });
          }, 500);
        }
      }
    });
  },

  rejectOrder: function(e) {
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '拒绝订单',
      content: `确定要拒绝订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          // 在实际应用中，这里应该调用API更新订单状态
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '-1'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '订单已拒绝',
                  icon: 'success',
                  duration: 2000
                });
              }
            });
            const orders = this.data.orders.filter(order => order.orderId !== orderId);
            this.setData({ orders, filteredOrders: orders });
          }, 500);
        }
      }
    });
  }
});