// 线下店铺首页
// 获取应用实例
var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    is_seller: 0,
    categories: [
      { id: 1, name: '热销推荐', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 2, name: '套餐系列', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 3, name: '招牌菜', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 4, name: '饮料甜品', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 5, name: '主食', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' }
    ],
    foods: [],  // 所有商品数据
    filteredFoods: [],  // 当前分类的商品
    activeCategory: 1,
    currentCategoryName: '热销推荐',
    totalQuantity: 0,  // 总数量
    totalPrice: 0,     // 总价格
    orderItems: [],    // 下单商品列表
    
    // 规格选择弹窗相关
    showSpecModal: false,
    currentSpecs: [],  // 当前商品的规格列表
    currentFoodIndex: -1,  // 当前商品在filteredFoods中的索引
    currentFoodId: null,   // 当前商品ID
    currentSpecIndex: 0,   // 当前选中的规格索引
    modalQuantity: 1,      // 弹窗中的数量
    modalFoodIndex: -1,     // 弹窗对应商品索引

    orderItemsExpanded: false,  // 订单项是否展开
    displayOrderItems: [],      // 用于显示的订单项数组，包含规格信息

    // 弹窗控制
    showPayModal: false,
    showScanModal: false,
    showOnlinePayModal: false,
    showResultModal: false,
    
    // 支付相关
    payMethod: 'wechat',
    paySuccess: false,
    resultMessage: ''
  },

  onLoad(options) {
    //后端获取指定“线下店铺”的分类及商品
    let t = this;
    let is_seller = options.is_seller ? options.is_seller : 0;

    t.setData({
      is_seller: is_seller
    });

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_shop_goods_category'}).then(res => {
      t.setData({
        activeCategory:res.data.category[0].id,
        currentCategoryName:res.data.category[0].name,
        categories:res.data.category,
        foods:res.data.list,
      });
      t.filterFoodsByCategory(res.data.category[0].id);
    });
    // this.loadFoods();
    // 初始化加载第一个分类的商品
    // this.filterFoodsByCategory(1);

    if(wx.getStorageSync('sns_openid')!=''){
      // 计算初始总价和总数
      this.calculateTotal();
    }
  },

  is_login(){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/orderfood/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  onShow() {
    let t = this;

    if(wx.getStorageSync('sns_openid')!=''){
      // 页面显示时重新计算总数和总价
      this.calculateTotal();
    }
  },

  // 切换分类
  switchCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    const category = this.data.categories.find(c => c.id === categoryId);
    
    this.setData({
      activeCategory: categoryId,
      currentCategoryName: category ? category.name : ''
    });
    
    // 过滤商品
    this.filterFoodsByCategory(categoryId);
  },

  // 根据分类过滤商品
  filterFoodsByCategory(categoryId) {
    const filteredFoods = this.data.foods.filter(item => item.categoryId === categoryId);
    this.setData({ filteredFoods });
  },

  // 跳转到详情页
  goToDetail(e) {
    const foodId = e.currentTarget.dataset.id;
    const food = this.data.foods.find(item => item.id === foodId);
    let is_seller = this.data.is_seller;

    if (food) {
      wx.navigateTo({
        url: `/pages/orderfood_detail/index?id=${foodId}&quantity=${food.quantity || 0}&is_seller=${is_seller}`
      });
    }
  },

  // 显示规格选择弹窗
  showSpecModal(e) {
    const index = e.currentTarget.dataset.index;
    const food = this.data.filteredFoods[index];
    
    if (food && food.specifications && food.specifications.length > 0) {
      // 设置默认选中的规格（第一个）
      const selectedSpecIndex = food.selectedSpecIndex !== undefined ? food.selectedSpecIndex : 0;
      
      this.setData({
        showSpecModal: true,
        currentSpecs: food.specifications,
        currentFoodIndex: index,
        currentFoodId: food.id,
        currentSpecIndex: selectedSpecIndex,
        modalQuantity: food.quantity || 1,
        modalFoodIndex: index
      });
    }
  },

  // 隐藏规格选择弹窗
  hideSpecModal() {
    this.setData({
      showSpecModal: false
    });
  },

  // 阻止事件冒泡
  stopPropagation() {
    return;
  },

  // 选择规格
  selectSpec(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      currentSpecIndex: index
    });
  },

  // 弹窗中增加数量
  modalIncreaseQuantity() {
    const newQuantity = this.data.modalQuantity + 1;
    this.setData({
      modalQuantity: newQuantity
    });
  },

  // 弹窗中减少数量
  modalDecreaseQuantity() {
    if (this.data.modalQuantity > 1) {
      const newQuantity = this.data.modalQuantity - 1;
      this.setData({
        modalQuantity: newQuantity
      });
    }
  },

  // 弹窗中数量输入
  onModalQuantityInput(e) {
    const value = parseInt(e.detail.value) || 1;
    if (value >= 1) {
      this.setData({
        modalQuantity: value
      });
    }
  },

  // 确认规格选择
  confirmSpec() {
    const { currentFoodIndex, currentSpecIndex, modalQuantity, currentFoodId } = this.data;
    
    if (currentFoodIndex === -1) return;
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 更新foods中的规格和数量
    const foodIndex = foods.findIndex(item => item.id === currentFoodId);
    if (foodIndex !== -1) {
      foods[foodIndex].selectedSpecIndex = currentSpecIndex;
      foods[foodIndex].quantity = modalQuantity;
    }
    
    // 更新filteredFoods中的规格和数量
    if (filteredFoods[currentFoodIndex]) {
      filteredFoods[currentFoodIndex].selectedSpecIndex = currentSpecIndex;
      filteredFoods[currentFoodIndex].quantity = modalQuantity;

      //切换规格时，当前数量大于规格库存，替换为最大库存量
      if(filteredFoods[currentFoodIndex].quantity > filteredFoods[currentFoodIndex].specifications[currentSpecIndex].goods_number){
        filteredFoods[currentFoodIndex].quantity = filteredFoods[currentFoodIndex].specifications[currentSpecIndex].goods_number;
        foods[foodIndex].quantity = filteredFoods[currentFoodIndex].specifications[currentSpecIndex].goods_number;
        
        this.setData({
          totalQuantity: filteredFoods[currentFoodIndex].quantity,
          foods: foods
        })
      }
    }
    
    this.setData({
      foods,
      filteredFoods,
      showSpecModal: false
    }, () => {
      this.calculateTotal();
    });
  },

  // 修复小数点
  fixFloatPrecision(str) {
    // if (!str || typeof str !== 'string') return str;
    
    // 如果包含小数点
    console.log(str,str.includes('.'),typeof str);
    if (str.includes('.')) {
        // 转换为数字，然后使用toFixed固定小数位数
        const num = parseFloat(str);
        
        // 检查是否是有限数字
        if (isFinite(num)) {
            // 使用toFixed并去掉末尾多余的0
            const fixedStr = num.toFixed(2);
            // 去掉末尾的0
            return fixedStr.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
        }
    }
    return str;
  },

  // 增加数量（原有方法，需修改）
  increaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    const max = e.currentTarget.dataset.max;
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 检查商品是否有规格且已选择规格
    const food = filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      let num = (Number(filteredFoods[index].quantity) || 0) + 1;
      filteredFoods[index].quantity = this.fixFloatPrecision(String(num));
      
      if(Number(filteredFoods[index].quantity) > max){
        filteredFoods[index].quantity = max;
        wx.showToast({
          title: '商品最大库存数：'+max,
          icon: 'none'
        });
      }
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = filteredFoods[index].quantity;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 减少数量（原有方法，需修改）
  decreaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 检查商品是否有规格且已选择规格
    const food = filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      const currentQuantity = filteredFoods[index].quantity || 0;
      if (currentQuantity > 0) {
        let num = currentQuantity - 1;
        filteredFoods[index].quantity = this.fixFloatPrecision(String(num));
        // filteredFoods[index].quantity = currentQuantity - 1;
      }
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = filteredFoods[index].quantity;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 输入框数量变化（原有方法，需修改）
  onQuantityInput(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    const max = e.currentTarget.dataset.max;
    var value = e.detail.value;

    // 清理前导0的函数
    const cleanNumberString = (str) => {
      if (str === '') return '0';
      let parts = str.split('.');
      let integerPart = parts[0];
      let decimalPart = parts.length > 1 ? '.' + parts[1] : '';
      
      // 去掉整数部分的前导0，但保留单独的0
      integerPart = integerPart.replace(/^0+/, '');
      if (integerPart === '') {
          integerPart = '0';
      }
      
      return integerPart + decimalPart;
    };

    // 清理输入值中的前导0
    value = cleanNumberString(value);

    if (value < 0) return;
    //超过数量
    if (Number(value) > max) {
      value = max;
      wx.showToast({
        title: '商品最大库存数：'+max,
        icon: 'none'
      });
    }
    
    // 检查商品是否有规格且已选择规格
    const food = this.data.filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;

    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      filteredFoods[index].quantity = value;
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = value;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 计算总价和总数（修改以支持规格价格）
  calculateTotal() {
    let t = this;
    let totalQuantity = 0;
    let totalPrice = 0;
    let orderItems = [];
    let displayOrderItems = [];

    //判断有无登录，无登录则登录
    t.is_login();
    
    t.data.foods.forEach(item => {
      const quantity = Number(item.quantity) || 0;
      if (quantity > 0) {
        
        // 计算商品价格：有规格的用规格价格，无规格的用基础价格
        var itemPrice = item.price;
        let specName = '';
        let image = item.image;
        
        //根据数量决定价格
        u.post(app.globalData.url + 'api/miniprogram/index', {'method':'get_quantity_price','id':item.id,'quantity':quantity,'spec_id':item.specifications[item.selectedSpecIndex].id}).then(res => {
          if(res.data.code==0){
            if (item.specifications && item.specifications.length > 0 && item.selectedSpecIndex !== undefined) {
              const selectedSpec = item.specifications[item.selectedSpecIndex];
              itemPrice = selectedSpec.price;
              specName = selectedSpec.name;
            }

            itemPrice = res.data.price;
            item.price = res.data.price;
            item.specifications[item.selectedSpecIndex].price = res.data.price;

            totalQuantity = Number(totalQuantity) + Number(quantity);
            totalPrice += parseFloat((itemPrice * quantity).toFixed(2));
            
            // 存储订单项
            orderItems.push({
              id: item.id,
              name: item.name,
              price: itemPrice,
              quantity: quantity,
              image: image,
              specifications: item.specifications,
              selectedSpecIndex: item.selectedSpecIndex,
              totalPrice:parseFloat((itemPrice * quantity).toFixed(2))
            });
            
            // 构建显示用的数据
            displayOrderItems.push({
              id: item.id,
              name: item.name,
              specName: specName,
              quantity: quantity,
              price: itemPrice,
              image: image,
              totalPrice:parseFloat((itemPrice * quantity).toFixed(2))
            });

            totalQuantity = t.fixFloatPrecision(String(totalQuantity));

            t.setData({
              totalQuantity,
              totalPrice: totalPrice.toFixed(2),
              orderItems,
              displayOrderItems
            });
            t.filterFoodsByCategory(t.data.activeCategory);
          }
        });
      }
      else{
        //去除数量为0的商品
        const newOrderItems = t.data.orderItems.filter(item2 => item2.id !== item.id);
        const newDisplayOrderItems = t.data.displayOrderItems.filter(item2 => item2.id !== item.id);

        let totalQuantity = 0;
        let totalPrice = 0;

        // 更新数据
        t.setData({
          totalQuantity,
          totalPrice: totalPrice.toFixed(2),
          orderItems: newOrderItems,
          displayOrderItems: newDisplayOrderItems
        });
      }
    });
  },

  // 添加切换展开/收起的方法
  toggleOrderItemsExpand(e) {
    this.setData({
      orderItemsExpanded: !this.data.orderItemsExpanded
    });
  },

  // 跳转到下单页面
  goToOrder() {
    let t = this;
    t.is_login();
    if(wx.getStorageSync('sns_openid')!=''){
      // 如果订单项是展开状态，先收起
      if (t.data.orderItemsExpanded) {
        t.setData({
          orderItemsExpanded: false
        });
        
        // 延迟执行跳转，让收起动画完成
        setTimeout(() => {
          t.navigateToOrder();
        }, 300);
      } else {
        t.navigateToOrder();
      }
    }
  },

  // 提取下单跳转逻辑
  navigateToOrder() {
    let t = this;
    if (t.data.totalQuantity === 0) {
      wx.showToast({
        title: '请选择商品',
        icon: 'none'
      });
      return;
    }
    
    // 检查是否有商品未选择规格
    const unselectedSpecItems = t.data.orderItems.filter(item => 
      item.specifications && item.specifications.length > 0 && item.selectedSpecIndex === undefined
    );
    
    if (unselectedSpecItems.length > 0) {
      wx.showToast({
        title: '请为商品选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 显示加载中
    wx.showLoading({
      title: '提交选购单中...',
    });

    // 构建提交数据 - 将items字段JSON序列化
    const orderItems = t.data.orderItems.map(item => ({
      goods_id: item.id,
      spec_id: item.specifications && item.specifications.length > 0 && item.selectedSpecIndex !== undefined ? 
              item.specifications[item.selectedSpecIndex].id : null,
      quantity: item.quantity,
      price: item.price,
      name: item.name, // 添加商品名称便于调试
      spec_name: item.specifications && item.specifications.length > 0 && item.selectedSpecIndex !== undefined ? 
                item.specifications[item.selectedSpecIndex].name : null
    }));

    // 构建提交数据
    const orderData = {
      method: 'create_order',
      items: JSON.stringify(orderItems),
      uid: wx.getStorageSync('uid'),
      total_price: t.data.totalPrice,
      total_quantity: t.data.totalQuantity,
      is_seller: t.data.is_seller
    };

    // 将订单数据存储到本地，供下单页面使用
    wx.setStorageSync('orderItems', this.data.orderItems);
    
    // 调用接口存储订单
    u.post(app.globalData.url + 'api/miniprogram/index', orderData).then(res => {
      wx.hideLoading();
      
      if (res.data.code === 0) {
        // 存储订单ID到本地，供订单页面使用
        wx.setStorageSync('currentOrderId', res.data.cart_id);
        wx.setStorageSync('orderData', res.data);
        
        // 跳转到订单确认页面
        wx.navigateTo({
          url: '/pages/orderfood/order?orderId=' + res.data.cart_id + '&is_seller='+ t.data.is_seller
        });
      } else {
        wx.showToast({
          title: res.data.msg || '提交失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '网络错误',
        icon: 'none'
      });
    });
  },

  // 加载商品数据（增加规格数据）
  loadFoods() {
    // 模拟数据 - 确保每个商品都有正确的 categoryId
    const foods = [
      {
        id: 1,
        name: '招牌牛肉汉堡',
        description: '双层牛肉饼，特制酱料',
        price: 38,
        originalPrice: 45,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 1,
        sales: 1250,
        tags: ['招牌', '热销'],
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '常规尺寸', price: 381, originalPrice: 45 },
          { id: 2, name: '加大尺寸', price: 481, originalPrice: 55 },
          { id: 3, name: '套餐（含饮料）', price: 551, originalPrice: 65 }
        ],
        selectedSpecIndex: 0  // 默认选中第一个规格
      },
      {
        id: 2,
        name: '香辣鸡腿堡',
        description: '酥脆鸡腿肉，香辣可口',
        price: 28,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 1,
        sales: 980,
        tags: ['辣', '新品'],
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '常规尺寸', price: 28 },
          { id: 2, name: '加大尺寸', price: 35 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 3,
        name: '经典套餐A',
        description: '汉堡+薯条+可乐',
        price: 45,
        originalPrice: 58,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 2,
        sales: 850,
        quantity: 0,
        // 无规格的商品
        specifications: []
      },
      {
        id: 4,
        name: '双人分享套餐',
        description: '两份汉堡+大份薯条+两杯饮料',
        price: 78,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 2,
        sales: 620,
        quantity: 0,
        specifications: []
      },
      {
        id: 5,
        name: '特制烤鸭',
        description: '传统工艺，皮脆肉嫩',
        price: 88,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 3,
        sales: 450,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '半只', price: 88 },
          { id: 2, name: '整只', price: 168 },
          { id: 3, name: '整只+配菜', price: 198 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 6,
        name: '经典奶茶',
        description: '浓郁茶香，丝滑口感',
        price: 15,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 4,
        sales: 1200,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '中杯', price: 15 },
          { id: 2, name: '大杯', price: 18 },
          { id: 3, name: '特大杯', price: 22 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 7,
        name: '草莓奶昔',
        description: '新鲜草莓，冰凉清爽',
        price: 22,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 4,
        sales: 850,
        quantity: 0,
        specifications: []
      },
      {
        id: 8,
        name: '牛肉面',
        description: '大块牛肉，手工面条',
        price: 35,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 5,
        sales: 950,
        quantity: 0,
        specifications: []
      },
      {
        id: 9,
        name: '扬州炒饭',
        description: '粒粒分明，配料丰富',
        price: 25,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 5,
        sales: 780,
        quantity: 0,
        specifications: []
      },
      {
        id: 10,
        name: '芝士披萨',
        description: '厚芝士，香浓拉丝',
        price: 68,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 3,
        sales: 520,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '7寸', price: 68 },
          { id: 2, name: '9寸', price: 88 },
          { id: 3, name: '12寸', price: 128 }
        ],
        selectedSpecIndex: 0
      }
    ];
    
    this.setData({ foods });
  },

  // 搜索功能
  onSearch(e) {
    const keyword = e.detail.value;
  
    if (!keyword.trim()) {
      // 如果搜索词为空，显示当前分类的商品
      this.filterFoodsByCategory(this.data.activeCategory);
      return;
    }
    
    // 修复：添加空值检查，避免访问 undefined 属性
    const filteredFoods = this.data.foods.filter(item => 
      (item.name && item.name.includes(keyword)) || 
      (item.description && item.description.includes(keyword)) ||
      (item.tags && Array.isArray(item.tags) && item.tags.some(tag => tag && tag.includes(keyword)))
    );
    
    this.setData({ 
      filteredFoods,
      currentCategoryName: `搜索"${keyword}"`
    });
  },
});