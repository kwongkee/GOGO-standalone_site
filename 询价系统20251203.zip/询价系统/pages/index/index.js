// 获取应用实例
var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    // 当前轮播图索引
    currentSwiperIndex: 0,
    // 自动播放
    autoplay: false,
    // 自动播放间隔
    interval: 3000,
    // 滑动动画时长
    duration: 500
  },
 
  onLoad() {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_navbar_info','id':1}).then(res => {
      t.setData({
				data:res.data.data,
				head:res.data.head
      });
    });
  },
  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },
  homenav(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/index/index',
    });
  },
  bindnav(e){
    let t = this;
    if(e.currentTarget.dataset.type2==3){
      wx.switchTab({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==2){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==1){
      if(wx.getStorageSync('sns_openid')==''){
        wx.redirectTo({
          url:"/pages/login/index"
        });
        return false;
      }
      t.subscribeMsg();
      wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
      wx.navigateTo({
        url: '/pages/agreement/index',
      });
		}
		else if(e.currentTarget.dataset.type2==0){
			if(e.currentTarget.dataset.have_children==0){
        if(e.currentTarget.dataset.tz_type==0 || e.currentTarget.dataset.tz_type==2 || e.currentTarget.dataset.tz_type==3){
          //跳转第三方链接
          wx.setStorageSync('agreement_url', e.currentTarget.dataset.url);
          wx.navigateTo({
            url: '/pages/agreement/index',
          });  
        }else if(e.currentTarget.dataset.tz_type==1){
          //小程序内跳转
          wx.navigateTo({
            url: e.currentTarget.dataset.url,
          })
        }
			}
			else if(e.currentTarget.dataset.have_children==1){
				//跳转子页
				wx.navigateTo({
					url: '/pages/my_page/children/index?id='+e.currentTarget.dataset.id,
				});
			}
		}
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
	},
	// 轮播图切换事件
  swiperChange: function(e) {
    this.setData({
      currentSwiperIndex: e.detail.current
    });
  },

  // 上一张
  swiperPrev: function() {
    const { currentSwiperIndex, data } = this.data;
    const newIndex = currentSwiperIndex === 0 ? data.length - 1 : currentSwiperIndex - 1;
    
    this.setData({
      currentSwiperIndex: newIndex
    });
  },

  // 下一张
  swiperNext: function() {
    const { currentSwiperIndex, data } = this.data;
    const newIndex = currentSwiperIndex === data.length - 1 ? 0 : currentSwiperIndex + 1;
    
    this.setData({
      currentSwiperIndex: newIndex
    });
  }
})
