// pages/my_page/activity/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  //检测有无登录微信小程序
  goto_login: function(){
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  // 跳转到预约免费食页面
  navigateToReserve: function() {
    // this.goto_login();
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    wx.navigateTo({
      url: '/pages/my_page/reserve/index'
    })
  },

  //管理活动页面
  navigateToActivityManage: function(e) {
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
    
    wx.navigateTo({
      url: '/pages/my_page/activity_manage/index?type='+e.currentTarget.dataset.type
    });

  },

  // 跳转到好食才付款页面
  navigateToPayAfter: function() {
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    wx.navigateTo({
      url: '/pages/my_page/payafter/index'
    })
  },

  // 跳转到买一送一页面
  navigateToBuyOne: function() {
    // this.goto_login();

    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/my_page/activity/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
    
    wx.navigateTo({
      url: '/pages/my_page/buyone/index'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})