// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({
  data: {
    type:1,
    // 实体店数据
    selectedStore: null,
    showStoreModal: false,
    // 实体店当前活动的时间
    minDate: '2025-12-01',
    maxDate: '2025-12-31',
    selectedDate: 0,
    selected_date: '',
    shop_date:[],
    // 产品数据 - 包含ID和其他信息
    productIndex: -1,
    selectedProduct: null
  },

  // 计算表单是否完整
  isFormComplete: function() {
    const { selectedStore, selected_date, selectedProduct } = this.data
    return selectedStore && selected_date && selectedProduct
  },

  // 打开店铺选择模态框
  toggleStoreModal: function() {
    this.setData({
      showStoreModal: true
    })
  },

  // 隐藏店铺选择模态框
  hideStoreModal: function() {
    this.setData({
      showStoreModal: false
    })
  },

  // 阻止事件冒泡
  stopPropagation: function() {
    // 空函数，仅用于阻止事件冒泡
  },

  // 选择店铺
  selectStore: function(e) {
    let t = this;
    const store = e.currentTarget.dataset.store;

    t.setData({
      selectedStore: store,
      showStoreModal: false
    });

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_shop_activity_info','id':store.id,'type':t.data.type,'sort':1}).then(res => {
      t.setData({
        shop_date:res.data.data.shop_date,
      });
    });
  },

  // 选择日期
  bindDateChange: function(e) {
    let t = this;

    t.setData({
      selectedDate: e.detail.value,
      selected_date: t.data.shop_date[e.detail.value]
    })
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_shop_activity_info','id':t.data.selectedStore.id,'type':t.data.type,'selected_date':t.data.selected_date,'sort':2}).then(res => {
      t.setData({
        products:res.data.data.goods
      });
    });
  },

  // 选择产品
  bindProductChange: function(e) {
    const index = parseInt(e.detail.value)
    const selectedProduct = this.data.products[index]

    this.setData({
      productIndex: index,
      selectedProduct: selectedProduct
    })
  },

  // 跳转到产品详情页 - 获取所有选择的数据
  navigateToProductDetail: function() {
    if (!this.isFormComplete()) {
      wx.showToast({
        title: '请完善所有信息',
        icon: 'none'
      })
      return
    }

    const { selectedStore, selected_date, selectedProduct } = this.data
    
    // 获取所有选择的数据
    const selectedData = {
      store: {
        id: selectedStore.id,
        name: selectedStore.name,
        address: selectedStore.address,
        phone: selectedStore.phone
      },
      date: selected_date,
      product: {
        id: selectedProduct.goods_id,
        name: selectedProduct.goods_name,
      },
      timestamp: new Date().getTime()
    }

    console.log('完整的选择数据:', selectedData)
    
    // 方式1: 直接跳转到产品详情页并传递参数
    // this.navigateWithParams(selectedData)
    
    // 方式2: 先显示确认信息，再跳转
    this.showConfirmAndNavigate(selectedData)
  },

  // 方式1: 直接跳转并传递参数
  navigateWithParams: function(selectedData) {
    // 将对象转换为JSON字符串进行传递
    const params = encodeURIComponent(JSON.stringify(selectedData))
    
    wx.navigateTo({
      url: `/pages/productDetail/productDetail?data=${params}`,
      success: function(res) {
        console.log('跳转成功')
      },
      fail: function(err) {
        console.error('跳转失败:', err)
        // 如果页面不存在，显示成功提示
        wx.showToast({
          title: '选择完成！',
          icon: 'success',
          duration: 2000
        })
      }
    })
  },

  // 方式2: 显示确认信息后再跳转
  showConfirmAndNavigate: function(selectedData) {
    var t = this;
    const { store, date, product } = selectedData
    
    wx.showModal({
      title: '确认选择',
      content: `店铺: ${store.name}\n日期: ${date}\n产品: ${product.name}`,
      confirmText: '确认',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          // 记录用户参与活动，并完成指定任务
          u.post(app.globalData.url+'api/miniprogram/index',{'method':'join_activity','type':t.data.type,'store_id':store.id,'date':date,'product_id':product.id,'uid':wx.getStorageSync('uid'),'sns_openid':wx.getStorageSync('sns_openid')}).then(res => {
            if (res.data.code==0) {
              // 参与活动成功，问用户跳转活动管理页，还是继续参与活动
              wx.showModal({
                title:'提示',
                content:res.data.msg,
                cancelText:'继续参与',
                confirmText:'管理活动',
                success(res2){
                  if (res2.confirm) {
                    wx.redirectTo({url:'/pages/my_page/activity_manage/index'});
                  }else if(res2.cancel){
                    wx.redirectTo({url:'/pages/my_page/activity/index'});
                  }
                }
              });
            }
          });
        }
      }
    })
  },

  // 获取当前选择数据的函数（可以在其他地方调用）
  getSelectedData: function() {
    const { selectedStore, selectedDate, selectedProduct } = this.data
    
    if (!this.isFormComplete()) {
      return null
    }

    return {
      storeId: selectedStore.id,
      storeName: selectedStore.name,
      date: selectedDate,
      productId: selectedProduct.id,
      productName: selectedProduct.name
    }
  },

  onLoad: function() {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_activity_info','type':t.data.type}).then(res => {
      t.setData({
        stores:res.data.data
      });
    });
  },

  onShow: function() {
    // 页面显示时，可以检查当前选择状态
    const selectedData = this.getSelectedData()
    if (selectedData) {
      console.log('当前选择状态:', selectedData)
    }
  }
})