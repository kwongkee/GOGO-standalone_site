// 获取应用实例
var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    show: 0,
    barHeight: 20, //  顶部状态栏高度
    navBarHeight: 66, // 顶部高度
    background:'',
    username:'请登录',
    gogoId:'暂无',
    is_follow:0,
    auths:'',
    headPic:'https://shop.gogo198.cn/collect_website/public/uploads/centralize/website_index/64d357f7c4a70.jpg',
    // 当前轮播图索引
    currentSwiperIndex: 0,
    // 自动播放
    autoplay: false,
    // 自动播放间隔
    interval: 3000,
    // 滑动动画时长
    duration: 500
  },
 
  onLoad(options) {
    let t = this;
    
    let agentid = options.agentid;//分销商推广二维码
    wx.setStorageSync('agentid', agentid);
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_gather_info'}).then(res => {
      wx.setStorageSync('template_id',res.data.info.template_id);
      t.setData({
        background:res.data.info.color_inner
      });
    });
    if(wx.getStorageSync('sns_openid')!=''){
      //获取微信信息
      wx.getUserInfo({
        success: function (res) {
          t.setData({
            show:1,
            username: res.userInfo.nickName
          });
          // 将用户信息存入本地缓存
          wx.setStorageSync('userInfo', res.userInfo);
        }
      });
      //每加载一次就设置平台用户公众号openid和判断有无关注公众号，获取有无权限->“管理选品”
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'set_user_openid','sns_openid':wx.getStorageSync('sns_openid'),'unionid':wx.getStorageSync('unionid'),'uid':wx.getStorageSync('uid'),'agentid':wx.getStorageSync('agentid')}).then(res => {
        t.setData({
          gogoId:res.data.gogoId,
          username:res.data.username,
          is_follow:res.data.follow,
          auths:res.data.auths
        });
      });
    }
    if(wx.getStorageSync('openid')!=''){
      t.setData({
        is_follow:1
      })
    }

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_navbar_info','id':17}).then(res => {
      t.setData({
			data:res.data.data,
			head:res.data.head
      });
    });
  },
  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },
  homenav(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/index/index',
    });
  },
  //跳转登录页
  headClick(){
    let t = this;
  
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
    }else{
      wx.getUserProfile({
        desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
        success: (res) => {
          let rawData = JSON.parse(res.rawData);
          
          this.setData({
            headPic: rawData.avatarUrl // 设置用户头像URL
          });
        },
        fail: (err) => {
          console.error('Failed to get user profile:', err);
        }
      });
    }
  },
  //导航条跳转
  navClick(data){
    let t = this;
    let key = data.currentTarget.dataset.key;

    //先判断是否已登录
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    //跳转到指定页面
    if(key=='customer_center'){
      wx.setStorageSync('agreement_url','https://www.gogo198.net/?s=member/member_center&key='+key+'&mid='+wx.getStorageSync('uid'))
    }
    else if(key=='goods_center'){
      //商品管理
      wx.navigateTo({
        url: "/pages/my_page/manage_goods/home",
      });
      return false;
    }
    else{
      wx.setStorageSync('agreement_url','https://www.gogo198.net/?s=members/member_center&key='+key+'&mid='+wx.getStorageSync('uid'))
    }
    wx.navigateTo({
      url:"/pages/agreement/index"
    });
  },
  //跳转客服
  kefuClick(data){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
    }else{
      wx.setStorageSync('agreement_url','https://boss.gogo198.cn/?s=index/member_login&member_id='+wx.getStorageSync('uid'))
      wx.navigateTo({
        url:"/pages/agreement/index"
      });
    }
  },
  bindnav(e){
    let t = this;
    if(e.currentTarget.dataset.type2==3){
      wx.switchTab({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==2){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==1){
      if(wx.getStorageSync('sns_openid')==''){
        wx.redirectTo({
          url:"/pages/login/index"
        });
        return false;
      }
      t.subscribeMsg();
      wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
      wx.navigateTo({
        url: '/pages/agreement/index',
      });
		}
		else if(e.currentTarget.dataset.type2==0){
			if(e.currentTarget.dataset.have_children==0){
        if(e.currentTarget.dataset.tz_type==0){
          //跳转第三方链接
          wx.setStorageSync('agreement_url', e.currentTarget.dataset.url);
          wx.navigateTo({
            url: '/pages/agreement/index',
          });  
        }else if(e.currentTarget.dataset.tz_type==1){
          //小程序内跳转
          wx.navigateTo({
            url: e.currentTarget.dataset.url,
          })
        }
			}
			else if(e.currentTarget.dataset.have_children==1){
				//跳转子页
				wx.navigateTo({
					url: '/pages/my_page/children/index?id='+e.currentTarget.dataset.id,
				});
			}
		}
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
	},
	// 轮播图切换事件
  swiperChange: function(e) {
    this.setData({
      currentSwiperIndex: e.detail.current
    });
  },

  // 上一张
  swiperPrev: function() {
    const { currentSwiperIndex, data } = this.data;
    const newIndex = currentSwiperIndex === 0 ? data.length - 1 : currentSwiperIndex - 1;
    
    this.setData({
      currentSwiperIndex: newIndex
    });
  },

  // 下一张
  swiperNext: function() {
    const { currentSwiperIndex, data } = this.data;
    const newIndex = currentSwiperIndex === data.length - 1 ? 0 : currentSwiperIndex + 1;
    
    this.setData({
      currentSwiperIndex: newIndex
    });
  }
})
