const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}

const dd = n => {
  console.log(n);return false;
}

const msg = n =>{
  wx.showToast({
    title: n, // 提示的内容
    icon: "none", // 图标，默认success
    duration: 3000, // 提示的延迟时间，默认1500
    mask: false, // 是否显示透明蒙层，防止触摸穿透
    success: function () {
        
    },
  })
}

function post(url,data){
  return new Promise(function(resolve,reject){
      wx.request({
        url: url,
        data: data,
        header: {
          // 'content-type': 'application/json' // 默认值
         "Content-Type": "application/x-www-form-urlencoded" //用于post
        },
        method: 'POST',
        success: function (res) {
          msg(res.data.msg);
          if(res.data.code==0){
            resolve(res);
          }
        },
        fail: function (res) { },
        complete: function (res) { },
      });
  })
}

module.exports = {
  formatTime,
  dd:dd,
  msg:msg,
  post:post,
}
