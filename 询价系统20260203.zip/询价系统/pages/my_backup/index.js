var u = require('../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: 0,
    barHeight: 20, //  顶部状态栏高度
    navBarHeight: 66, // 顶部高度
    background:'',
    username:'请登录',
    gogoId:'暂无',
    is_follow:0,
    auths:'',
    headPic:'https://shop.gogo198.cn/collect_website/public/uploads/centralize/website_index/64d357f7c4a70.jpg'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    let agentid = options.agentid;//分销商推广二维码
    wx.setStorageSync('agentid', agentid);
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_gather_info'}).then(res => {
      wx.setStorageSync('template_id',res.data.info.template_id);
      t.setData({
        background:res.data.info.color_inner
      });
    });
    if(wx.getStorageSync('sns_openid')!=''){
      //获取微信信息
      wx.getUserInfo({
        success: function (res) {
          t.setData({
            show:1,
            username: res.userInfo.nickName
          });
          // 将用户信息存入本地缓存
          wx.setStorageSync('userInfo', res.userInfo);
        }
      });
      //每加载一次就设置平台用户公众号openid和判断有无关注公众号，获取有无权限->“管理选品”
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'set_user_openid','sns_openid':wx.getStorageSync('sns_openid'),'unionid':wx.getStorageSync('unionid'),'uid':wx.getStorageSync('uid'),'agentid':wx.getStorageSync('agentid')}).then(res => {
        t.setData({
          gogoId:res.data.gogoId,
          username:res.data.username,
          is_follow:res.data.follow,
          auths:res.data.auths
        });
      });
    }
    if(wx.getStorageSync('openid')!=''){
      t.setData({
        is_follow:1
      })
    }
  },
  homenav(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/home/index',
    });
  },
  //跳转登录页
  headClick(){
    let t = this;
  
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
    }else{
      wx.getUserProfile({
        desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
        success: (res) => {
          let rawData = JSON.parse(res.rawData);
          
          this.setData({
            headPic: rawData.avatarUrl // 设置用户头像URL
          });
        },
        fail: (err) => {
          console.error('Failed to get user profile:', err);
        }
      });
    }
  },
  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },

  //导航条跳转
  navClick(data){
    let t = this;
    let key = data.currentTarget.dataset.key;

    //先判断是否已登录
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }

    //跳转到指定页面
    if(key=='customer_center'){
      wx.setStorageSync('agreement_url','https://www.gogo198.net/?s=member/member_center&key='+key+'&mid='+wx.getStorageSync('uid'))
    }
    else if(key=='goods_center'){
      //商品管理
      wx.navigateTo({
        url: "/pages/my_page/manage_goods/home",
      });
      return false;
    }
    else{
      wx.setStorageSync('agreement_url','https://www.gogo198.net/?s=members/member_center&key='+key+'&mid='+wx.getStorageSync('uid'))
    }
    wx.navigateTo({
      url:"/pages/agreement/index"
    });
    
    // if(key=='basic'){
    //   //跳转基本信息页
    //   if(wx.getStorageSync('sns_openid')==''){
    //     wx.navigateTo({
    //       url:"/pages/login/index"
    //     });
    //   }else{
    //     t.subscribeMsg();
    //     wx.navigateTo({
    //       url:"/pages/my_page/basic_info/index"
    //     });
    //   }
    // }
    // else if(key=='order'){
    //   //我的订单页
    //   if(wx.getStorageSync('sns_openid')==''){
    //     wx.navigateTo({
    //       url:"/pages/login/index"
    //     });
    //   }
    //   else{
    //     t.subscribeMsg();
    //     wx.setStorageSync('agreement_url', 'https://gather.gogo198.cn/?s=gather/parcel_order&miniprogram=1&uid='+wx.getStorageSync('uid'));
    //     wx.navigateTo({
    //       url: '/pages/agreement/index',
    //     })
    //   }
    // }
    // else if(key=='distr'){
    //   //跳转我的分销页
    //   if(wx.getStorageSync('sns_openid')==''){
    //     wx.navigateTo({
    //       url:"/pages/login/index"
    //     });
    //   }else{
    //     t.subscribeMsg();
    //     wx.navigateTo({
    //       url:"/pages/my_page/distribute_info/index"
    //     });
    //   }
    // }
    // else if(key=='merch'){
    //   //商家服务页
    //   if(wx.getStorageSync('sns_openid')==''){
    //     wx.navigateTo({
    //       url:"/pages/login/index"
    //     });
    //   }else{
    //     t.subscribeMsg();
    //     wx.navigateTo({
    //       url:"/pages/my_page/merch_info/index"
    //     });
    //   }
    // }
  },

  //跳转客服
  kefuClick(data){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
    }else{
      wx.setStorageSync('agreement_url','https://boss.gogo198.cn/?s=index/member_login&member_id='+wx.getStorageSync('uid'))
      wx.navigateTo({
        url:"/pages/agreement/index"
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})