const { dd } = require('../../utils/util.js');
var u = require('../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_login:0,
    auth_id:0
  },

  //授权登录
  authlogin(e){
    let t = this;
    wx.removeStorage('auth_id');
    u.post(app.globalData.url+'api/miniprogram/index',{'uid':wx.getStorageSync('uid'),'auth_id':t.data.auth_id,'status':1,'method':'auth_login'}).then(res => {
      t.setData({
        is_login:1
      });
    });
  },
  //取消授权登录
  noauthlogin(e){
    let t = this;
    wx.removeStorage('auth_id');
    u.post(app.globalData.url+'api/miniprogram/index',{'uid':wx.getStorageSync('uid'),'auth_id':t.data.auth_id,'status':-1,'method':'auth_login'}).then(res => {
      t.setData({
        is_login:-1
      });
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    t.setData({
      auth_id:options.auth_id
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})