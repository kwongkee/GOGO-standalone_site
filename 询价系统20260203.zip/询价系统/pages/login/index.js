// pages/login/index.js
var u = require('../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    reg_array:['手机号码','电子邮箱'],
    reg_index:[1,2],
    reg_act:0,
    background:'#fff',
    send_msg:'发送',
    countdown: 60,
    timer: null,
    agreement_title:[],
    agreement_link:[],
    check_agreement:0
  },

  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },

  //一键登录
  getPhoneNumber (e) {
    let t = this;
    let phone_code = e.detail.code;
    if(t.data.agreement_title.length!=''){
      if(t.data.check_agreement==0){
        let content = '';
        for(let i=0;i<t.data.agreement_title.length;i++){
          content += t.data.agreement_title[i];
        }
        wx.showToast({
          title: '请勾选同意直邮易'+content,
          icon:'none'
        });
        return false;
      }
    }
    wx.login({
      success(res){
        if(res.code){
          let data2 = {'code':res.code,'method':'get_openid'};
          u.post(app.globalData.url+'api/miniprogram/index',data2).then(res2 => {
            u.post(app.globalData.url+'api/miniprogram/index',{'method':'phone_login','code':phone_code,'openid':res2.data.openid,'unionid':res2.data.unionid}).then(res3 => {
              if(res3.data.code==0){
                wx.setStorageSync('uid', res3.data.uid);
                wx.setStorageSync('sns_openid', res3.data.sns_openid);
                wx.setStorageSync('unionid', res3.data.unionid);
                t.subscribeMsg();
                if(wx.getStorageSync('auth_id')!=''){
                  if(wx.getStorageSync('type_id')!=''){
                    //授权进来的进入回公用页(agreement)
                    wx.redirectTo({
                      url:"/pages/agreement/index?id="+wx.getStorageSync('auth_id')+"&typeid="+wx.getStorageSync('type_id')
                    });
                  }else{
                    //授权进来的进入回授权页
                    wx.redirectTo({
                      url:"/pages/authlogin/index?auth_id="+wx.getStorageSync('auth_id')
                    });
                  }
                }else{
                  if(wx.getStorageSync('to_pages')!=''){
                    //跳转到微信小程序内指定页面
                    wx.reLaunch({
                      url:wx.getStorageSync('to_pages')
                    });
                  }else{
                    //跳转到我的+
                    wx.reLaunch({
                      url:"/pages/my/index"
                    });
                  }
                }
              }
            });
          });
        }
      }
    });
  },

  //勾选协议
  checkradio(e){
    let t = this;
    if(t.data.check_agreement==0){
      t.setData({
        check_agreement:1
      })
    }else{
      t.setData({
        check_agreement:0
      })
    }
    
  },

  agree_navgator(r){
    wx.setStorageSync('agreement_url', r.currentTarget.dataset.url);
  },
  nologin(e){
    wx.reLaunch({
      url: '/pages/my/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_agreement','id':1}).then(res => {
      t.setData({
        agreement_title:res.data.info.content.title,
        agreement_link:res.data.info.content.link,
        logo:res.data.logo
      });
    });
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_gather_info'}).then(res => {
      wx.setStorageSync('template_id',res.data.info.template_id);
    });
    
    let res= decodeURIComponent(options.scene);//扫码进来的id
    let typeid = '';
    let auth_id = '';
    if(res!='undefined'){
      //扫码进入
      typeid = res.split("=")[2];//登录类型
      auth_id = '';
      if(typeid>0){
        auth_id = res.split("=")[1];//授权登录的id
        auth_id = auth_id.split("&type")[0];
      }else{
        auth_id = res.split("=")[1];//授权登录的id
      }
    }else{
      //模板进入
      typeid = options.type;//登录类型
      auth_id = options.id;
    }
  
    if(auth_id>0){
      if(typeid>0){
        //*指定业务登录
        if(wx.getStorageSync('uid')!=''){
          //已登录跳转去公用页（agreement）
          wx.redirectTo({
            url:"/pages/agreement/index?id="+auth_id+"&typeid="+typeid
          });
        }else{
          //未登录
          wx.setStorageSync('auth_id', auth_id);
          wx.setStorageSync('type_id', typeid);
        }
      }else{
        //*授权登录
        if(wx.getStorageSync('uid')!=''){
          //已登录跳转去授权页
          wx.redirectTo({
            url:"/pages/authlogin/index?auth_id="+auth_id
          });
        }else{
          //未登录
          wx.setStorageSync('auth_id', auth_id);
        }
      }
    }
  },

  //登录方式(废弃)
  reg_method(data){
    this.setData({
      reg_act:data.detail.value,
      number:''
    });
    // u.dd(data);
  },

  //发送验证码(废弃)
  sendcode(data){
    let t = this;
    let reg_act = t.data.reg_act;
    let number = t.data.number;
    if(number=='' || typeof(number)=='undefined'){
        u.msg('请输入登录账号');
        return false;
    }

    if(t.data.send_msg!='发送'){
      return false;
    }
    
    //开始发送消息
    u.post(app.globalData.url+'api/miniprogram/index',{'reg_act':reg_act,'number':number,'method':'send_code'}).then(res => {
      t.startCountdown();
      t.setData({
        login_code:res.data.code2
      });
    });
  },

  //发送后60秒倒数(废弃)
  startCountdown: function () {
    if (this.data.timer) {
      clearInterval(this.data.timer);
    }
    this.setData({ countdown: 60 });
    this.data.timer = setInterval(() => {
      if (this.data.countdown === 0) {
        clearInterval(this.data.timer);
        this.setData({ countdown: 60, timer: null,send_msg:'发送' });
      } else {
        let countdown = this.data.countdown - 1;
        this.setData({ countdown: countdown,send_msg:'发送('+countdown+')' });
      }
    }, 1000);
  },

  //手机号+邮箱号(废弃)
  getInputValue(data){
    let t = this;
    t.setData({
      number:data.detail.value
    });
  },

  //表单提交(废弃)
  formSubmit(data){
    let t = this;
    data.detail.value['method'] = 'login';
    data.detail.value['login_code'] = t.data.login_code;
  
    if(wx.getStorageSync('sns_openid')==''){
      //获取openid
      wx.login({
        success(res){
          if(res.code){
            let data2 = {'code':res.code,'method':'get_openid'};
            u.post(app.globalData.url+'api/miniprogram/index',data2).then(res2 => {
              data.detail.value['openid'] = res2.data.openid;
              data.detail.value['unionid'] = res2.data.unionid;
              u.post(app.globalData.url+'api/miniprogram/index',data.detail.value).then(res3 => {
                if(res3.data.code==0){
                  wx.setStorageSync('uid', res3.data.uid);
                  wx.setStorageSync('sns_openid', res3.data.sns_openid);
                  wx.setStorageSync('unionid', res3.data.unionid);
                  wx.redirectTo({
                    url:'/pages/my/index'
                  });
                }
              });
            });
          }
        }
      });
    }else{
      //已有openid
      data.detail.value['openid'] = wx.getStorageSync('sns_openid');
      u.post(app.globalData.url+'api/miniprogram/index',data.detail.value).then(res => {
        if(res.data.code==0){
          wx.setStorageSync('uid', res.data.uid);
          wx.setStorageSync('sns_openid', res.data.sns_openid);
          wx.redirectTo({
            url:'/pages/my/index'
          });
        }
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})