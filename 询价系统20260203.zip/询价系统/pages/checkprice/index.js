// pages/checkprice/index.js
var u = require('../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    merch_status:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
      let t = this;
    
      if(wx.getStorageSync('uid') == ''){
          wx.redirectTo({
            url: '/pages/login/index',
          })
      }
      u.dd(app.globalData.account);
      if(app.globalData.account==''){
        let data = {'method':'get_info','openid':wx.getStorageSync('sns_openid')};
        u.post(app.globalData.url+'api/miniprogram/index',data).then(res => {
          app.globalData.account = res.data.acc;
          t.setData({
            merch_status:app.globalData.account.merch_status
          });
        });
      }else{
        t.setData({
          merch_status:app.globalData.account.merch_status
        });
      }
     
      // wx.login({
      //   success(res){
      //     if(res.code){
      //       let data = {'code':res.code,'method':'get_openid'};
            // u.post(app.globalData.url+'api/miniprogram/index',data).then(res => {
            //   u.dd(res);
            // });
      //     }
      //   }
      // });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})