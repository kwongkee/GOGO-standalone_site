// 获取应用实例
var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    link:[]
  },
 
  onLoad() {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'crossborder_info','type':1}).then(res => {
      for (let i = 0; i < res.data.info2.content.length; i++) {
        WxParse.wxParse('content' + i, 'html', res.data.info2.content[i], t);
        if (i === res.data.info2.content.length - 1) {
          WxParse.wxParseTemArray("content",'content', res.data.info2.content.length, t);
        }
      }
      
      t.setData({
        link:res.data.info,
        info2:res.data.info2
      });
      // WxParse.wxParse('article', 'html', res.data.info2.content, t, 5);
    });
  },
  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },
  homenav(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/home/index',
    });
  },
  bindnav(e){
    let t = this;
    if(e.currentTarget.dataset.type2==3){
      wx.switchTab({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==2){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==1){
      if(wx.getStorageSync('sns_openid')==''){
        wx.redirectTo({
          url:"/pages/login/index"
        });
        return false;
      }
      t.subscribeMsg();
      wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
      wx.navigateTo({
        url: '/pages/agreement/index',
      });
    }
    // if(wx.getStorageSync('sns_openid')==''){
    //   wx.redirectTo({
    //     url:"/pages/login/index"
    //   });
    //   return false;
    // }
    // t.subscribeMsg();
    // wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
    // wx.navigateTo({
    //   url: '/pages/agreement/index',
    // })
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
