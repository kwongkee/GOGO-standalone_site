//小程序外扫码进入、登录时的协议可调用该页面
var u = require('../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    // console.log(options,123);
    //授权进入
    let id = options.id;//跳转进来
    let type = options.typeid;//跳转进来
    let tz_url = options.url;

    //商品分享
    var goods_id = 0;//分享商品id
    var campaign_id = 0;//活动id
    var share_uid = 0;//分享人id
    if (options.scene) {
      // 2. 手动解析 scene 字符串
      const sceneParams2 = decodeURIComponent(options.scene);
      const sceneParams = t.decodeScene2(sceneParams2);
      
      goods_id = sceneParams.gid;
      share_uid = sceneParams.uid;
      campaign_id = sceneParams.cid;
      console.log('扫码参数:', goods_id, share_uid, campaign_id);
    } else {
        // 从分享卡片进入的情况
        goods_id = options.gid;
        share_uid = options.uid;
        campaign_id = options.cid;
        console.log('分享参数:', goods_id, share_uid, campaign_id);
    }

    if(id>0 && type>0){
      //授权进入
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_business_url','type':type,'id':id}).then(res => {
        t.setData({
          url: res.data.url+"&uid="+wx.getStorageSync('uid')
        });
      });
    }
    else if(goods_id>0){
      //商品分享
      t.setData({
        url: "https://www.gogo198.cn/goods-" + goods_id + ".html?campaign_id="+campaign_id+"&share_uid="+share_uid
      });
    }
    else{
      //授权登录
      t.setData({
        url: wx.getStorageSync('agreement_url')
      });
    }

    if(tz_url!=''){
      t.setData({
        // url:'https://qr.shouqianba.com/20051201002009494485'
        url:decodeURIComponent(tz_url)
      });
    }
  },

  // 解析 scene 字符串的方法
  decodeScene2(sceneStr) {
    // 根据 PHP 端的格式来解析
    // 如果 PHP 端是 "gid=1&cid=2&uid=3"
    const params = {};
    const pairs = sceneStr.split('&');
    
    pairs.forEach(pair => {
        const [key, value] = pair.split('=');
        if (key && value !== undefined) {
            params[key] = value;
        }
    });
    
    return params;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    // wx.switchTab({
    //   url: '/pages/my/index',
    // })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})