// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();
var WxParse = require('../../../wxParse/wxParse.js');

Page({
  data: {
    // 活动基本信息
    // activityData2: {
    //   type: '预约免费食',
    //   status: '进行中',
    //   statusClass: 'status-processing',
    //   participateTime: '2025-01-15 14:30:25',
    //   validUntil: '2025-12-31 23:59:59',
    //   quota: '100/200人'
    // },
    
    // 实体店信息
    // storeData2: {
    //   name: '朝阳门店',
    //   address: '北京市朝阳区朝阳门外大街18号',
    //   phone: '010-12345678',
    //   businessHours: '09:00-22:00'
    // },
    
    // 产品信息
    // productData2: {
    //   name: '招牌红烧肉',
    //   description: '精选五花肉，慢火炖煮，肥而不腻，入口即化',
    //   price: '¥68',
    //   image: '' // 可以设置图片URL
    // },
    
    // 任务数据
    // taskData2: [
    //   {
    //     id: 1,
    //     name: '分享产品主题图',
    //     icon: '🖼️',
    //     expanded: false,
    //     allCompleted: false,
    //     conditions: [
    //       { name: '分享被查看', description: '需有3次以上查看记录', completed: true },
    //       { name: '分享被加购', description: '需有1次加购记录', completed: false },
    //       { name: '分享被转发', description: '需有2次转发记录', completed: true },
    //       { name: '分享被评论', description: '需有1条以上评论', completed: false },
    //       { name: '分享被点赞', description: '需有5次以上点赞', completed: true }
    //     ]
    //   },
    // ],
    
    // 已完成任务数量
    // completedTaskCount2: 0,
    // taskCount2: 0

    //海报图
    poster_img:'',
    show_poster:0,

    highlightIndex: 0, // 当前高亮任务索引
    showTutorialModal: false, // 控制教程弹窗显示
    tutorialData: {}, // 教程数据
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack({
      delta: 1,
      fail:function(){
        wx.redirectTo({
          url: '/pages/my_page/activity/index',
        });
      }
    });
  },

  //预览地图图片
  previewAddrImage: function(e){
    let t = this;
    wx.previewImage({
      urls:[t.data.storeData.image]
    });
  },

  // 预览产品图片
  previewProductImage: function(e) {
    const urls = this.data.productData.image;
    
    wx.previewImage({
      urls: [urls]
    });
  },

  onLoad: function(options) {
    let t = this;
    
    t.loadDetail(options.id);

    // 添加高亮任务逻辑
    t.calculateHighlightTask();
  },

  loadDetail(id){
    let t = this;
    t.setData({
      campaign_id:id
    });

    //获取活动详情信息
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_activity_detail','id':id}).then(res => {
      // 处理任务数据，添加高亮标识
      let taskData = res.data.data.taskData;
      let highlightIndex = 0;
      
      // 计算第一个未完成的任务作为高亮任务
      for(let i = 0; i < taskData.length; i++) {
        if(!taskData[i].allCompleted) {
          highlightIndex = i;
          break;
        }
      }
      
      // 为每个任务添加isHighlight字段
      taskData.forEach((task, index) => {
        task.isHighlight = index === highlightIndex;
      });

      t.setData({
        activityData:res.data.data.activityData,
        completedTaskCount:res.data.data.completedTaskCount,
        productData:res.data.data.productData,
        storeData:res.data.data.storeData,
        taskCount:res.data.data.taskCount,
        //taskData:res.data.data.taskData,
        taskData: taskData,
        highlightIndex: highlightIndex
      });
    });
  },

  // 计算高亮任务
  calculateHighlightTask: function() {
    let t = this;
    let { taskData, highlightIndex } = t.data;
    
    // 检查当前高亮任务是否已完成
    if (highlightIndex >= 0 && highlightIndex < t.data.taskCount) {
      if (taskData[highlightIndex].allCompleted) {
        // 如果已完成，找到下一个未完成的任务
        let newIndex = -1;
        for(let i = highlightIndex + 1; i < taskData.length; i++) {
          if(!taskData[i].allCompleted) {
            newIndex = i;
            break;
          }
        }
        
        // 更新高亮状态
        if (newIndex !== -1) {
          taskData.forEach((task, index) => {
            task.isHighlight = index === newIndex;
          });
          t.setData({
            taskData: taskData,
            highlightIndex: newIndex
          });
        }
      }
    }
  },

  // 查看教程
  viewTutorial: function(e) {
    let t = this;
    let index = e.currentTarget.dataset.index;
    let taskId = e.currentTarget.dataset.id;
    
    // 显示加载中
    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    
    // 请求后端获取教程数据
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_task_tutorial',
      'task_id': taskId
    }).then(res => {
      wx.hideLoading();
      
      if (res.data.code === 0) {
        WxParse.wxParse('task_content', 'html', res.data.data.content, t);
        WxParse.wxParseTem("content",'task_content', 1, t);

        t.setData({
          task_conent:t.data.task_content,
          tutorialData: res.data.data,
          showTutorialModal: true
        });
      } else {
        wx.showToast({
          title: res.data.msg || '获取教程失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      console.log(err);
      wx.hideLoading();
      wx.showToast({
        title: '网络错误',
        icon: 'none'
      });
    });
  },

  // 隐藏教程弹窗
  hideTutorialModal: function() {
    this.setData({
      showTutorialModal: false
    });
  },

  // 继续任务
  continueTask: function() {
    let t = this;
    const { completedTaskCount, taskData } = t.data
    
    if (completedTaskCount === taskData.length) {
      wx.showModal({
        title: '恭喜',
        content: '您已完成所有任务！',
        showCancel: false,
        confirmText: '确定'
      })
    } else {
      // 生成主题图/产品详情页/图文音视频
      wx.showLoading({
        title: '加载中...',
        mask: true
      });
      
      u.post(app.globalData.url+'api/getgoods/get_miniprogram_goods_code',{'id':t.data.campaign_id,'uid':wx.getStorageSync('uid')}).then(res => {
        wx.hideLoading();
      
        t.setData({
          poster_img:res.data.img,
          show_poster:1
        });
      });
    }
  },

  //保存图片
  save_pic(e){
    const { poster_img } = this.data;
      
    if (poster_img) {
      wx.showActionSheet({
        itemList: ['保存到相册'],
        success: (res) => {
          if (res.tapIndex === 0) {
            this.savePoster();
          }
        }
      });
    }
  },

  // 保存海报到相册
  savePoster() {
    const that = this;
    const { poster_img } = this.data;
    
    if (!poster_img) {
      wx.showToast({
        title: '请先生成海报',
        icon: 'none'
      });
      return;
    }

    this.setData({ isSaving: true });

    wx.showLoading({
      title: '保存中...',
      mask: true
    });

    // 获取相册授权
    wx.getSetting({
      success: (res) => {
        if (!res.authSetting['scope.writePhotosAlbum']) {
          // 未授权，请求授权
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => {
              that.doSaveImage(poster_img);
            },
            fail: () => {
              wx.hideLoading();
              that.setData({ isSaving: false });
              wx.showModal({
                title: '授权提示',
                content: '需要您授权保存图片到相册',
                confirmText: '去授权',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    wx.openSetting();
                  }
                }
              });
            }
          });
        } else {
          // 已授权，直接保存
          that.doSaveImage(poster_img);
        }
      },
      fail: () => {
        wx.hideLoading();
        that.setData({ isSaving: false });
        wx.showToast({
          title: '保存失败',
          icon: 'error'
        });
      }
    });
  },
  // 1、执行保存图片
  doSaveImage(imagePath) {
    const that = this;
    
    wx.downloadFile({
      url: imagePath,
      success: function(res) {
        wx.hideLoading();
        
        // 下载成功，res.tempFilePath 是临时文件路径
        if (res.statusCode === 200) {
          // 4. 检查保存权限并保存到相册
          that.checkAndSaveImage(res.tempFilePath);
        } else {
          wx.showToast({
            title: '下载失败，请重试',
            icon: 'none'
          });
        }
      },
      fail: function(err) {
        wx.hideLoading();
        console.error('下载图片失败:', err);
        wx.showToast({
          title: '保存失败',
          icon: 'error'
        });
      }
    });
  },
  // 2、检查保存权限
  checkAndSaveImage(filePath) {
    const that = this;
    
    // 检查用户是否已授权保存相册权限
    wx.getSetting({
      success: (res) => {
        if (res.authSetting['scope.writePhotosAlbum']) {
          // 已授权，直接保存
          that.saveImageToAlbum(filePath);
        } else {
          // 未授权，请求授权
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => {
              that.saveImageToAlbum(filePath);
            },
            fail: (err) => {
              // 用户拒绝授权时的友好提示
              wx.showModal({
                title: '授权需要',
                content: '需要您授权保存图片到相册，请在设置中开启权限',
                showCancel: false,
                confirmText: '去设置',
                success: (confirmRes) => {
                  if (confirmRes.confirm) {
                    // 打开小程序设置页面（用户可手动开启权限）
                    wx.openSetting({
                      success: (settingRes) => {
                        if (settingRes.authSetting['scope.writePhotosAlbum']) {
                          // 如果用户在设置中开启了权限，可自动重试保存
                          that.saveImageToAlbum(filePath);
                        } else {
                          wx.showToast({
                            title: '未开启权限，保存失败',
                            icon: 'none'
                          });
                        }
                      }
                    });
                  }
                }
              });
            }
          });
        }
      },
      fail: (err) => {
        console.error('权限检查失败:', err);
        wx.showToast({
          title: '系统错误',
          icon: 'none'
        });
      }
    });
  },
  // 3. 保存图片到相册的封装方法
  saveImageToAlbum(filePath) {
    wx.saveImageToPhotosAlbum({
      filePath: filePath,
      success: () => {
        wx.showToast({
          title: '保存成功！已存入相册',
          icon: 'none',
          duration: 2000
        });
      },
      fail: (err) => {
        console.error('保存失败:', err);
        wx.showToast({
          title: '保存失败，请重试',
          icon: 'none'
        });
      }
    });
  },
  //关闭图片
  hideModal(e){
    this.setData({ show_poster: 0 });
  },

  onShow: function() {
    // 页面显示时重新计算任务状态
    // this.calculateCompletedTasks()
  },

  // 切换任务展开/收起
  toggleTask: function(e) {
    const index = e.currentTarget.dataset.index
    const taskData = this.data.taskData
    const task = taskData[index]
    
    // 切换展开状态
    task.expanded = !task.expanded
    
    // 如果展开，只展开当前任务，收起其他任务
    if (task.expanded) {
      taskData.forEach((t, i) => {
        if (i !== index) {
          t.expanded = false
        }
      })
    }
    
    this.setData({
      taskData: taskData
    })
  },

  // 分享活动
  shareActivity: function() {
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成分享海报'],
      success: (res) => {
        if (res.tapIndex === 0) {
          this.shareToFriend()
        } else if (res.tapIndex === 1) {
          this.shareToTimeline()
        } else if (res.tapIndex === 2) {
          this.generatePoster()
        }
      }
    })
  },

  shareToFriend: function() {
    wx.showToast({
      title: '已复制分享链接',
      icon: 'success'
    })
    
    // 可以在这里实现真正的分享逻辑
    // wx.shareAppMessage({ ... })
  },

  shareToTimeline: function() {
    wx.showToast({
      title: '已分享到朋友圈',
      icon: 'success'
    })
  },

  generatePoster: function() {
    wx.showModal({
      title: '生成海报',
      content: '海报生成功能开发中...',
      showCancel: false
    })
  },

  // 查看任务条件详情（长按条件可以查看详情）
  viewConditionDetail: function(e) {
    const { taskIndex, conditionIndex } = e.currentTarget.dataset
    const condition = this.data.taskData[taskIndex].conditions[conditionIndex]
    
    wx.showModal({
      title: condition.name,
      content: condition.description,
      showCancel: false,
      confirmText: '知道了'
    })
  }
})