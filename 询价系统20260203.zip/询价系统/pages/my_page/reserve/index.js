// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({
  data: {
    type: 1,
    // 实体店数据
    selectedStore: null,
    showStoreModal: false,
    // 实体店当前活动的时间
    minDateTime: '',
    maxDateTime: '',
    // 日期选择
    selectedDate: '',
    minDate: '',
    maxDate: '',
    // 时间选择
    selectedTime: '',
    timeStart: '',
    timeEnd: '',
    // 完整日期时间
    selectedDateTime: '',
    selected_date: '',
    shop_date: [],
    // 产品数据 - 包含ID和其他信息
    productIndex: -1,
    selectedProduct: null,
    products: [], // 确保products有初始值
    // 显示产品选择弹窗
    showProductModal: false,
    is_generate: 0 // 是否已生成订购单
  },
  
  // 获取今天日期字符串
  getTodayDateString() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },
  
  // 比较日期大小
  compareDate(date1, date2) {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    return d1.getTime() - d2.getTime();
  },

  // 获取当前日期时间字符串
  getNowDateTimeString() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hour = String(now.getHours()).padStart(2, '0');
    const minute = String(now.getMinutes()).padStart(2, '0');
    const second = String(now.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  },

  // 获取当前时间字符串（HH:mm）
  getNowTimeString() {
    const now = new Date();
    const hour = String(now.getHours()).padStart(2, '0');
    const minute = String(now.getMinutes()).padStart(2, '0');
    return `${hour}:${minute}`;
  },

  // 比较日期时间大小
  compareDateTime(dateTime1, dateTime2) {
    const d1 = new Date(dateTime1);
    const d2 = new Date(dateTime2);
    return d1.getTime() - d2.getTime();
  },

  // 比较时间大小（HH:mm）
  compareTime(time1, time2) {
    const t1 = time1.split(':');
    const t2 = time2.split(':');
    const t1Minutes = parseInt(t1[0]) * 60 + parseInt(t1[1]);
    const t2Minutes = parseInt(t2[0]) * 60 + parseInt(t2[1]);
    return t1Minutes - t2Minutes;
  },

  // 解析时间限制
  parseTimeLimits: function() {
    let t = this;
    const { minDateTime, maxDateTime } = t.data;
    
    if (!minDateTime || !maxDateTime) {
      console.error('时间限制数据不完整');
      return;
    }
    
    // 获取今天的日期和当前时间
    const todayDate = t.getTodayDateString();
    const nowTime = t.getNowTimeString();
    const nowDateTime = t.getNowDateTimeString();
    
    // 解析最小时间
    const minDate = minDateTime.split(' ')[0];
    const minTime = minDateTime.split(' ')[1] || '00:00:00';
    const minHour = parseInt(minTime.split(':')[0]);
    const minMinute = minTime.split(':')[1];
    
    // 解析最大时间
    const maxDate = maxDateTime.split(' ')[0];
    const maxTime = maxDateTime.split(' ')[1] || '23:59:59';
    const maxHour = parseInt(maxTime.split(':')[0]);
    const maxMinute = maxTime.split(':')[1];
    
    // 计算实际的最小日期：取今天和minDate中的较大值
    let actualMinDate = minDate;
    if (t.compareDate(todayDate, minDate) > 0) {
      actualMinDate = todayDate;
    }
    
    // 如果是今天，需要调整开始时间
    let actualTimeStart = `${minHour}:${minMinute}`;
    let actualTimeEnd = `${maxHour}:${maxMinute}`;
    
    if (actualMinDate === todayDate) {
      // 如果今天已经过了活动开始时间，则从当前时间开始
      if (t.compareTime(nowTime, actualTimeStart) > 0) {
        actualTimeStart = nowTime;
      }
      
      // 如果当前时间已经过了活动结束时间，则不能选择今天
      if (t.compareTime(nowTime, actualTimeEnd) > 0) {
        wx.showToast({
          title: '今天的活动时间已结束',
          icon: 'none'
        });
        actualMinDate = ''; // 清空最小日期，用户需要选择明天或之后的日期
      }
    }
    
    // 设置日期限制
    t.setData({
      minDate: actualMinDate || minDate,
      maxDate: maxDate,
      timeStart: actualTimeStart,
      timeEnd: actualTimeEnd,
      // 如果是最小日期是今天，设置默认选中的日期为今天
      selectedDate: actualMinDate === todayDate ? todayDate : actualMinDate
    });
    
    console.log('时间限制设置完成:', {
      nowDateTime: nowDateTime,
      minDateTime: t.data.minDateTime,
      maxDateTime: t.data.maxDateTime,
      actualMinDate: actualMinDate,
      maxDate: maxDate,
      timeStart: t.data.timeStart,
      timeEnd: t.data.timeEnd
    });
  },
  
  // 选择日期
  bindDateChange: function(e) {
    const selectedDate = e.detail.value;
    let t = this;
    
    console.log('选择的日期:', selectedDate);
    
    // 验证选择的日期不能早于今天
    const todayDate = t.getTodayDateString();
    if (t.compareDate(selectedDate, todayDate) < 0) {
      wx.showToast({
        title: '不能选择今天之前的日期',
        icon: 'none'
      });
      
      // 重置为今天或最小允许日期
      t.setData({
        selectedDate: t.data.minDate,
        selectedTime: '',
        selectedDateTime: ''
      });
      return;
    }
    
    // 获取当前时间
    const nowTime = t.getNowTimeString();
    const nowDateTime = t.getNowDateTimeString();
    
    // 如果是今天，需要调整时间范围
    if (selectedDate === todayDate) {
      let timeStart = t.data.timeStart;
      let timeEnd = t.data.timeEnd;
      
      // 如果当前时间晚于活动开始时间，则从当前时间开始
      if (t.compareTime(nowTime, timeStart) > 0) {
        timeStart = nowTime;
      }
      
      // 如果当前时间已经晚于活动结束时间，则不能选择今天
      if (t.compareTime(nowTime, timeEnd) > 0) {
        wx.showToast({
          title: '今天的活动时间已结束，请选择其他日期',
          icon: 'none'
        });
        t.setData({
          selectedDate: '',
          selectedTime: '',
          selectedDateTime: ''
        });
        return;
      }
      
      t.setData({
        timeStart: timeStart,
        timeEnd: timeEnd
      });
    }
    
    t.setData({
      selectedDate: selectedDate,
      selectedTime: '', // 清空时间选择
      selectedDateTime: '' // 清空完整日期时间
    });
    
    // 如果选择的日期是活动开始日期，需要调整时间范围
    const minDate = t.data.minDateTime.split(' ')[0];
    const maxDate = t.data.maxDateTime.split(' ')[0];
    
    if (selectedDate === minDate) {
      const minTime = t.data.minDateTime.split(' ')[1] || '00:00:00';
      t.setData({
        timeStart: minTime.substring(0, 5)
      });
    } else if (selectedDate === maxDate) {
      const maxTime = t.data.maxDateTime.split(' ')[1] || '23:59:59';
      t.setData({
        timeEnd: maxTime.substring(0, 5)
      });
    } else {
      t.setData({
        timeStart: '00:00',
        timeEnd: '23:59'
      });
    }
    
    // 清空产品选择
    // t.setData({
    //   productIndex: -1,
    //   selectedProduct: null,
    //   products: []
    // });
  },
  
  // 选择时间
  bindTimeChange: function(e) {
    let t = this;
    const selectedTime = e.detail.value;
    
    t.setData({
      selectedTime: selectedTime
    });
    
    // 如果已经选择了日期，组合成完整的时间
    if (t.data.selectedDate) {
      t.combineDateTime();
    }
  },
  
  // 组合日期和时间
  combineDateTime: function() {
    let t = this;
    const { selectedDate, selectedTime } = t.data;
    
    if (selectedDate && selectedTime) {
      const selectedDateTime = `${selectedDate} ${selectedTime}:00`;
      const nowDateTime = t.getNowDateTimeString();
      
      // 验证是否在时间范围内
      const minTime = new Date(t.data.minDateTime).getTime();
      const maxTime = new Date(t.data.maxDateTime).getTime();
      const selectedTimeMs = new Date(selectedDateTime).getTime();
      
      // 验证1：不能早于活动开始时间
      if (selectedTimeMs < minTime) {
        wx.showToast({
          title: '不能早于活动开始时间',
          icon: 'none'
        });
        t.setData({
          selectedDateTime: '',
          // products: [],
          // selectedProduct: null,
          // productIndex: -1
        });
        return;
      }
      
      // 验证2：不能晚于活动结束时间
      if (selectedTimeMs > maxTime) {
        wx.showToast({
          title: '不能晚于活动结束时间',
          icon: 'none'
        });
        t.setData({
          selectedDateTime: '',
          // products: [],
          // selectedProduct: null,
          // productIndex: -1
        });
        return;
      }
      
      // 验证3：不能选择过去的时间（如果是今天）
      const todayDate = t.getTodayDateString();
      if (selectedDate === todayDate) {
        if (t.compareDateTime(selectedDateTime, nowDateTime+1) < 0) {
          wx.showToast({
            title: '不能选择过去的时间',
            icon: 'none'
          });
          t.setData({
            selectedDateTime: '',
            // products: [],
            // selectedProduct: null,
            // productIndex: -1
          });
          return;
        }
      }
      
      t.setData({
        selectedDateTime: selectedDateTime,
        selected_date: selectedDate // 保持兼容性
      });
      
      console.log('选择的完整时间:', selectedDateTime);
    }
  },
  
  // 打开产品选择弹窗
  openProductModal: function() {
    if (!this.data.selectedDateTime) {
      wx.showToast({
        title: '请先选择时间',
        icon: 'none'
      });
      return;
    }
    
    // 验证选择的时间是否有效
    const selectedDateTime = this.data.selectedDateTime;
    const nowDateTime = this.getNowDateTimeString();
    const todayDate = this.getTodayDateString();
    
    // 如果是今天，验证时间是否早于当前时间
    if (selectedDateTime.split(' ')[0] === todayDate) {
      if (this.compareDateTime(selectedDateTime, nowDateTime+1) < 0) {
        wx.showToast({
          title: '不能选择过去的时间',
          icon: 'none'
        });
        this.setData({
          selectedDateTime: '',
          selectedTime: ''
        });
        return;
      }
    }
    
    if (!this.data.products || this.data.products.length === 0) {
      wx.showToast({
        title: '暂无可用产品',
        icon: 'none'
      });
      return;
    }
    
    this.setData({
      showProductModal: true
    });
  },
  
  // 关闭产品选择弹窗
  closeProductModal: function() {
    this.setData({
      showProductModal: false
    });
  },
  
  // 选择产品
  selectProduct: function(e) {
    let t = this;
    const index = e.currentTarget.dataset.index;
    const product = t.data.products[index];
    
    //如果是好食才付款，需判断有无生成“订购单”
    if(t.data.type==2){
      u.post(app.globalData.url + 'api/miniprogram/index', {
        'method': 'get_activity_info',
        'type': t.data.type,
        'id': t.data.campaign_id,
        'is_check_order':1,
        'goods_id':product.goods_id,
        'uid': wx.getStorageSync('uid')
      }).then(res => {
        t.setData({
          is_generate: res.data.data.is_generate,
          productIndex: index,
          selectedProduct: product,
          showProductModal: false
        });
      });
    }else{
      t.setData({
        productIndex: index,
        selectedProduct: product,
        showProductModal: false
      });
    }
  },
  
  // 预览产品图片
  previewProductImage: function(e) {
    // e.stopPropagation(); // 阻止事件冒泡
    
    const index = e.currentTarget.dataset.index;
    const product = this.data.products[index];
    
    if (product && product.goods_image) {
      wx.previewImage({
        current: product.goods_image,
        urls: [product.goods_image]
      });
    } else {
      wx.showToast({
        title: '暂无图片',
        icon: 'none'
      });
    }
  },
  
  // 计算表单是否完整
  isFormComplete: function() {
    const { selectedStore, selectedDateTime, selectedProduct } = this.data
    return selectedStore && selectedDateTime && selectedProduct
  },
  
  // 打开店铺选择模态框
  toggleStoreModal: function() {
    this.setData({
      showStoreModal: true
    })
  },
  
  // 隐藏店铺选择模态框
  hideStoreModal: function() {
    this.setData({
      showStoreModal: false
    })
  },
  
  // 阻止事件冒泡
  stopPropagation: function() {
    // 空函数，仅用于阻止事件冒泡
  },
  
  // 选择店铺
  selectStore: function(e) {
    let t = this;
    const store = e.currentTarget.dataset.store;
    
    t.setData({
      selectedStore: store,
      showStoreModal: false,
      // 重置其他选择
      selectedDate: '',
      selectedTime: '',
      selectedDateTime: '',
      selectedProduct: null,
      productIndex: -1,
      products: []
    });
    
    // 获取店铺活动信息
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_shop_activity_info',
      'id': store.id,
      'type': t.data.type,
      'sort': 1
    }).then(res => {
      if (res.data.code === 0) {
        t.setData({
          shop_date: res.data.data.shop_date || [],
        });
      }
    });
  },
  
  //生成订购单
  generate_order: function(e){
    let t = this;
    //1、首先生成选购单
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_activity_info',
      'type': t.data.type,
      'id': t.data.campaign_id,
      'goods_id': t.data.selectedProduct.goods_id,
      'uid': wx.getStorageSync('uid'),
      'is_generate_order': 1
    }).then(res => {

    });
  },

  // 确认参与活动
  navigateToProductDetail: function() {
    let t = this;
    if (!t.isFormComplete()) {
      wx.showToast({
        title: '请完善所有信息',
        icon: 'none'
      })
      return
    }

    //判断是否“好食才付款”活动，是否已生成订购单
    if(t.data.type == 2 && t.data.is_generate==0){
      wx.showToast({
        title: '请先生成订购单',
        icon: 'none'
      })
      return
    }
    
    const { selectedStore, selectedDateTime, selectedProduct } = t.data
    
    // 获取所有选择的数据
    const selectedData = {
      store: {
        id: selectedStore.id,
        name: selectedStore.name,
        address: selectedStore.address,
        phone: selectedStore.phone
      },
      date: selectedDateTime.split(' ')[0], // 只取日期部分
      datetime: selectedDateTime, // 完整的日期时间
      product: {
        id: selectedProduct.goods_id,
        name: selectedProduct.goods_name,
        image: selectedProduct.goods_image
      },
      timestamp: new Date().getTime()
    }
    
    console.log('完整的选择数据:', selectedData)
   
    // 显示确认信息，再提交
    this.showConfirmAndNavigate(selectedData)
  },
  
  // 显示确认信息后再跳转
  showConfirmAndNavigate: function(selectedData) {
    var t = this;
    const { store, datetime, product } = selectedData
    
    // 记录用户参与活动，并完成指定任务
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'join_activity',
      'type': t.data.type,
      'store_id': store.id,
      'date': datetime,
      'product_id': product.id,
      'campaign_id': t.data.campaign_id,
      'uid': wx.getStorageSync('uid'),
      'sns_openid': wx.getStorageSync('sns_openid')
    }).then(res => {
      if (res.data.code == 0) {
        // 参与活动成功，问用户跳转活动管理页，还是继续参与活动
        wx.showActionSheet({
          itemList: ['管理活动', '返回上一页'],
          success: (res) => {
            if (res.tapIndex === 0) {
              wx.redirectTo({
                url: '/pages/my_page/activity_manage/index'
              });
            } else if (res.tapIndex === 1) {
              wx.redirectTo({
                url: '/pages/my_page/activity/index'
              });
            }
          },
          fail: () => {
            // 默认跳转到活动管理页
            wx.redirectTo({
              url: '/pages/my_page/activity/index'
            });
          }
        });
      }
    });
  },
  
  //预览地图图片
  previewAddrImage: function(e){
    let t = this;
    wx.previewImage({
      urls:[t.data.selectedStore.addr_image]
    });
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack({
      delta: 1,
      fail:function(){
        wx.redirectTo({
          url: '/pages/my_page/activity/index',
        });
      }
    });
  },
  
  onLoad: function(options) {
    let t = this;
    
    console.log('页面参数:', options);
    
    t.setData({
      type:options.type
    });

    // 显示当前时间
    const nowTime = t.getNowTimeString();
    const nowDateTime = t.getNowDateTimeString();
    console.log('当前时间:', nowDateTime);

    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_activity_info',
      'type': options.type,
      'id': options.id
    }).then(res => {
      if (res.data.code === 0) {
        const activityInfo = res.data.data;
        
        console.log('活动信息:', activityInfo);
        
        // 假设后台返回了时间限制
        const startTime = activityInfo.startTime; // 默认从今天开始
        const endTime = activityInfo.endTime;
        
        // 获取店铺数据（假设是第一个店铺）
        const storeData = activityInfo.stores;
        
        t.setData({
          selectedStore: storeData,
          minDateTime: startTime,
          maxDateTime: endTime,
          products: activityInfo.goods || [],
          nowTime: nowTime,
          nowDateTime: nowDateTime,
          campaign_id:options.id
        });
        
        // 解析时间限制
        t.parseTimeLimits();
      } else {
        wx.showToast({
          title: res.data.msg || '加载失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      console.error('加载活动信息失败:', err);
      wx.showToast({
        title: '网络错误',
        icon: 'none'
      });
    });
  },
  
  onShow: function() {
    // 页面显示时，可以检查当前选择状态
    // const selectedData = this.getSelectedData()
    // if (selectedData) {
    //   console.log('当前选择状态:', selectedData)
    // }
  }
})