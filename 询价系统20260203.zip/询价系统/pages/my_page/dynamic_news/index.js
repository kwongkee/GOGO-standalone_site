var u = require('../../../utils/util.js');
const app = getApp();
var WxParse = require('../../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:[],
    // 新闻数据
    newsData: {
      id: 1,
      title: '科技创新引领未来：人工智能在医疗领域的突破性应用',
      category: '科技',
      isHot: true,
      isExclusive: false,
      summary: '最新的AI诊断系统准确率已达到95%，正在改变传统医疗模式...',
      mediaLogo: '/images/logos/tech-news.png',
      mediaName: '科技前沿',
      author: '张明',
      publishTime: '2小时前',
      readCount: '12.5万',
      isFollowed: false,
      coverImage: '/images/news/cover.jpg',
      imageDesc: 'AI医疗影像分析系统正在工作中',
      content: `
        <p>近年来，人工智能技术在医疗健康领域展现出巨大潜力。从疾病诊断到药物研发，AI正在逐步改变传统的医疗模式。</p>
        <p>最新研究显示，基于深度学习的医学影像分析系统，在某些疾病的诊断准确率上已经超越了经验丰富的医生团队。</p>
        <h3>关键技术突破</h3>
        <p>1. 多模态数据融合分析</p>
        <p>2. 实时监测预警系统</p>
        <p>3. 个性化治疗方案推荐</p>
      `,
      gallery: [
        '/images/news/gallery1.jpg',
        '/images/news/gallery2.jpg',
        '/images/news/gallery3.jpg'
      ],
      videoUrl: '',
      videoCover: '',
      quote: '人工智能不会取代医生，但使用AI的医生将取代不使用AI的医生。',
      likeCount: 2458,
      commentCount: 382
    },
    
    // 交互状态
    isLiked: false,
    isCollected: false,
    showInput: false,
    commentText: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    let id = options.id;

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_dynamic_news_info','id':id}).then(res => {
      WxParse.wxParse('content', 'html', res.data.data.content, t);
      WxParse.wxParseTem("content",'content', 1, t);

      t.setData({
        data:res.data.data
      })
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})