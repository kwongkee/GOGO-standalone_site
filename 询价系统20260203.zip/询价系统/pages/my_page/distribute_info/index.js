var u = require('../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_info','uid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        info:res.data.acc
      });
    });
  },

  //我要分销
  distrClick(){
    wx.navigateTo({
      url:"/pages/my_page/apply_distribute/index"
    });
  },

  //我的分销码
  mycodeClick(){
    wx.setStorageSync('agreement_url', 'https://www.gogo198.net/?s=index/generate_distribute_code&miniprogram=1&uid='+wx.getStorageSync('uid'));
    wx.navigateTo({
      url: '/pages/agreement/index',
    })
  },

  //分销对账
  billClick(){
    wx.setStorageSync('agreement_url', 'https://www.gogo198.net/?s=index/distr_recon&miniprogram=1&uid='+wx.getStorageSync('uid'));
    wx.navigateTo({
      url: '/pages/agreement/index',
    })
  },
  //分销下单
  placeorderClick(){
    wx.setStorageSync('agreement_url', 'https://www.gogo198.net/?s=index/add_reservation&process1=16&process2=17&process3=17&miniprogram=1&uid='+wx.getStorageSync('uid'));
    wx.reLaunch({
      url: '/pages/agreement/index',
    })
  },

  //管理分销
  manageClick(){
    wx.navigateTo({
      url:"/pages/my_page/manage_distribute/index"
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})