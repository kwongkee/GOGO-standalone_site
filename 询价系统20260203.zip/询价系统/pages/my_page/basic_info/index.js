var u = require('../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_info','uid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        info:res.data.acc
      });
    });
  },

  //表单提交
  formSubmit(data){
    let t = this;
    let arr = data.detail.value;
    let email = arr['email'];let phone = arr['phone'];let nickname = arr['nickname'];let realname = arr['realname'];
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'set_user_info','uid':wx.getStorageSync('uid'),'email':email,'phone':phone,'nickname':nickname,'realname':realname}).then(res => {
      if(res.data.code==-1){
        wx.showToast({
          title: res.data.msg,
          icon:'error'
        });
      }else if(res.data.code==0){
        wx.showToast({
          title: res.data.msg,
          icon:'none'
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})