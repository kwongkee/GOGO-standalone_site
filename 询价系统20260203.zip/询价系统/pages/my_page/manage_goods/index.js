// pages/my_page/manage_goods/index.js
var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    type:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
      let t=this;
      
      if(options.type>0){
        t.setData({
          type:options.type
        });

        if(options.type==1){
          wx.setNavigationBarTitle({
            title: '管理选品'
          });
          t.getMyGoods(0);
        }else if(options.type==2){
          wx.setNavigationBarTitle({
            title: '整理入库'
          });
          t.getMyGoods(0);
        }else if(options.type==3){
          wx.setNavigationBarTitle({
            title: '已入库列表'
          });
          t.getMyGoods(1);
        }
      }
      else{
        t.getMyGoods(0);
      }
  },

  //获取我的商品
  getMyGoods(sta){
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_my_goods','status':sta,'mid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        list:res.data.list,
      });
    });
  },
  //跳转页面
  navClick(e){
    let t = this;
    let key = e.currentTarget.dataset.key;
    let id = e.currentTarget.dataset.id;

    if(key=='add'){
      wx.navigateTo({
        url: '/pages/my_page/manage_goods/save_info?id='+0,
      })
    }
    else if(key=='ruku'){
      wx.navigateTo({
        url: '/pages/my_page/manage_goods/index?type=2',
      })
    }
    else if(key=='edit'){
      let type = 0;
      if(t.data.type==3){
        type = 2;
      }
      else{
        type = t.data.type;
      }
      wx.navigateTo({
        url: '/pages/my_page/manage_goods/save_info?id='+id+'&type='+type,
      })
    }
    else if(key=='del'){
      //删除入库
      wx.showModal({
        title: '确认删除吗？',
        confirmText: "确认",
        cancelText:"取消",
        showCancel: true,
        success: function (res) {
          if (res.confirm) {
            //点击确认
            u.post(app.globalData.url+'api/miniprogram/index',{'method':'del_goods','id':id,'mid':wx.getStorageSync('uid')}).then(res => {
              wx.showLoading({
                'title':'删除中'
              });
              setTimeout(function(){
                t.getMyGoods(1);
                wx.hideLoading();
              },1500);
            });
          } else if (res.cancel) {
            //点击取消
            
          }
        }
      });
    }
  },
  //刷新页面
  reload(e){
    let t = this;
    wx.showLoading({
      'title':'刷新中'
    });
    setTimeout(function(){
      t.getMyGoods();
      wx.hideLoading();
    },1500);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})