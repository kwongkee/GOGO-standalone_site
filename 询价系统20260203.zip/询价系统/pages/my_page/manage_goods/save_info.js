// pages/my_page/manage_goods/save_info.js
var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:0,
    data:{'name':'','cate_ids':'','pic_list':[],'desc':'','desc_list':[],'unit':'','currency':'','price':'','sale_unit':''},
    unit:[],
    unit_default:'单位',
    unit_key:0,
    currency:[],
    currency_key:0,
    currency_default:'币种',
    sale_unit:[],
    sale_unit_key:0,
    sale_unit_default:'选品渠道',
    category:[],
    category_key:0,
    mask_show:0,
    move_show:0,
    gallery_show:0,
    selImgToOcrNum:0,
    now_type:'',
    havetxt_show:0,
    orcContent:'',
    textToCopy:'',
    uploadPic_show:0,
    is_upload:0,
    upload_img_to_ocr:'',
    diy_sale_unit:0,
    array:[],//picker带搜索=========================start
    index: 0,
    index1: -1,
    selectedName:'',
    show:false,
    cat2_show:false,//二级分类
    show2:false,
    index1_2:-1,
    index2:0,
    array2:[],
    cat3_show:false,//三级分类
    show3:false,
    index1_3:-1,
    index3:0,
    array3:[],
    unit_array:[],//unit
    unit_index: 0,
    unit_index1: -1,
    unit_show:false,
    country_array:[],//country
    country_index: 0,
    country_index1: -1,
    country_show:false,//picker带搜索=========================start
    type:0,
    showDefaultCategory:0,
    seladd_show:0,
    gallery_show2:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    
    t.setData({
      id:typeof(options.id)=='undefined'?'0':options.id
    });

    t.getUnit();

    if(options.id>0){
      t.getGoods();

      if(options.type==1){
        //修改信息
        wx.setNavigationBarTitle({
          title: '修改信息'
        });
      }
      else if(options.type==2){
        //整理入库
        wx.setNavigationBarTitle({
          title: '整理入库'
        });
      }

      t.setData({
        type:options.type
      })
    }
  },
  /*带搜索的picker============================================================================== */
  bindChange(e) {
    let t = this;
    let type = e.currentTarget.dataset.type;

    if(type=='category'){
      t.setData({
        index: e.detail.value
      })
    }
    else if(type=='category2'){
      t.setData({
        index2: e.detail.value
      })
    }
    else if(type=='category3'){
      t.setData({
        index3: e.detail.value
      })
    }
    else if(type=='unit'){
      t.setData({
        unit_key:e.detail.value,
        unit_index: e.detail.value
      })
    }
    else if(type=='country'){
      t.setData({
        country_key:e.detail.value,
        country_index: e.detail.value
      })
    }
    
  },
  //点击搜索展示框
  showPicker(e) {
    let t = this;
    let type = e.currentTarget.dataset.type;
    if(type=='category'){
      t.setData({
        show: !t.data.show,
        array:t.data.category,
        index1:t.data.index,
        showDefaultCategory:0
      });
    }
    else if(type=='category2'){
      t.setData({
        show2: !t.data.show2,
        array2:t.data.category2,
        index1_2:t.data.index2,
        showDefaultCategory:0
      });
    }
    else if(type=='category3'){
      t.setData({
        show3: !t.data.show3,
        array3:t.data.category3,
        index1_3:t.data.index3,
        showDefaultCategory:0
      });
    }
    else if(type=='unit'){
      t.setData({
        unit_show: !t.data.unit_show,
        unit_array:t.data.unit,
        unit_index1:t.data.unit_index,
      });
    }
    else if(type=='country'){
      t.setData({
        country_show: !t.data.country_show,
        country_array:t.data.country,
        country_index1:t.data.country_index,
      });
    }
  },
  //搜索框选择变化
  bindNameChange(e) {
    let t = this;
    let type = e.currentTarget.dataset.type;
    if(type=='category'){
      t.setData({
        index: e.detail.value
      });
      
      t.getNextCategory(t.data.array[e.detail.value].cat_id,2);
    }
    else if(type=='category2'){
      t.setData({
        index2: e.detail.value
      });
      
      t.getNextCategory(t.data.array2[e.detail.value].cat_id,3);
    }
    else if(type=='category3'){
      t.setData({
        index3: e.detail.value
      })
    }
    else if(type=='unit'){
      t.setData({
        unit_key:e.detail.value,
        unit_index: e.detail.value
      })
    }
    else if(type=='country'){
      t.setData({
        country_index: e.detail.value
      });
      // let currency = t.data.currency.filter(item => item.country_id.includes(t.data.country_array[e.detail.value].id));
      
      t.data.currency.forEach(function(item,index){
        if(item.country_id==t.data.country_array[e.detail.value].id){
            t.setData({
              currency_key:index
            });
        }
      });
    }
  },
  //确认选择
  confirm(e){
    let t = this;
    let type = e.currentTarget.dataset.type;
    
    if(type=='category'){
      t.setData({
        show:!t.data.show
      });

      if(t.data.array.length>0){
        t.getNextCategory(t.data.array[t.data.index].cat_id,2);
      }
    }
    else if(type=='category2'){
      t.setData({
        show2:!t.data.show2
      });

      if(t.data.array2.length>0){
        t.getNextCategory(t.data.array2[t.data.index2].cat_id,3);
      }
    }
    else if(type=='category3'){
      t.setData({
        show3:!t.data.show3
      })
    }
    else if(type=='unit'){
      t.setData({
        unit_show:!t.data.unit_show
      });
    }
    else if(type=='country'){
      t.setData({
        country_show:!t.data.country_show
      });

      if(t.data.country_array.length>0){
        t.data.currency.forEach(function(item,index){
          if(item.country_id==t.data.country_array[t.data.country_index].id){
              t.setData({
                currency_key:index
              });
          }
        });
      }
    }
  },
  //取消选择
  hiddeDatePicker(e){
    let t = this;
    let type = e.currentTarget.dataset.type;
    if(type=='category'){
      t.setData({
        show:!t.data.show
      })
    }
    else if(type=='category2'){
      t.setData({
        show2:!t.data.show2
      })
    }
    else if(type=='category3'){
      t.setData({
        show3:!t.data.show3
      })
    }
    else if(type=='unit'){
      t.setData({
        unit_show:!t.data.unit_show
      })
    }
    else if(type=='country'){
      t.setData({
        country_show:!t.data.country_show
      })
    }
  },
  //监听选择框的输入框输入
  bindNameInput(e) {
    let t = this;
    let type = e.currentTarget.dataset.type;
    const keyword = e.detail.value;

    if(type=='category'){
      let searchResults = t.data.category.filter(item => item.cat_name.includes(keyword));  
      if(keyword==null){
        t.setData({ 
          array:t.data.category,
          index:0
        });
      }else{
        if(searchResults.length==0){
          wx.showToast({
            title: '暂无“'+keyword+'”信息',
            icon:'none'
          })
        }else{
          t.setData({ 
            array:searchResults,
            index:0
          });
        }
      }
    }
    else if(type=='category2'){
      let searchResults = t.data.category2.filter(item => item.cat_name.includes(keyword));  
      if(keyword==null){
        t.setData({ 
          array2:t.data.category2,
          index2:0
        });
      }else{
        if(searchResults.length==0){
          wx.showToast({
            title: '暂无“'+keyword+'”信息',
            icon:'none'
          })
        }else{
          t.setData({ 
            array2:searchResults,
            index2:0
          });
        }
      }
    }
    else if(type=='category3'){
      let searchResults = t.data.category3.filter(item => item.cat_name.includes(keyword));  
      if(keyword==null){
        t.setData({ 
          array3:t.data.category3,
          index3:0
        });
      }else{
        if(searchResults.length==0){
          wx.showToast({
            title: '暂无“'+keyword+'”信息',
            icon:'none'
          })
        }else{
          t.setData({ 
            array3:searchResults,
            index3:0
          });
        }
      }
    }
    else if(type=='unit'){
      let searchResults = t.data.unit.filter(item => item.code_name.includes(keyword));  
      if(keyword==null){
        t.setData({ 
          unit_array:t.data.unit,
          unit_index:0
        });
      }else{
        if(searchResults.length==0){
          wx.showToast({
            title: '暂无“'+keyword+'”信息',
            icon:'none'
          })
        }else{
          t.setData({ 
            unit_array:searchResults,
            unit_index:0
          });
        }
      }
    }
    else if(type=='country'){
      let searchResults = t.data.country.filter(item => item.param2.includes(keyword));
      if(keyword==null){
        t.setData({ 
          country_array:t.data.country,
          country_index:0
        });
      }else{
        if(searchResults.length==0){
          wx.showToast({
            title: '暂无“'+keyword+'”信息',
            icon:'none'
          })
        }else{
          t.setData({ 
            country_array:searchResults,
            country_index:0
          });
        }
      }
    }
  },
  //获取下一级
  getNextCategory(parent_id,get_level){
    let t = this;
    
    //请求获取下一级
    if(parent_id>0){
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_category_child','parent_id':parent_id,'mid':wx.getStorageSync('uid')}).then(res => {
        if(get_level==2){
          if(res.data.list.length>0){
            t.setData({
              category2:res.data.list,
              array2:res.data.list,
              cat2_show:true,
              index2:0,
              category3:[],
              array3:[],
              cat3_show:false,
              index3:0
            });
          }
          else{
            t.setData({
              category2:[],
              array2:[],
              cat2_show:false,
              index2:0,
              category3:[],
              array3:[],
              cat3_show:false,
              index3:0
            });
          }
        }
        else if(get_level==3){
          if(res.data.list.length>0){
            t.setData({
              category3:res.data.list,
              array3:res.data.list,
              cat3_show:true,
              index3:0
            });
          }else{
            t.setData({
              category3:[],
              array3:[],
              cat3_show:false,
              index3:0
            });
          }
        }
      });
    }
  },
  /*============================================================================== */
  //获取单位&币种&选品渠道&商品类别&国家
  getUnit(e){
    let t = this;

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_unit','type':1,'mid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        unit:res.data.list,
        unit_array:res.data.list,
        currency:res.data.list2,
        sale_unit:res.data.list3,
        category:res.data.list4,
        array:res.data.list4,
        country:res.data.list5,
        country_array:res.data.list5,
        country_index:res.data.list5_key,
        currency_key:res.data.list5_key2
      });
    });
  },
  //获取当前商品信息
  getGoods(e){
    let t = this;

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_goods','id':t.data.id,'mid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        data:res.data.list,
        showDefaultCategory:1
      });

      setTimeout(function(){
        //商品单位
        t.data.unit.forEach(function(item,index){
          if(item.code_value==t.data.data.unit){
              t.setData({
                unit_index:index
              });
          }
        });

        //国家地区
        t.data.country.forEach(function(item,index){
          if(item.id==t.data.data.country_id){
              t.setData({
                  country_index:index
              });
          }
        });

        //商品币种
        t.data.currency.forEach(function(item,index){
          if(item.id==t.data.data.currency){
              t.setData({
                  currency_key:index
              });
          }
        });

        //选品渠道
        t.data.sale_unit.forEach(function(item,index){
          if(item.id==t.data.data.sale_unit){
              t.setData({
                  sale_unit_key:index
              });
          }
        });
      },1000);
      // console.log(res);
    });

  },
  //单位选择（废弃）
  unitChange(e){
    let t = this;
    t.setData({
      unit_key:e.detail.value,
    });
  },
  //币种选择
  currencyChange(e){
    let t = this;
    t.setData({
      currency_key:e.detail.value,
    });
  },
  //销售单位选择
  saleunitChange(e){
    let t = this;
    
    if(t.data.sale_unit[e.detail.value].id==-1){
      t.setData({
        diy_sale_unit:1,
        sale_unit_key:e.detail.value
      })
    }else{
      t.setData({
        sale_unit_key:e.detail.value,
        diy_sale_unit:0
      });
    }
  },
  //添加图片to商品详情
  add_image(e){
    let t = this;
    let key = e.currentTarget.dataset.key;

    wx.showLoading({
      title: '上传中..',
    });

    wx.chooseMedia({
      count: 1,
      mediaType: ['image','video'],
      sourceType: ['album', 'camera'],
      maxDuration: 30,
      camera: 'back',
      success(res) {
        wx.uploadFile({
          url: app.globalData.url+'api/uploadfile/index', // 替换为你的服务器接口地址
          filePath: res.tempFiles[0].tempFilePath,
          name: 'file',
          formData: {
            'folder': 'website',
            'type':'goods',
            'file_size':res.tempFiles[0].size,
            'file_type':res.tempFiles[0].fileType
          },
          success (res) {
            const data = JSON.parse(res.data);
            // 处理响应数据
            if(data.code==1){
              //上传成功
              if(key=='goods_img'){
                var file_arr = t.data.data.pic_list;
                file_arr.push('https://shop.gogo198.cn/'+data.file_path);
                t.setData({
                  'data.pic_list':file_arr
                });
              }
              else if(key=='desc_img'){
                var file_arr = t.data.data.desc_list;
                file_arr.push('https://shop.gogo198.cn/'+data.file_path);
                t.setData({
                  'data.desc_list':file_arr,
                  mask_show:0,
                  seladd_show:0
                });
              }
              
              wx.hideLoading();
            }else{
              //上传失败
              wx.showLoading({
                title: data.message,
              });

              setTimeout(function(){
                wx.hideLoading();
              },2000);
            }
          },
          fail (err) {
            console.error(err);
          }
        });
      }
    })
  },
  //添加或选择图片to商品详情=选择框
  add_select_image(e){
    let t = this;

    t.setData({
      mask_show:1,
      seladd_show:1
    });
  },
  //选择图库to商品详情
  selectphoto2(e){
    let t = this;
    t.setData({
      gallery_show2:1,
      seladd_show:0
    });
    wx.hideLoading();
  },
  //确认/取消选择图片to商品详情
  sure_desc(e){
    let t = this;
    let key = e.currentTarget.dataset.key;

    if(key==0){
      //取消
      t.setData({
        gallery_show2:0,
        mask_show:0
      });
    }
    else if(key==1){
      //确认
      let pic = t.data.data.pic_list[t.data.selImgToOcrNum];
      
      var file_arr = t.data.data.desc_list;
      file_arr.push(pic);
      t.setData({
        'data.desc_list':file_arr,
        gallery_show2:0,
        mask_show:0
      });
    }
  },
  //删除照片
  del_image(e){
    let t = this;
    wx.showLoading({
      title: '删除中..',
    });
    let key = e.currentTarget.dataset.key;
    let type = e.currentTarget.dataset.type;
    if(type=='goods_img'){
      let file_list = t.data.data.pic_list;
      file_list.splice(key, 1); // 删除第n个元素，n是基于1的索引
      t.setData({
        'data.pic_list':file_list
      });
    }
    else if(type=='desc_img'){
      let file_list = t.data.data.desc_list;
      file_list.splice(key, 1); // 删除第n个元素，n是基于1的索引
      t.setData({
        'data.desc_list':file_list
      });
    }
    
    wx.hideLoading();
  },
  //图片识别弹框里的取消
  cancelPicTxt(e){
    let t = this;

    t.setData({
      mask_show:0,
      gallery_show:0,
      havetxt_show:0
    });
  },
  //打开图片图标，弹出上传图片/识别图片
  ocrImg(e){
    let t = this;
    let type = e.currentTarget.dataset.type;

    if(type=='name'){
      //商品名称只能打开图库，ocr识别图片，获取图片的文字，然后复制，粘贴到输入框
      t.setData({
        mask_show:1,
        gallery_show:1,
        now_type:type
      });
    }
    else{
      //其他能上传图片，识别图片
      t.setData({
        mask_show:1,
        move_show:1,
        now_type:type
      });
    }
    // console.log(e);
  },
  //选择图片识别
  takephoto(e){
    let t = this;

    t.setData({
      mask_show:1,
      gallery_show:1,
      move_show:0,
    });
  },
  //上传图片识别
  selectphoto(e){
    let t = this;

    t.setData({
      mask_show:1,
      uploadPic_show:1,
      move_show:0,
    });
  },
  //图库选择图片to识别
  selImgToOcr(e){
    let t = this;
    
    t.setData({
      selImgToOcrNum:e.currentTarget.dataset.key
    });
  },
  //图库点击开始识别或取消识别按钮
  sure_ocr(e){
    let t = this;
    let key = e.currentTarget.dataset.key;
    
    if(key==0){
      t.setData({
        mask_show:0,
        gallery_show:0,
        now_type:''
      });
    }else{
      wx.showLoading({
        title: '图片识别中...',
      });

      //请求ocr接口
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_ocr','img':t.data.data.pic_list[t.data.selImgToOcrNum],'mid':wx.getStorageSync('uid')}).then(res => {
        wx.hideLoading();
        if(res.data.content!=''){
            t.setData({
              orcContent:res.data.content,
              gallery_show:0,
              havetxt_show:1,
            });
        }else{
          wx.showToast({
            'title':'识别图片内容为空',
            'icon':none,
            'duration':2000
          })
        }
      });
    }
  },
  //图片文字结果更改
  orcContentChange(e){
    let t = this;
    t.setData({
      orcContent:e.detail.value
    });
  },
  //复制文本框内容
  copyText(e){
    const t = this;
    wx.setClipboardData({
      data: t.data.orcContent,
      success(res) {
        wx.showToast({
          title: '复制成功',
          icon: 'success',
          duration: 2000
        });

        t.setData({
          havetxt_show:0,
          mask_show:0,
          'data.name':t.data.orcContent
        });
      },
      fail(err) {
        console.error('复制失败', err);
      }
    });
  },
  //监听型号和参数的输入框变化
  bindOptions(e){
    let t = this;
    
    let type = e.currentTarget.dataset.type;
    let key = e.currentTarget.dataset.key;
    let val = e.currentTarget.dataset.val;

    if(type=='option'){
      if(val=='name'){
        t.data.data.option_list[key].option_name = e.detail.value;
      }
      else if(val=='desc'){
        t.data.data.option_list[key].option_desc = e.detail.value;
      }
      t.setData({
        'data.option_list':t.data.data.option_list
      });
    }
    else if(type=='spec'){
      if(val=='name'){
        t.data.data.spec_list[key].spec_name = e.detail.value;
      }
      else if(val=='desc'){
        t.data.data.spec_list[key].spec_desc = e.detail.value;
      }
      t.setData({
        'data.spec_list':t.data.data.spec_list
      });
    }
  },
  //添加型号&参数
  optionOpera(e){
    let t = this;
    let key = e.currentTarget.dataset.key;
    let type = e.currentTarget.dataset.type;

    if(key=='del'){
      let keynum = e.currentTarget.dataset.keynum;
      
      if(type=='option'){
        var file_list = t.data.data.option_list;
        file_list.splice(keynum, 1);
        t.setData({
          'data.option_list':file_list
        });
      }
      else if(type=='spec'){
        var file_list = t.data.data.spec_list;
        file_list.splice(keynum, 1);
        t.setData({
          'data.spec_list':file_list
        });
      }
    }
    else if(key=='add'){
      if(type=='option'){
        t.data.data.option_list.push({'option_name':'','option_desc':''});
        t.setData({
          'data.option_list':t.data.data.option_list
        })
      }
      else if(type=='spec'){
        t.data.data.spec_list.push({'spec_name':'','spec_desc':''});
        t.setData({
          'data.spec_list':t.data.data.spec_list
        })
      }
    }
  },
  //整理商品型号
  arrangeText(e){
    let t = this;
    
    wx.showLoading({
      title: '整理中..',
    });
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'arrange_txt','id':t.data.id,'uid':wx.getStorageSync('uid'),'type':t.data.now_type,'txts':t.data.orcContent}).then(res2 => {
      if(res2.data.code==0){
        //整理字符完成
        console.log(t.data.now_type,res2.data.list);
        if(t.data.now_type=='option'){
          t.setData({
            'data.option_list':res2.data.list,
            mask_show:0,
            havetxt_show:0
          });
        }
        else if(t.data.now_type=='spec'){
          t.setData({
            'data.spec_list':res2.data.list,
            mask_show:0,
            havetxt_show:0
          });
        }
      }
      wx.hideLoading();
    });
  },
  //上传图片识别
  uploadImgToOcr(e){
    let t = this;
    wx.showLoading({
      title: '上传中..',
    });

    wx.chooseMedia({
      count: 1,
      mediaType: ['image','video'],
      sourceType: ['album', 'camera'],
      maxDuration: 30,
      camera: 'back',
      success(res) {
        wx.uploadFile({
          url: app.globalData.url+'api/uploadfile/index', // 替换为你的服务器接口地址
          filePath: res.tempFiles[0].tempFilePath,
          name: 'file',
          formData: {
            'folder': 'website',
            'type':'uploadtoocr',
            'file_size':res.tempFiles[0].size,
            'file_type':res.tempFiles[0].fileType
          },
          success (res) {
            const data = JSON.parse(res.data);
            // 处理响应数据
            if(data.code==1){
              //上传成功
              t.setData({
                is_upload:1,
                upload_img_to_ocr:'https://shop.gogo198.cn/'+data.file_path
              });
              
              wx.hideLoading();
            }else{
              //上传失败
              wx.showLoading({
                title: data.message,
              });

              setTimeout(function(){
                wx.hideLoading();
              },2000);
            }
          },
          fail (err) {
            console.error(err);
          }
        });
      }
    });
  },
  //取消此图片识别，可上传第二张
  cancelUploadImg(e){
    let t = this;

    t.setData({
      is_upload:0,
      upload_img_to_ocr:''
    });
    wx.hideLoading();
  },
  //取消上传图片识别
  uploadCancel(e){
    let t = this;

    t.setData({
      uploadPic_show:0,
      mask_show:0,
      is_upload:0,
      upload_img_to_ocr:''
    });

    wx.hideLoading();
  },
  //确认此图片，跳转到识别文字框
  upload_sure_ocr(e){
    let t = this;
    
    wx.showLoading({
      title: '图片识别中...',
    });

    //请求ocr接口
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_ocr','img':t.data.upload_img_to_ocr,'mid':wx.getStorageSync('uid')}).then(res => {
      wx.hideLoading();
      if(res.data.content!=''){
          t.setData({
            orcContent:res.data.content,
            gallery_show:0,
            havetxt_show:1,
            uploadPic_show:0,
            is_upload:0,
            upload_img_to_ocr:''
          });
      }else{
        wx.showToast({
          'title':'识别图片内容为空',
          'icon':none,
          'duration':2000
        })
      }
    });
  },
  //提交表单
  submitForm: function(e) {
    let t = this;
    
    // console.log(e.detail.value); // 输出表单数据
    wx.showLoading({
      title: '保存中..',
    });

    let cat1 = 0;let cat2 = 0;let cat3 = 0;
    if(t.data.array.length > 0){
      cat1 = t.data.array[t.data.index].cat_id;
    }
    if(t.data.array2.length > 0){
      cat2 = t.data.array2[t.data.index2].cat_id;
    }
    if(t.data.array3.length > 0){
      cat3 = t.data.array3[t.data.index3].cat_id;
    }
    
    var data;
    if(t.data.id==0){
      data = {'method':'save_goods','id':t.data.id,'uid':wx.getStorageSync('uid'),'type':t.data.type,'name':e.detail.value['name'],'country_id':t.data.country_array[t.data.country_index].id,'pic_list':t.data.data.pic_list,'desc':e.detail.value['desc'],'desc_list':t.data.data.desc_list,'unit':t.data.unit[t.data.unit_index].code_value,'currency':t.data.currency[e.detail.value.currency].id,'price':e.detail.value.price,'sale_unit':t.data.sale_unit[e.detail.value.sale_unit].id,'diy_sale_unit':e.detail.value['diy_sale_unit']};
    }
    else{
      if(t.data.type==1){
        //修改信息
        data = {'method':'save_goods','id':t.data.id,'uid':wx.getStorageSync('uid'),'type':t.data.type,'name':e.detail.value['name'],'country_id':t.data.country_array[t.data.country_index].id,'pic_list':t.data.data.pic_list,'desc':e.detail.value['desc'],'desc_list':t.data.data.desc_list,'unit':t.data.unit[t.data.unit_index].code_value,'currency':t.data.currency[e.detail.value.currency].id,'price':e.detail.value.price,'sale_unit':t.data.sale_unit[e.detail.value.sale_unit].id,'diy_sale_unit':e.detail.value['diy_sale_unit']};
      }
      else if(t.data.type==2){
        //整理入库
        if(cat1==0){
          if(typeof(t.data.data.cate_ids[0])!='undefined'){
            cat1 = t.data.data.cate_ids[0];
          }
        }
        if(cat2==0){
          if(typeof(t.data.data.cate_ids[1])!='undefined'){
            cat2 = t.data.data.cate_ids[1];
          }
        }
        if(cat3==0){
          if(typeof(t.data.data.cate_ids[2])!='undefined'){
            cat3 = t.data.data.cate_ids[2];
          }
        }

        data = {'method':'save_goods','id':t.data.id,'uid':wx.getStorageSync('uid'),'type':t.data.type,'name':e.detail.value['name'],'desc_list':t.data.data.desc_list,'option_list':JSON.stringify(t.data.data.option_list),'spec_list':JSON.stringify(t.data.data.spec_list),'cat1':cat1,'cat2':cat2,'cat3':cat3};
      }
    }
     
    u.post(app.globalData.url+'api/miniprogram/index',data).then(res2 => {  
      if(res2.data.code==0){
        setTimeout(function(){
          let id = t.data.id;
          let type = t.data.type;
          if(id==0 || type==1){
            //提交选品=继续新增&前往管理
            wx.showModal({
              title: '提交成功，请选择下一步：',
              confirmText: "继续新增",
              cancelText:"前往管理",
              showCancel: true,
              success: function (res) {
                if (res.confirm) {
                  //点击继续新增
                  wx.redirectTo({
                    url:'/pages/my_page/manage_goods/save_info?id='+id
                  });
                } else if (res.cancel) {
                  //点击前往管理
                  wx.redirectTo({
                    url:'/pages/my_page/manage_goods/home2'
                  });
                }
              }
            });
          }
          else if(id>0 && type==2){
            //提交入库
            wx.showModal({
              title: '提交成功，请选择下一步：',
              confirmText: "新增入库",
              cancelText:"管理入库",
              showCancel: true,
              success: function (res) {
                if (res.confirm) {
                  //点击新增入库
                  wx.redirectTo({
                    url:'/pages/my_page/manage_goods/index?type=2'
                  });
                } else if (res.cancel) {
                  //点击管理入库
                  wx.redirectTo({
                    url:'/pages/my_page/manage_goods/index?type=3'
                  });
                }
              }
            });
          }

          wx.hideLoading();
        },2000);
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})