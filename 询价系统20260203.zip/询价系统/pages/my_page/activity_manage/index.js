// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({
  data: {
    filterType: '1', // 筛选类型：all, 1预约免费食, 2好食才付款, 3买一送一
    activityList: [], // 活动列表
    currentPage: 1, // 当前页码
    pageSize: 10, // 每页显示数量
    hasMore: true, // 是否还有更多数据
    isLoading: false, // 是否正在加载
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack({
      delta: 1,
      fail:function(){
        wx.redirectTo({
          url: '/pages/my_page/activity/index',
        });
      }
    });
  },

  onLoad: function(options) {
    var t = this;

    // 从首页传递的活动类型
    if (options.type) {
      t.setData({
        filterType: options.type
      })
    }
    
    //请求当前活动类型的活动列表（每10个为一页）
    t.loadCampaignData();

    // 加载活动数据
    //this.loadActivityData()
  },

  //加载指定类型的活动列表信息
  loadCampaignData(){
    let t = this;

    t.setData({ isLoading: true })

    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_activity_list','type':t.data.filterType,'currentPage':t.data.currentPage,'uid':wx.getStorageSync('uid')}).then(res => {
      if(res.data.data.length==0){
        //暂无活动记录
        t.setData({
          hasMore: false
        });
      }else{
        t.setData({
          activityList: [...t.data.activityList, ...res.data.data.list],
          currentPage: t.data.currentPage + 1,
          hasMore: res.data.data.hasMore, // 还有更多
          isLoading: false
        });
      }
    });
  },

  onShow: function() {
    // 页面显示时刷新数据
    // this.refreshData()
  },

  // 改变筛选类型
  changeFilterType: function(e) {
    const type = e.currentTarget.dataset.type
    this.setData({
      filterType: type,
      currentPage: 1,
      activityList: [],
      hasMore: true
    }, () => {
      this.loadCampaignData()
      // this.loadActivityData()
    })
  },

  // 加载活动数据
  loadActivityData: function() {
    if (this.data.isLoading || !this.data.hasMore) return
    
    this.setData({ isLoading: true })
    
    // 模拟API请求延迟
    setTimeout(() => {
      // 生成模拟数据
      const newData = this.generateMockData()
      
      this.setData({
        activityList: [...this.data.activityList, ...newData],
        currentPage: this.data.currentPage + 1,
        hasMore: this.data.activityList.length + newData.length < 50, // 模拟最多50条
        isLoading: false
      })
    }, 800)
  },

  // 生成模拟数据
  generateMockData: function() {
    const types = ['1', '2', '3']
    const typeTexts = {
      '1': '预约免费食',
      '2': '好食才付款',
      '3': '买一送一'
    }
    const statusList = ['processing', 'completed', 'pending', 'cancelled']
    const statusTexts = {
      'processing': '进行中',
      'completed': '已完成',
      'pending': '待审核',
      'cancelled': '已取消'
    }
    const statusClasses = {
      'processing': 'status-processing',
      'completed': 'status-completed',
      'pending': 'status-pending',
      'cancelled': 'status-cancelled'
    }
    
    const storeNames = ['朝阳门店', '王府井店', '西单店', '三里屯店', '国贸店']
    const productNames = ['招牌红烧肉', '清蒸鲈鱼', '宫保鸡丁', '麻婆豆腐', '糖醋里脊']
    
    const newData = []
    const startIndex = (this.data.currentPage - 1) * this.data.pageSize
    
    for (let i = 0; i < this.data.pageSize; i++) {
      const type = types[Math.floor(Math.random() * types.length)]
      
      // 如果设置了筛选类型，只生成对应类型的数据
      if (this.data.filterType !== 'all' && this.data.filterType !== type) {
        continue
      }
      
      const status = statusList[Math.floor(Math.random() * statusList.length)]
      
      newData.push({
        id: startIndex + i + 1,
        type: type,
        typeText: typeTexts[type],
        storeName: storeNames[Math.floor(Math.random() * storeNames.length)],
        productName: productNames[Math.floor(Math.random() * productNames.length)],
        participateTime: this.generateRandomDate(),
        orderId: 'ORD' + (Date.now() - startIndex - i).toString().slice(-8),
        status: status,
        statusText: statusTexts[status],
        statusClass: statusClasses[status]
      })
    }
    
    return newData
  },

  // 生成随机日期
  generateRandomDate: function() {
    const start = new Date(2025, 0, 1)
    const end = new Date()
    const randomDate = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
    
    return randomDate.toLocaleDateString('zh-CN') + ' ' + 
           randomDate.toLocaleTimeString('zh-CN', {hour: '2-digit', minute:'2-digit'})
  },

  // 加载更多
  loadMore: function() {
    if (!this.data.isLoading && this.data.hasMore) {
      // this.loadActivityData()
      this.loadCampaignData()
    }
  },

  // 刷新数据
  refreshData: function() {
    this.setData({
      currentPage: 1,
      activityList: [],
      hasMore: true
    }, () => {
      this.loadActivityData()
    })
  },

  // 查看详情
  viewDetail: function(e) {
    const id = e.currentTarget.dataset.id
    const activity = this.data.activityList.find(item => item.id === id)
    
    wx.navigateTo({
      url: '/pages/my_page/activity_detail/index?id='+id,
    })
  },

  // 去做任务
  doTask: function(e) {
    const id = e.currentTarget.dataset.id
    const activity = this.data.activityList.find(item => item.id === id)
    
    if (activity.status === 'processing') {
      wx.showModal({
        title: '任务提示',
        content: `您将开始"${activity.productName}"的任务，确定要继续吗？`,
        success: (res) => {
          if (res.confirm) {
            wx.showToast({
              title: '任务已开始',
              icon: 'success'
            })
            
            // 更新状态
            this.updateActivityStatus(id, 'completed')
          }
        }
      })
    }
  },

  // 更新活动状态
  updateActivityStatus: function(id, newStatus) {
    const statusTexts = {
      'processing': '进行中',
      'completed': '已完成',
      'pending': '待审核',
      'cancelled': '已取消'
    }
    const statusClasses = {
      'processing': 'status-processing',
      'completed': 'status-completed',
      'pending': 'status-pending',
      'cancelled': 'status-cancelled'
    }
    
    const updatedList = this.data.activityList.map(item => {
      if (item.id === id) {
        return {
          ...item,
          status: newStatus,
          statusText: statusTexts[newStatus],
          statusClass: statusClasses[newStatus]
        }
      }
      return item
    })
    
    this.setData({
      activityList: updatedList
    })
  }
})