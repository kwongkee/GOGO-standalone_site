// 获取应用实例
var u = require('../../../utils/util.js');
const app = getApp();

Page({
  data: {
    // 活动数据
    activityData: {
      // 活动基础信息
      id: 1,
      type: '预约免费食',
      quota: 99,
      usedQuota: 45,
      description: '这是一个预约免费食的活动。用户可以通过预约免费品尝指定商品，活动期间内到店即可享受免费美食体验。活动名额有限，先到先得。',
      
      // 活动图片
      image: 'https://dtc.gogo198.net/uploads/merch_file/goods_files/692022ffd216a.jpg',
      
      // 活动时间
      startTime: '2025-01-01 09:00:00',
      endTime: '2025-12-30 23:00:00',
      duration: '364天14小时',
      
      // 适用店铺
      stores: {
          id: 1,
          name: '美食体验中心旗舰店',
          address: '北京市朝阳区建国路88号SOHO现代城A座',
          phone: '010-88888888',
          businessHours: '09:00-21:00',
          isCurrent: true,
          distance: '1.2km'
      },
      
      // 产品信息
      products: [
        {
          id: 1,
          image: 'https://img.alicdn.com/bao/uploaded/i2/2213637590456/O1CN01yjSE2n1FEtgbEqHtz_!!2213637590456.jpg',
          name: '精选套餐A',
          price: '0.00',
          originalPrice: '128.00'
        },
        {
          id: 2,
          image: 'https://img.alicdn.com/bao/uploaded/i3/2213637590456/O1CN01p3QK9q1FEtgaYv4jw_!!2213637590456.jpg',
          name: '精选套餐B',
          price: '0.00',
          originalPrice: '158.00'
        },
        {
          id: 3,
          image: 'https://img.alicdn.com/bao/uploaded/i4/2213637590456/O1CN01B9X6Hf1FEtgb0sW9l_!!2213637590456.jpg',
          name: '精选套餐C',
          price: '0.00',
          originalPrice: '198.00'
        }
      ],
      
      // 任务信息
      tasks: [
        {
          icon: '👀',
          name: '分享被查看',
          description: '将活动分享给好友，被1人查看',
          completed: true,
          progress: {
            current: 1,
            total: 1
          }
        },
        {
          icon: '🛒',
          name: '分享被加购',
          description: '通过分享链接，被1人加入购物车',
          completed: false,
          progress: {
            current: 0,
            total: 1
          }
        },
        {
          icon: '📤',
          name: '分享被转发',
          description: '分享内容被1人再次转发',
          completed: false,
          progress: {
            current: 0,
            total: 1
          }
        },
        {
          icon: '💬',
          name: '分享被评论',
          description: '分享内容收到1条评论',
          completed: true,
          progress: {
            current: 1,
            total: 1
          }
        },
        {
          icon: '👍',
          name: '分享被点赞',
          description: '分享内容获得5个点赞',
          completed: false,
          progress: {
            current: 3,
            total: 5
          }
        }
      ],
      
      // 活动规则
      rules: [
        '活动期间每个用户仅可参与一次',
        '需完成至少一个任务才能获得参与资格',
        '预约成功后需在指定时间内到店消费',
        '如需取消预约，请提前2小时通知',
        '最终解释权归活动主办方所有'
      ]
    }
  },
  
  onLoad: function(options) {
    // 从上一页或通过参数传递活动ID
    const activityId = options.id || 1;

    this.setData({
      type:options.type
    });

    // 这里可以调用API获取活动详情
    this.loadActivityData(activityId);
    
    // 设置页面标题
    wx.setNavigationBarTitle({
      title: '活动详情'
    });
  },
  
  // 加载活动数据
  loadActivityData: function(activityId) {
    let t = this;
    // 模拟API请求
    console.log('加载活动数据，ID:', activityId);
    
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_campaign_detail','campaign_id':activityId}).then(res => {
      t.setData({
        activityData:res.data.data
      })
    });
  },
  
  // 返回上一页
  goBack: function() {
    wx.navigateBack({
      delta: 1,
      fail:function(){
        wx.redirectTo({
          url: '/pages/my_page/activity/index',
        });
      }
    });
  },
  
  // 预览活动图片
  previewImage: function() {
    const { image } = this.data.activityData;
    wx.previewImage({
      current: image,
      urls: [image]
    });
  },
  //预览地图图片
  previewAddrImage: function(e){
    let t = this;
    wx.previewImage({
      urls:[t.data.activityData.stores.addr_image]
    });
  },
  // 预览产品图片
  previewProductImage: function(e) {
    const index = e.currentTarget.dataset.index;
    const { products } = this.data.activityData;
    const urls = products.map(item => item.goods_image);
    
    wx.previewImage({
      current: products[index].goods_image,
      urls: urls
    });
  },
  
  // 执行任务
  doTask: function(e) {
    const index = e.currentTarget.dataset.index;
    const task = this.data.activityData.tasks[index];
    
    wx.showModal({
      title: '完成任务',
      content: `确定要开始完成任务「${task.name}」吗？`,
      confirmText: '去完成',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          // 这里应该执行具体的任务逻辑
          // 比如跳转到分享页面、评论页面等
          wx.showToast({
            title: '开始执行任务',
            icon: 'success'
          });
          
          // 模拟完成任务
          setTimeout(() => {
            this.completeTask(index);
          }, 2000);
        }
      }
    });
  },
  
  // 完成任务
  completeTask: function(index) {
    const taskKey = `activityData.tasks[${index}].completed`;
    const progressKey = `activityData.tasks[${index}].progress.current`;
    
    this.setData({
      [taskKey]: true,
      [progressKey]: this.data.activityData.tasks[index].progress.total
    });
    
    wx.showToast({
      title: '任务已完成',
      icon: 'success'
    });
  },
  
  // 立即参与活动
  participateActivity: function() {
    let t = this;
    const { quota, usedQuota } = t.data.activityData;
    const remainingQuota = quota - usedQuota;
    
    if (remainingQuota <= 0) {
      wx.showModal({
        title: '名额已满',
        content: '很抱歉，本次活动名额已满，请关注下次活动。',
        showCancel: false,
        confirmText: '知道了'
      });
      return;
    }
    
    // 确认参与，跳转至参与活动页面
    wx.navigateTo({
      url: '/pages/my_page/reserve/index?id=' + t.data.activityData.campaign_id+"&type="+t.data.type,
    })
  },
  
  onShareAppMessage: function() {
    return {
      title: `快来参与${this.data.activityData.type}活动！`,
      path: `/pages/activity_detail/index?id=${this.data.activityData.campaign_id}`,
      imageUrl: this.data.activityData.image
    };
  },
  
  onShareTimeline: function() {
    return {
      title: `🔥 ${this.data.activityData.type} | 剩余名额${this.data.activityData.quota - this.data.activityData.usedQuota}人`,
      query: `id=${this.data.activityData.id}`,
      imageUrl: this.data.activityData.image
    };
  }
});