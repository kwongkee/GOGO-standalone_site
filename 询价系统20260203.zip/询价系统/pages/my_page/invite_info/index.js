// pages/my_page/invite_info/index.js
var u = require('../../../utils/util.js');
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    warn_msg:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    let company_id = 0;//企业邀请id
    let role_id = 0;//企业邀请角色id

    if (options.scene) {
      //扫码进入
      let scene = decodeURIComponent(options.scene);//扫码进来的参数
      let params  = scene.split("&");
      company_id = params[0].split("=")[1];
      role_id = params[1].split("=")[1];

      wx.setStorageSync('to_pages', '/pages/my_page/invite_info/index');
      wx.setStorageSync('invite_company_id', company_id);
      wx.setStorageSync('invite_role_id', role_id);
    }
    else{
      company_id = wx.getStorageSync('invite_company_id');
      role_id = wx.getStorageSync('invite_role_id');
    }
    
    if(wx.getStorageSync('sns_openid')==''){
      wx.navigateTo({
        url:"/pages/login/index"
      });
    }else{
      var data = {'method':'get_invite_info','uid':wx.getStorageSync('uid'),'company_id':wx.getStorageSync('invite_company_id'),'role_id':wx.getStorageSync('invite_role_id')};

      u.post(app.globalData.url+'api/miniprogram/index',data).then(res2 => {
        t.setData({
          company_id:wx.getStorageSync('invite_company_id'),
          role_id:wx.getStorageSync('invite_role_id'),
          warn_msg:res2.data.warn_msg
        });
      });
    }
  },

  //提交表单
  submitForm: function(e) {
    let t = this;
    
    // console.log(e.detail.value); // 输出表单数据
    if(e.detail.value['name']==''){
      wx.showToast({
        title: '请输入真实名称',
        icon:'none'
      });
      return false;
    }
    wx.showLoading({
      title: '提交中..',
    });
    
    var data = {'method':'save_staff','uid':wx.getStorageSync('uid'),'company_id':wx.getStorageSync('invite_company_id'),'role_id':wx.getStorageSync('invite_role_id'),'name':e.detail.value['name']};

    u.post(app.globalData.url+'api/miniprogram/index',data).then(res2 => {  
      if(res2.data.code==0){
        setTimeout(function(){
          wx.switchTab({
            url:'/pages/my/index'
          });
        },2000);
      }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})