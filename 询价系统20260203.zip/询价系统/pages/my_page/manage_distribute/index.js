var u = require('../../../utils/util.js');
const app = getApp();
Page({
    /** 页面的初始数据*/
    data: {
        tabList: ['未审核', '已审核', '已拒绝'],
        tabNow: 0, //当前选中的tab标签索引
        search: "",
        list:[],
        hidem:1,
        cb:0,
        custom_id:'',
        business:'',
        category:''
    },
    selectTab (e) { //切换不同的tab
        this.setData({
            tabNow: e.currentTarget.dataset.id
        })
    },
    handleSwiperChange(e) { //对应改变tab
        this.setData({
          tabNow: e.detail.current
        })
    },
    getContent(e) {
        console.log("主页：",e)
        this.setData({
          search: e.detail
        })
    },
    handleMove(e){
    //不做任何处理
    },
    qx:function(e){
      this.setData({
          hidem:1
      });
    },
    qx2:function(e){
      this.setData({
        hidem:1
      })
    },
    qr:function(e){
      let that = this;
      if(that.data.cb==0){
        wx.showToast({
          title: '请点击确认框',
          icon:'none'
        })
        return;
      }else{
        
        s.get('common/read_agreement',{},function(res){
          if(res.status==1){
              that.setData({
                  hidem:1
              });
          }else{
            if(res.status==-1){
              wx.navigateTo({
                url: '/pages/auth/index',
              })
            }
          }
        });
      }
    },
    cb:function(e){
      let that = this;
      if(that.data.cb==0){
        that.setData({
          cb:1
        })
      }else{
        that.setData({
          cb:0
        })
      }
    },
    pass(e){
      let t = this;
      t.setData({
        uid:e.currentTarget.dataset.uid,
        hidem:0,
        custom_id:e.currentTarget.dataset.custom_id,
        business:e.currentTarget.dataset.business,
        category:e.currentTarget.dataset.category,
        pa:'pass'
      });
    },
    reject(e){
      let t = this;
      t.setData({
        uid:e.currentTarget.dataset.uid,
        hidem:0,
        custom_id:e.currentTarget.dataset.custom_id,
        business:e.currentTarget.dataset.business,
        category:e.currentTarget.dataset.category,
        pa:'refuse'
      });
    },
    //表单提交
    formSubmit(data){
      let t = this;
      let arr = data.detail.value;
      u.post(app.globalData.url+'api/miniprogram/index',{'pa':t.data.pa,'method':'check_agent','uid':t.data.uid,'typp':t.data.agent_user.agent_content.type,'trade_amount':arr['trade_amount'],'category':t.data.category,'contents':arr['contents']}).then(res => {
        if(res.data.code==0){
          wx.showToast({
            title: res.data.msg,
            icon:'none'
          });
          u.post(app.globalData.url+'api/miniprogram/index',{'method':'manage_agent','uid':25}).then(res => {
            // console.log(res);
            t.setData({
              list:res.data.list,
              agent_user:res.data.user,
              hidem:1
            });
          });
        }
      });
    },
 
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      let t = this;
      // 25
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'manage_agent','uid':wx.getStorageSync('uid')}).then(res => {
        // console.log(res);
        t.setData({
          list:res.data.list,
          agent_user:res.data.user
        });
      });
    },
 
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
 
    },
 
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
 
    },
 
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
 
    },
 
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
 
    },
 
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
 
    },
 
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
 
    },
 
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
 
    }
})