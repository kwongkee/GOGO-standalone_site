var u = require('../../../utils/util.js');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    category:['物流服务','仓储服务','电商服务'],
    category_index:[1,2,3],
    category_act:0,
    info:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_info','uid':wx.getStorageSync('uid')}).then(res => {
      t.setData({
        info:res.data.acc
      });
    });
  },

  //业务方式
  category_method(data){
    this.setData({
      category_act:data.detail.value,
    });
    // u.dd(data);
  },

  //表单提交
  formSubmit(data){
    let t = this;
    let arr = data.detail.value;
    let agent_phone = arr['agent_phone'];let category_method = t.data.category_index[arr['category_method']];
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'apply_distr','uid':wx.getStorageSync('uid'),'number':agent_phone,'category':category_method}).then(res => {
      if(res.data.code==-1){
        wx.showToast({
          title: res.data.msg,
          icon:'error'
        });
      }else if(res.data.code==0){
        wx.showToast({
          title: res.data.msg,
          icon:'none'
        });
      }
      wx.navigateBack({
        delta: 1
      });
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})