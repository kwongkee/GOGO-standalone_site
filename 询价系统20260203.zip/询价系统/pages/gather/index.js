var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    gather_url:'',
    is_intro:1
  },
  //订阅消息
  subscribeMsg(){
    wx.getSetting({
      withSubscriptions: true,
      success (res2) {
        wx.requestSubscribeMessage({
          tmplIds:wx.getStorageSync('template_id')
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    // let nav_id = options.id;//扫码进来的id
    let res= decodeURIComponent(options.scene);//扫码进来的id
    let nav_id = res.split("=")[1];
    if(typeof(nav_id)=='undefined'){
      u.post(app.globalData.url+'api/miniprogram/index',{'method':'crossborder_info','type':2}).then(res => {
        for (let i = 0; i < res.data.info2.content.length; i++) {
          WxParse.wxParse('content' + i, 'html', res.data.info2.content[i], t);
          if (i === res.data.info2.content.length - 1) {
            WxParse.wxParseTemArray("content",'content', res.data.info2.content.length, t);
          }
        }
        
        t.setData({
          info2:res.data.info2,
          is_intro:1
        });
        // WxParse.wxParse('article', 'html', res.data.info2.content, t, 5);
      });
      return false;
    }else{
      t.setData({
        is_intro:0
      });
    }
    if(wx.getStorageSync('sns_openid')==''){
      wx.redirectTo({
        url:"/pages/login/index"
      });
    }
    t.subscribeMsg();
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'get_gather_info','nav_id':nav_id}).then(res => {
      t.setData({
        gather_url:res.data.info.url+'&uid='+wx.getStorageSync('uid'),
      });
    });
  },
  homenav(e){
    let t = this;
    wx.navigateTo({
      url: '/pages/home/index',
    });
  },
  bindnav(e){
    let t = this;
    if(e.currentTarget.dataset.type2==3){
      wx.switchTab({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==2){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==1){
      if(wx.getStorageSync('sns_openid')==''){
        wx.redirectTo({
          url:"/pages/login/index"
        });
        return false;
      }
      t.subscribeMsg();
      wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
      wx.navigateTo({
        url: '/pages/agreement/index',
      });
    }
    // if(wx.getStorageSync('sns_openid')==''){
    //   wx.redirectTo({
    //     url:"/pages/login/index"
    //   });
    //   return false;
    // }
    // t.subscribeMsg();
    // wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
    // wx.navigateTo({
    //   url: '/pages/agreement/index',
    // })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})