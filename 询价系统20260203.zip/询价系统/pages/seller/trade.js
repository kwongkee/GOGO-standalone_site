// pages/transaction/transaction.js
Page({
  data: {
    // 统计数据
    pendingOrders: 5,
    todayOrders: 12,
    pendingDeliveries: 3,
    inTransit: 8,
    pendingReturns: 2,
    monthReturns: 7,
    todayRevenue: '¥1,850',
    deliveryRate: 85,
    
    // 控制显示
    showOverview: true,
    
    // 动画控制
    cardAnimation: []
  },

  onLoad: function() {
    // this.initData();
    // this.startAnimations();
  },

  onShow: function() {
    // 每次页面显示时刷新数据
    // this.refreshData();
  },

  // 初始化数据
  initData: function() {
    // 这里应该从服务器获取实际数据
    // 模拟数据
    const mockData = {
      pendingOrders: Math.floor(Math.random() * 10) + 1,
      todayOrders: Math.floor(Math.random() * 20) + 5,
      pendingDeliveries: Math.floor(Math.random() * 5) + 1,
      inTransit: Math.floor(Math.random() * 10) + 3,
      pendingReturns: Math.floor(Math.random() * 4) + 1,
      monthReturns: Math.floor(Math.random() * 15) + 5,
      todayRevenue: `¥${(Math.random() * 3000 + 1000).toFixed(0)}`,
      deliveryRate: Math.floor(Math.random() * 20) + 80
    };
    
    this.setData(mockData);
  },

  // 刷新数据
  refreshData: function() {
    // wx.showLoading({
    //   title: '刷新中...',
    // });
    
    // // 模拟网络请求
    // setTimeout(() => {
    //   this.initData();
    //   wx.hideLoading();
    //   wx.showToast({
    //     title: '数据已更新',
    //     icon: 'success',
    //     duration: 1500
    //   });
    // }, 1000);
  },

  // 开始动画
  startAnimations: function() {
    const animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease',
    });
    
    this.animation = animation;
  },

  // 导航到卖家下单页面
  navigateToSellerOrder: function() {
    wx.navigateTo({
      url: '/pages/orderfood/index?is_seller=1',
    });
  },

  // 导航到卖家交付页面
  navigateToSellerDelivery: function() {
    wx.navigateTo({
      url: '/pages/seller/delivery',
      success: () => {
        // this.addClickFeedback(1);
      }
    });
  },

  // 导航到退货管理页面
  navigateToReturnManagement: function() {
    wx.navigateTo({
      url: '/pages/seller/return',
      success: () => {
        // this.addClickFeedback(2);
      }
    });
  },

  // 下拉刷新
  onPullDownRefresh: function() {
    this.refreshData();
    setTimeout(() => {
      wx.stopPullDownRefresh();
    }, 1000);
  },

  // 页面滚动
  onPageScroll: function(e) {
    // 可以根据滚动位置添加视差效果
    if (e.scrollTop > 50) {
      this.setData({
        showOverview: false
      });
    } else {
      this.setData({
        showOverview: true
      });
    }
  }
});