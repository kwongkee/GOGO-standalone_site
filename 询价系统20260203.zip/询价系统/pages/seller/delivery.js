// pages/index/index.js
Page({
  data: {
    
  },

  onLoad: function() {
    
  },

  navigateToPendingOrders: function() {
    wx.navigateTo({
      url: '/pages/seller/pending_orders'
    });
  },

  navigateToPendingDelivery: function() {
    wx.navigateTo({
      url: '/pages/seller/pending_delivery'
    });
  }
});