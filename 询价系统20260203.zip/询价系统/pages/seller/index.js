// pages/seller/index.js
const app = getApp();
const u = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    is_merchant:0,
    selected_company:0,
    companyIndex:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;

    //检测是否有企业的卖家
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'check_seller',
      'id': wx.getStorageSync('uid'),
    }).then(res => {
      if(res.data.code==0){
        t.setData({
          is_merchant: res.data.is_merchant,
        });

        if(res.data.is_merchant==1){
          t.setData({
            company:res.data.company,
            selected_company:res.data.company[0].id,
            currentCompany:res.data.company[0]
          });

          // 保存到本地存储，作为默认企业
          wx.setStorageSync('default_company_id', res.data.company[0].id);
          wx.setStorageSync('default_company_name', res.data.company[0].company);
        }
      }
    });
  },

  is_login(){
    let t = this;
    if(wx.getStorageSync('sns_openid')==''){
      wx.setStorageSync('to_pages', '/pages/seller/index');

      wx.navigateTo({
        url:"/pages/login/index"
      });
      return false;
    }
  },

  /**
   * 企业选择器改变事件
   */
  companyPickerChange: function(e) {
    let t = this;
    const index = e.detail.value;
    const companyList = t.data.company;
    
    if(index >= 0 && index < companyList.length) {
      const selectedCompany = companyList[index];
      
      t.setData({
        companyIndex: index,
        currentCompany: selectedCompany,
        selected_company: selectedCompany.id
      });
      
      // 保存到本地存储，作为默认企业
      wx.setStorageSync('default_company_id', selectedCompany.id);
      wx.setStorageSync('default_company_name', selectedCompany.company);
      
      // 显示成功提示
      wx.showToast({
        title: `已切换到${selectedCompany.company}`,
        icon: 'none',
        duration: 2000
      });
    }
  },

  /**
   * 点击指示器切换企业
   */
  switchCompany: function(e) {
    let t = this;
    const index = e.currentTarget.dataset.index;
    const companyList = t.data.company;
    
    if(index >= 0 && index < companyList.length) {
      const selectedCompany = companyList[index];
      
      t.setData({
        companyIndex: index,
        currentCompany: selectedCompany,
        selected_company: selectedCompany.id
      });
      
      // 保存到本地存储
      wx.setStorageSync('default_company_id', selectedCompany.id);
      wx.setStorageSync('default_company_name', selectedCompany.company);
      
      // 重新加载统计数据
      t.loadStatistics();
      
      // 添加微动画效果
      wx.showToast({
        title: `企业已切换`,
        icon: 'success',
        duration: 1500
      });
    }
  },

  /**
   * 跳转到交易管理页面
   */
  goToTrade: function() {
    wx.navigateTo({
      url: '/pages/seller/trade',
      success: function(res) {
        console.log('跳转到交易管理页面成功');
      },
      fail: function(err) {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 跳转到活动管理页面
   */
  goToCampaign: function() {
    wx.navigateTo({
      url: '/pages/seller/campaign'
    });
  },

  /**
   * 跳转到上架管理页面
   */
  goToListing: function() {
    wx.navigateTo({
      url: '/pages/seller/listing',
      success: function(res) {
        console.log('跳转到上架管理页面成功');
      },
      fail: function(err) {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '页面不存在',
          icon: 'none'
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    let t = this;
    //检测有无登录
    t.is_login();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})