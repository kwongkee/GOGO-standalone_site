var u = require('../../utils/util.js');
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let t = this;
    u.post(app.globalData.url+'api/miniprogram/index',{'method':'crossborder_info','type':4}).then(res => {
      for (let i = 0; i < res.data.info2.content.length; i++) {
        WxParse.wxParse('content' + i, 'html', res.data.info2.content[i], t);
        if (i === res.data.info2.content.length - 1) {
          WxParse.wxParseTemArray("content",'content', res.data.info2.content.length, t);
        }
      }
      
      t.setData({
        link:res.data.info,
        info2:res.data.info2
      });
      // WxParse.wxParse('article', 'html', res.data.info2.content, t, 5);
    });
  },
  bindnav(e){
    let t = this;
    
    if(e.currentTarget.dataset.type2==3){
      wx.switchTab({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==2){
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      });
    }else if(e.currentTarget.dataset.type2==1){
      if(wx.getStorageSync('sns_openid')==''){
        wx.redirectTo({
          url:"/pages/login/index"
        });
        return false;
      }
      wx.setStorageSync('agreement_url', e.currentTarget.dataset.url+'&miniprogram=1&uid='+wx.getStorageSync('uid'));
      wx.navigateTo({
        url: '/pages/agreement/index',
      });
    }
  },
  con1(){
    wx.navigateTo({
      url: '/pages/index/index',
    })
  },
  con2(){
    wx.navigateTo({
      url: '/pages/gather/index',
    })
  },
  con3(){
    wx.navigateTo({
      url: '/pages/my/index',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})