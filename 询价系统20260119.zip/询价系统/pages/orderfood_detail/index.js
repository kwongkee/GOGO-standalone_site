// pages/detail/detail.js
Page({
  data: {
    product: {},
    quantity: 1,
    subtotal: 0,
    
    // 轮播图当前索引
    currentSwiper: 0,

    // 折叠状态
    specExpanded: false,
    paramsExpanded: false,
    reviewsExpanded: false,
    detailImagesExpanded: false,

    // 选中规格
    selectedSpec: {},
    
    // 购物车数量
    cartCount: 3,

    // 弹窗控制
    showPayModal: false,
    showScanModal: false,
    showOnlinePayModal: false,
    showResultModal: false,
    
    // 支付相关
    payMethod: 'wechat',
    paySuccess: false,
    resultMessage: '',
    
    // 模拟商品数据
    mockProducts: [
      {
        id: 1,
        name: '招牌牛肉汉堡',
        description: '双层牛肉饼搭配特制酱料，精选进口牛肉，手工制作，肉质鲜嫩多汁，搭配新鲜蔬菜和特调酱料，口感丰富，层次分明。',
        price: 38,
        originalPrice: 45,
        images: [
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png'
        ],
        categoryId: 1,
        sales: 1250,
        rating: 4.8,
        reviewCount: 3,
        isHot: true,
        isNew: false,
        isRecommend: true,
        tags: ['招牌', '热销', '推荐'],
        preparationTime: 10,
        
        // 默认规格
        defaultSpec: {
          id: 1,
          name: '标准版',
          price: 38
        },
        
        // 所有规格
        specs: [
          { id: 1, name: '标准版', price: 38 },
          { id: 2, name: '加料版', price: 48 },
          { id: 3, name: '豪华版', price: 58 },
          { id: 4, name: '双人套餐', price: 68 },
          { id: 5, name: '儿童套餐', price: 28 }
        ],
        
        // 商品参数
        params: [
          { key: '生产企业名称', value: '佛山市食品有限公司' },
          { key: '保质期', value: '12个月' },
          { key: '生产日期', value: '2023-10-01' },
          { key: '储存条件', value: '常温干燥处保存' },
          { key: '配料表', value: '牛肉、面粉、蔬菜等' },
          { key: '净含量', value: '350g' },
          { key: '产地', value: '广东佛山' },
          { key: '生产许可证号', value: 'SC123456789' }
        ],
        
        // 商品评价
        reviews: [
          {
            id: 1,
            name: '张先生',
            avatar: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
            rating: 5,
            time: '2023-10-15',
            content: '非常好吃！牛肉很嫩，面包也很软，配上特制酱料简直绝配！',
            images: [
              'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
              'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png'
            ]
          },
          {
            id: 2,
            name: '李女士',
            avatar: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
            rating: 4,
            time: '2023-10-10',
            content: '味道不错，就是份量稍微有点少，希望能增加一些蔬菜。',
            images: [
              'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png'
            ]
          },
          {
            id: 3,
            name: '王同学',
            avatar: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
            rating: 5,
            time: '2023-10-05',
            content: '经常来吃，汉堡很大一个，性价比很高，强烈推荐！',
            images: []
          }
        ],
        
        // 商品详情图
        detailImages: [
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
          'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png'
        ],
        
        nutrition: [
          { name: '热量', value: '450千卡' },
          { name: '蛋白质', value: '25g' },
          { name: '脂肪', value: '18g' },
          { name: '碳水化合物', value: '45g' }
        ]
      },
    ]
  },

  onLoad(options) {
    const { id, quantity = 1 } = options;
    this.loadProduct(parseInt(id));
    
    // 设置初始数量
    this.setData({
      quantity: parseInt(quantity) || 1
    }, () => {
      this.calculateSubtotal();
    });
  },

  // 加载商品信息
  loadProduct(id) {
    // 从模拟数据中查找商品
    const product = this.data.mockProducts.find(item => item.id === id) || this.data.mockProducts[0];
    this.setData({ 
      product,
      selectedSpec: product.defaultSpec || product.specs[0]
    }, () => {
      this.calculateSubtotal();
    });
  },

  // 轮播图切换
  swiperChange(e) {
    this.setData({
      currentSwiper: e.detail.current
    });
  },

  // 预览图片
  previewImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.product.images || [this.data.product.image];
    
    wx.previewImage({
      current: images[index],
      urls: images
    });
  },

  // 预览评价图片
  previewReviewImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = e.currentTarget.dataset.images;
    
    wx.previewImage({
      current: images[index],
      urls: images
    });
  },

  // 预览详情图片
  previewDetailImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = e.currentTarget.dataset.images;
    
    wx.previewImage({
      current: images[index],
      urls: images
    });
  },

  // 返回上一页
  goBack() {
    wx.navigateBack();
  },

  // 切换规格展开状态
  toggleSpecExpand() {
    this.setData({
      specExpanded: !this.data.specExpanded
    });
  },

  // 选择规格
  selectSpec(e) {
    const spec = e.currentTarget.dataset.spec;
    this.setData({
      selectedSpec: spec
    }, () => {
      this.calculateSubtotal();
      
      // 如果规格是折叠状态，选择后自动收起
      if (this.data.specExpanded) {
        this.setData({
          specExpanded: false
        });
      }
    });
  },

  // 切换参数展开状态
  toggleParamsExpand() {
    this.setData({
      paramsExpanded: !this.data.paramsExpanded
    });
  },

  // 切换评价展开状态
  toggleReviewsExpand() {
    this.setData({
      reviewsExpanded: !this.data.reviewsExpanded
    });
  },

  // 切换详情图展开状态
  toggleDetailImagesExpand() {
    this.setData({
      detailImagesExpanded: !this.data.detailImagesExpanded
    });
  },

  // 数量操作
  increaseQuantity() {
    const quantity = this.data.quantity + 1;
    if (quantity <= 99) {
      this.setData({ quantity }, () => {
        this.calculateSubtotal();
      });
    }
  },

  decreaseQuantity() {
    const quantity = this.data.quantity - 1;
    if (quantity >= 1) {
      this.setData({ quantity }, () => {
        this.calculateSubtotal();
      });
    }
  },

  onQuantityInput(e) {
    const value = parseInt(e.detail.value) || 1;
    const quantity = Math.max(1, Math.min(99, value));
    this.setData({ quantity }, () => {
      this.calculateSubtotal();
    });
  },

  // 计算小计
  calculateSubtotal() {
    const subtotal = this.data.product.price * this.data.quantity;
    this.setData({ subtotal });
  },

  // 跳转到购物车
  goToCart() {
    wx.switchTab({
      url: '/pages/cart/cart'
    });
  },

  // 提交订单
  submitOrder() {
    if (this.data.quantity < 1) {
      wx.showToast({
        title: '请选择至少1件商品',
        icon: 'none'
      });
      return;
    }

    this.setData({
      showPayModal: true
    });
  },

  // 关闭支付方式选择弹窗
  closePayModal() {
    this.setData({
      showPayModal: false
    });
  },

  // 选择扫码支付
  chooseScanPay() {
    this.setData({
      showPayModal: false,
      showScanModal: true
    });
  },

  // 选择在线支付
  chooseOnlinePay() {
    this.setData({
      showPayModal: false,
      showOnlinePayModal: true,
      payMethod: 'wechat' // 默认选择微信支付
    });
  },

  // 关闭扫码支付弹窗
  closeScanModal() {
    this.setData({
      showScanModal: false,
      showCamera: false,
      scanStatus: 'idle'
    });
    this.stopCamera();
  },

  // 关闭在线支付弹窗
  closeOnlinePayModal() {
    this.setData({
      showOnlinePayModal: false
    });
  },

  // 选择支付方式
  selectPayMethod(e) {
    const method = e.currentTarget.dataset.method;
    this.setData({
      payMethod: method
    });
  },

  // 开始扫码支付（核心函数）
  startScanCode() {
    this.checkCameraPermission();
  },

  // 检查相机权限
  checkCameraPermission() {
    wx.getSetting({
      success: (res) => {
        // 检查是否已授权相机权限
        if (res.authSetting['scope.camera']) {
          // 已授权，打开相机
          this.openCamera();
        } else if (res.authSetting['scope.camera'] === false) {
          // 已拒绝授权，引导用户打开设置
          this.showAuthModal();
        } else {
          // 未请求过授权，请求授权
          this.requestCameraAuth();
        }
      },
      fail: (err) => {
        console.error('获取权限设置失败:', err);
        wx.showToast({
          title: '获取权限失败',
          icon: 'none'
        });
      }
    });
  },

  // 显示授权引导弹窗
  showAuthModal() {
    wx.showModal({
      title: '需要相机权限',
      content: '扫码支付需要使用相机权限，请点击确定前往设置开启',
      confirmText: '去设置',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          // 打开设置页面
          wx.openSetting({
            success: (settingRes) => {
              if (settingRes.authSetting['scope.camera']) {
                this.openCamera();
              } else {
                wx.showToast({
                  title: '需要相机权限才能扫码',
                  icon: 'none'
                });
              }
            }
          });
        }
      }
    });
  },

  // 请求相机授权
  requestCameraAuth() {
    wx.authorize({
      scope: 'scope.camera',
      success: () => {
        // 授权成功，打开相机
        this.openCamera();
      },
      fail: (err) => {
        console.error('相机授权失败:', err);
        if (err.errMsg.includes('auth deny')) {
          this.showAuthModal();
        } else {
          wx.showToast({
            title: '相机授权失败',
            icon: 'none'
          });
        }
      }
    });
  },

  // 打开相机
  openCamera() {
    // 更新状态显示相机界面
    this.setData({
      showCamera: true,
      scanStatus: 'scanning'
    });

    // 创建相机上下文
    const cameraContext = wx.createCameraContext();
    this.setData({ cameraContext });

    // 设置扫码监听
    this.startScanListener();
  },

  // 开始扫码监听
  startScanListener() {
    if (!this.data.cameraContext) return;

    // 开始扫码识别
    this.data.cameraContext.onCameraFrame((frame) => {
      // 这里可以处理相机帧数据（如果需要本地识别）
      // 但微信小程序推荐使用 wx.scanCode
    });

    // 使用微信官方扫码API（推荐）
    wx.showLoading({
      title: '正在打开相机...',
    });

    // 延迟确保相机已加载
    setTimeout(() => {
      wx.hideLoading();
      this.scanQRCode();
    }, 500);
  },

   // 使用微信官方扫码功能
   scanQRCode() {
    wx.scanCode({
      onlyFromCamera: true, // 只允许从相机扫码
      scanType: ['qrCode'], // 只扫描二维码
      success: (res) => {
        console.log('扫码结果:', res);
        this.handleScanResult(res);
      },
      fail: (err) => {
        console.error('扫码失败:', err);
        this.setData({
          scanStatus: 'error'
        });
        
        // 根据错误类型给出提示
        if (err.errMsg.includes('scanCode:fail auth deny')) {
          wx.showToast({
            title: '相机权限被拒绝',
            icon: 'none'
          });
        } else if (err.errMsg.includes('scanCode:fail')) {
          wx.showToast({
            title: '扫码失败，请重试',
            icon: 'none'
          });
        }
      },
      complete: () => {
        // 扫码完成后可以重新开启扫码
        // 这里我们不自动重新开始，让用户手动操作
      }
    });
  },

  // 处理扫码结果
  handleScanResult(scanResult) {
    this.setData({
      scanStatus: 'success',
      scanResult: scanResult
    });

    // 解析扫码结果
    const { result, scanType } = scanResult;
    
    // 这里根据实际业务逻辑处理不同的二维码内容
    // 假设扫码得到的是支付链接或支付参数
    
    if (result && result.includes('http')) {
      // 如果是支付链接，处理支付
      this.processPayment(result);
    } else if (result && result.startsWith('{')) {
      // 如果是JSON格式的支付参数
      try {
        const paymentData = JSON.parse(result);
        this.processPaymentData(paymentData);
      } catch (e) {
        this.handleInvalidQRCode();
      }
    } else {
      // 其他格式，提示用户
      this.handleUnknownQRCode(result);
    }
  },

  // 处理支付
  processPayment(paymentUrl) {
    // 显示支付确认
    wx.showModal({
      title: '确认支付',
      content: `扫描到支付链接，是否确认支付 ¥${this.data.subtotal}？`,
      confirmText: '确认支付',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          this.startPaymentProcess(paymentUrl);
        } else {
          // 用户取消，重置扫码状态
          this.setData({
            scanStatus: 'scanning'
          });
        }
      }
    });
  },

  // 处理支付数据
  processPaymentData(paymentData) {
    // 这里根据实际支付接口处理
    // 示例：假设支付数据包含订单信息和支付参数
    console.log('支付数据:', paymentData);
    
    wx.showModal({
      title: '确认支付',
      content: `确认支付 ¥${this.data.subtotal}？`,
      success: (res) => {
        if (res.confirm) {
          this.callPaymentAPI(paymentData);
        }
      }
    });
  },

  // 调用支付API
  callPaymentAPI(paymentData) {
    wx.showLoading({
      title: '正在支付...',
      mask: true
    });

    // 模拟支付API调用
    setTimeout(() => {
      wx.hideLoading();
      
      // 模拟支付结果（实际项目中替换为真实API调用）
      const success = Math.random() > 0.2; // 80%成功率
      
      if (success) {
        this.showPaymentResult(true, '支付成功！');
      } else {
        this.showPaymentResult(false, '支付失败，请重试');
      }
      
      // 关闭相机
      this.stopCamera();
    }, 2000);
  },

  // 开始支付流程
  startPaymentProcess(paymentUrl) {
    wx.showLoading({
      title: '正在支付...',
      mask: true
    });

    // 实际项目中，这里应该调用真实的支付接口
    // 示例：跳转到支付页面或调用支付API
    setTimeout(() => {
      wx.hideLoading();
      
      // 模拟支付成功
      const success = Math.random() > 0.2;
      
      if (success) {
        // 支付成功，显示结果
        this.showPaymentResult(true, '支付成功！');
      } else {
        // 支付失败
        this.showPaymentResult(false, '支付失败，请重试');
      }
      
      // 关闭相机
      this.stopCamera();
    }, 2000);
  },

  // 处理无效二维码
  handleInvalidQRCode() {
    wx.showModal({
      title: '二维码无效',
      content: '请扫描有效的支付二维码',
      showCancel: false,
      success: () => {
        this.setData({
          scanStatus: 'scanning'
        });
        // 重新开始扫码
        setTimeout(() => {
          this.scanQRCode();
        }, 500);
      }
    });
  },

  // 处理未知格式二维码
  handleUnknownQRCode(codeContent) {
    wx.showModal({
      title: '二维码内容',
      content: `扫描结果: ${codeContent.substring(0, 50)}...`,
      confirmText: '确认支付',
      cancelText: '重新扫描',
      success: (res) => {
        if (res.confirm) {
          // 用户确认，尝试处理
          this.startPaymentProcess(codeContent);
        } else {
          // 重新扫描
          this.setData({
            scanStatus: 'scanning'
          });
          setTimeout(() => {
            this.scanQRCode();
          }, 500);
        }
      }
    });
  },

  // 显示支付结果
  showPaymentResult(success, message) {
    this.setData({
      showScanModal: false,
      showCamera: false,
      showResultModal: true,
      paySuccess: success,
      resultMessage: success 
        ? `${message} 您已支付¥${this.data.subtotal}，我们将尽快为您准备商品。`
        : message,
      scanStatus: 'idle'
    });
  },

  // 停止相机
  stopCamera() {
    if (this.data.cameraContext) {
      // 停止相机帧监听
      this.data.cameraContext.stopRecord();
      this.setData({
        cameraContext: null
      });
    }
  },

  // 重新扫码
  rescan() {
    this.setData({
      scanStatus: 'scanning',
      scanResult: null
    });
    this.scanQRCode();
  },

  // 确认在线支付
  confirmPay() {
    this.startPaymentProcess();
  },

  // 处理支付结果
  handleResult() {
    if (this.data.paySuccess) {
      // 支付成功，跳转到订单页面
      wx.redirectTo({
        url: '/pages/order/order'
      });
    } else {
      // 支付失败，重新选择支付方式
      this.setData({
        showResultModal: false,
        showPayModal: true
      });
    }
  },

  // 返回首页
  goToHome() {
    wx.navigateTo({
      url: '/pages/orderfood/index'
    });
  }
});