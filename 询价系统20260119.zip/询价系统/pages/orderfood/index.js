// index.js - 增加规格选择功能
Page({
  data: {
    categories: [
      { id: 1, name: '热销推荐', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 2, name: '套餐系列', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 3, name: '招牌菜', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 4, name: '饮料甜品', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' },
      { id: 5, name: '主食', icon: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png' }
    ],
    foods: [],  // 所有商品数据
    filteredFoods: [],  // 当前分类的商品
    activeCategory: 1,
    currentCategoryName: '热销推荐',
    totalQuantity: 0,  // 总数量
    totalPrice: 0,     // 总价格
    orderItems: [],    // 下单商品列表
    
    // 规格选择弹窗相关
    showSpecModal: false,
    currentSpecs: [],  // 当前商品的规格列表
    currentFoodIndex: -1,  // 当前商品在filteredFoods中的索引
    currentFoodId: null,   // 当前商品ID
    currentSpecIndex: 0,   // 当前选中的规格索引
    modalQuantity: 1,      // 弹窗中的数量
    modalFoodIndex: -1,     // 弹窗对应商品索引

    orderItemsExpanded: false,  // 订单项是否展开
    displayOrderItems: [],      // 用于显示的订单项数组，包含规格信息
  },

  onLoad() {
    this.loadFoods();
    // 初始化加载第一个分类的商品
    this.filterFoodsByCategory(1);
    // 计算初始总价和总数
    this.calculateTotal();
  },

  onShow() {
    // 页面显示时重新计算总数和总价
    this.calculateTotal();
  },

  // 切换分类
  switchCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    const category = this.data.categories.find(c => c.id === categoryId);
    
    this.setData({
      activeCategory: categoryId,
      currentCategoryName: category ? category.name : ''
    });
    
    // 过滤商品
    this.filterFoodsByCategory(categoryId);
  },

  // 根据分类过滤商品
  filterFoodsByCategory(categoryId) {
    const filteredFoods = this.data.foods.filter(item => item.categoryId === categoryId);
    this.setData({ filteredFoods });
  },

  // 跳转到详情页
  goToDetail(e) {
    const foodId = e.currentTarget.dataset.id;
    const food = this.data.foods.find(item => item.id === foodId);
    
    if (food) {
      wx.navigateTo({
        url: `/pages/orderfood_detail/index?id=${foodId}&quantity=${food.quantity || 0}`
      });
    }
  },

  // 显示规格选择弹窗
  showSpecModal(e) {
    const index = e.currentTarget.dataset.index;
    const food = this.data.filteredFoods[index];
    
    if (food && food.specifications && food.specifications.length > 0) {
      // 设置默认选中的规格（第一个）
      const selectedSpecIndex = food.selectedSpecIndex !== undefined ? food.selectedSpecIndex : 0;
      
      this.setData({
        showSpecModal: true,
        currentSpecs: food.specifications,
        currentFoodIndex: index,
        currentFoodId: food.id,
        currentSpecIndex: selectedSpecIndex,
        modalQuantity: food.quantity || 1,
        modalFoodIndex: index
      });
    }
  },

  // 隐藏规格选择弹窗
  hideSpecModal() {
    this.setData({
      showSpecModal: false
    });
  },

  // 阻止事件冒泡
  stopPropagation() {
    return;
  },

  // 选择规格
  selectSpec(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      currentSpecIndex: index
    });
  },

  // 弹窗中增加数量
  modalIncreaseQuantity() {
    const newQuantity = this.data.modalQuantity + 1;
    this.setData({
      modalQuantity: newQuantity
    });
  },

  // 弹窗中减少数量
  modalDecreaseQuantity() {
    if (this.data.modalQuantity > 1) {
      const newQuantity = this.data.modalQuantity - 1;
      this.setData({
        modalQuantity: newQuantity
      });
    }
  },

  // 弹窗中数量输入
  onModalQuantityInput(e) {
    const value = parseInt(e.detail.value) || 1;
    if (value >= 1) {
      this.setData({
        modalQuantity: value
      });
    }
  },

  // 确认规格选择
  confirmSpec() {
    const { currentFoodIndex, currentSpecIndex, modalQuantity, currentFoodId } = this.data;
    
    if (currentFoodIndex === -1) return;
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 更新foods中的规格和数量
    const foodIndex = foods.findIndex(item => item.id === currentFoodId);
    if (foodIndex !== -1) {
      foods[foodIndex].selectedSpecIndex = currentSpecIndex;
      foods[foodIndex].quantity = modalQuantity;
    }
    
    // 更新filteredFoods中的规格和数量
    if (filteredFoods[currentFoodIndex]) {
      filteredFoods[currentFoodIndex].selectedSpecIndex = currentSpecIndex;
      filteredFoods[currentFoodIndex].quantity = modalQuantity;
    }
    
    this.setData({
      foods,
      filteredFoods,
      showSpecModal: false
    }, () => {
      this.calculateTotal();
    });
  },

  // 增加数量（原有方法，需修改）
  increaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 检查商品是否有规格且已选择规格
    const food = filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      filteredFoods[index].quantity = (filteredFoods[index].quantity || 0) + 1;
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = filteredFoods[index].quantity;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 减少数量（原有方法，需修改）
  decreaseQuantity(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 检查商品是否有规格且已选择规格
    const food = filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      const currentQuantity = filteredFoods[index].quantity || 0;
      if (currentQuantity > 0) {
        filteredFoods[index].quantity = currentQuantity - 1;
      }
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = filteredFoods[index].quantity;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 输入框数量变化（原有方法，需修改）
  onQuantityInput(e) {
    const foodId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    const value = parseInt(e.detail.value) || 0;
    
    if (value < 0) return;
    
    // 检查商品是否有规格且已选择规格
    const food = this.data.filteredFoods[index];
    if (food && food.specifications && food.specifications.length > 0 && food.selectedSpecIndex === undefined) {
      wx.showToast({
        title: '请先选择规格',
        icon: 'none'
      });
      return;
    }
    
    let foods = this.data.foods;
    let filteredFoods = this.data.filteredFoods;
    
    // 更新filteredFoods中的数量
    if (index !== undefined && filteredFoods[index]) {
      filteredFoods[index].quantity = value;
    }
    
    this.setData({ filteredFoods }, () => {
      // 同步到foods数组
      const foodIndex = foods.findIndex(item => item.id === foodId);
      if (foodIndex !== -1) {
        foods[foodIndex].quantity = value;
        this.setData({ foods });
      }
      this.calculateTotal();
    });
  },

  // 计算总价和总数（修改以支持规格价格）
  calculateTotal() {
    let totalQuantity = 0;
    let totalPrice = 0;
    let orderItems = [];
    let displayOrderItems = [];
    
    this.data.foods.forEach(item => {
      const quantity = item.quantity || 0;
      if (quantity > 0) {
        // 计算商品价格：有规格的用规格价格，无规格的用基础价格
        let itemPrice = item.price;
        let specName = '';
        let image = item.image;
        
        if (item.specifications && item.specifications.length > 0 && item.selectedSpecIndex !== undefined) {
          const selectedSpec = item.specifications[item.selectedSpecIndex];
          itemPrice = selectedSpec.price;
          specName = selectedSpec.name;
        }
        
        totalQuantity += quantity;
        totalPrice += itemPrice * quantity;
        
        // 存储订单项
        orderItems.push({
          id: item.id,
          name: item.name,
          price: itemPrice,
          quantity: quantity,
          image: image,
          specifications: item.specifications,
          selectedSpecIndex: item.selectedSpecIndex
        });
        
        // 构建显示用的数据
        displayOrderItems.push({
          name: item.name,
          specName: specName,
          quantity: quantity,
          price: itemPrice,
          image: image
        });
      }
    });
    
    this.setData({
      totalQuantity,
      totalPrice: totalPrice.toFixed(2),
      orderItems,
      displayOrderItems
    });
  },

  // 添加切换展开/收起的方法
  toggleOrderItemsExpand(e) {
    this.setData({
      orderItemsExpanded: !this.data.orderItemsExpanded
    });
  },

  // 跳转到下单页面
  goToOrder() {
    // 如果订单项是展开状态，先收起
    if (this.data.orderItemsExpanded) {
      this.setData({
        orderItemsExpanded: false
      });
      
      // 延迟执行跳转，让收起动画完成
      setTimeout(() => {
        this.navigateToOrder();
      }, 300);
    } else {
      this.navigateToOrder();
    }
  },

  // 提取下单跳转逻辑
  navigateToOrder() {
    if (this.data.totalQuantity === 0) {
      wx.showToast({
        title: '请选择商品',
        icon: 'none'
      });
      return;
    }
    
    // 检查是否有商品未选择规格
    const unselectedSpecItems = this.data.orderItems.filter(item => 
      item.specifications && item.specifications.length > 0 && item.selectedSpecIndex === undefined
    );
    
    if (unselectedSpecItems.length > 0) {
      wx.showToast({
        title: '请为商品选择规格',
        icon: 'none'
      });
      return;
    }
    
    // 将订单数据存储到本地，供下单页面使用
    wx.setStorageSync('orderItems', this.data.orderItems);
    
    wx.navigateTo({
      url: '/pages/order/order'
    });
  },

  // 加载商品数据（增加规格数据）
  loadFoods() {
    // 模拟数据 - 确保每个商品都有正确的 categoryId
    const foods = [
      {
        id: 1,
        name: '招牌牛肉汉堡',
        description: '双层牛肉饼，特制酱料',
        price: 38,
        originalPrice: 45,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 1,
        sales: 1250,
        tags: ['招牌', '热销'],
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '常规尺寸', price: 38, originalPrice: 45 },
          { id: 2, name: '加大尺寸', price: 48, originalPrice: 55 },
          { id: 3, name: '套餐（含饮料）', price: 55, originalPrice: 65 }
        ],
        selectedSpecIndex: 0  // 默认选中第一个规格
      },
      {
        id: 2,
        name: '香辣鸡腿堡',
        description: '酥脆鸡腿肉，香辣可口',
        price: 28,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 1,
        sales: 980,
        tags: ['辣', '新品'],
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '常规尺寸', price: 28 },
          { id: 2, name: '加大尺寸', price: 35 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 3,
        name: '经典套餐A',
        description: '汉堡+薯条+可乐',
        price: 45,
        originalPrice: 58,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 2,
        sales: 850,
        quantity: 0,
        // 无规格的商品
        specifications: []
      },
      {
        id: 4,
        name: '双人分享套餐',
        description: '两份汉堡+大份薯条+两杯饮料',
        price: 78,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 2,
        sales: 620,
        quantity: 0,
        specifications: []
      },
      {
        id: 5,
        name: '特制烤鸭',
        description: '传统工艺，皮脆肉嫩',
        price: 88,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 3,
        sales: 450,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '半只', price: 88 },
          { id: 2, name: '整只', price: 168 },
          { id: 3, name: '整只+配菜', price: 198 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 6,
        name: '经典奶茶',
        description: '浓郁茶香，丝滑口感',
        price: 15,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 4,
        sales: 1200,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '中杯', price: 15 },
          { id: 2, name: '大杯', price: 18 },
          { id: 3, name: '特大杯', price: 22 }
        ],
        selectedSpecIndex: 0
      },
      {
        id: 7,
        name: '草莓奶昔',
        description: '新鲜草莓，冰凉清爽',
        price: 22,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 4,
        sales: 850,
        quantity: 0,
        specifications: []
      },
      {
        id: 8,
        name: '牛肉面',
        description: '大块牛肉，手工面条',
        price: 35,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 5,
        sales: 950,
        quantity: 0,
        specifications: []
      },
      {
        id: 9,
        name: '扬州炒饭',
        description: '粒粒分明，配料丰富',
        price: 25,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 5,
        sales: 780,
        quantity: 0,
        specifications: []
      },
      {
        id: 10,
        name: '芝士披萨',
        description: '厚芝士，香浓拉丝',
        price: 68,
        image: 'https://shop.gogo198.cn/collect_website/public/miniprogram/img/icon.png',
        categoryId: 3,
        sales: 520,
        quantity: 0,
        // 有规格的商品
        specifications: [
          { id: 1, name: '7寸', price: 68 },
          { id: 2, name: '9寸', price: 88 },
          { id: 3, name: '12寸', price: 128 }
        ],
        selectedSpecIndex: 0
      }
    ];
    
    this.setData({ foods });
  },

  // 搜索功能
  onSearch(e) {
    const keyword = e.detail.value;
    if (!keyword.trim()) {
      // 如果搜索词为空，显示当前分类的商品
      this.filterFoodsByCategory(this.data.activeCategory);
      return;
    }
    
    // 在所有商品中搜索
    const filteredFoods = this.data.foods.filter(item => 
      item.name.includes(keyword) || 
      item.description.includes(keyword) ||
      (item.tags && item.tags.some(tag => tag.includes(keyword)))
    );
    
    this.setData({ 
      filteredFoods,
      currentCategoryName: `搜索"${keyword}"`
    });
  },
});