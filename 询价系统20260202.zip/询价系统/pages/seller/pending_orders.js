const app = getApp();
const u = require('../../utils/util.js');

Page({
  data: {
    searchKeyword: '',
    activeFilter: 'all',
    orders: [
      {
        orderId: 'DD20230415001',
        pickupCode: 'A102',
        amount: '68.50',
        paymentMethod: 'wechat',
        orderTime: '14:30',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415002',
        pickupCode: 'B205',
        amount: '125.00',
        paymentMethod: 'cash',
        orderTime: '14:45',
        isUrgent: true,
        isToday: true
      },
      {
        orderId: 'DD20230414015',
        pickupCode: 'C301',
        amount: '42.00',
        paymentMethod: 'wechat',
        orderTime: '昨日 19:20',
        isUrgent: false,
        isToday: false
      },
      {
        orderId: 'DD20230415003',
        pickupCode: 'A105',
        amount: '89.00',
        paymentMethod: 'wechat',
        orderTime: '15:10',
        isUrgent: false,
        isToday: true
      },
      {
        orderId: 'DD20230415004',
        pickupCode: 'D401',
        amount: '156.80',
        paymentMethod: 'cash',
        orderTime: '15:25',
        isUrgent: true,
        isToday: true
      }
    ],
    filteredOrders: [],

    // 支付弹窗相关数据
    showPaymentModal: false,
    currentPayment: {
      orderId: '',
      orderSn: '',
      amount: '0.00',    // 应收金额
      income: '',        // 实收金额
      change: '0.00'     // 找零金额
    },
    autoFocusIncome: false
  },

  onLoad: function() {
    let t = this;

    // 清理可能存在的旧定时器
    t.clearTimers();

    let timeoutId = setTimeout(function(){
      t.getOrder();
    },1);

    let intervalId = setInterval(function(){
      t.getOrder();
    },5000);

    t.setData({
      timeoutId: timeoutId,
      intervalId: intervalId
    });
  },

  onUnload: function() {
    // 页面卸载时清理定时器
    this.clearTimers();
  },

  onHide: function() {
    // 页面隐藏时也可以清理，防止后台运行
    this.clearTimers();
  },

  onShow: function() {
    // 页面显示时重新启动定时器
    if (this.data.intervalId === null) {
      let t = this;
      let intervalId = setInterval(function() {
        t.getOrder();
      }, 5000);
      this.setData({ intervalId: intervalId });
    }
  },

  clearTimers: function() {
    // 清理timeout
    if (this.data.timeoutId) {
      clearTimeout(this.data.timeoutId);
      this.setData({ timeoutId: null });
    }
    
    // 清理interval
    if (this.data.intervalId) {
      clearInterval(this.data.intervalId);
      this.setData({ intervalId: null });
    }
  },

  getOrder(){
    let t = this;
    u.post(app.globalData.url + 'api/miniprogram/index', {
      'method': 'get_orders_list',
      'status': '1'
    }).then(res => {
      t.setData({
        orders: res.data.data,
        filteredOrders:res.data.data
      });
    });
  },

  gotoOrder(e){
    let cart_id = e.currentTarget.dataset.cart_id;
    wx.navigateTo({
      url: '/pages/orderfood/order?orderId='+cart_id,
    })
  },

  onSearchInput: function(e) {
    this.setData({
      searchKeyword: e.detail.value
    });
    this.filterOrders();
  },

  onSearch: function() {
    this.filterOrders();
  },

  clearSearch: function() {
    this.setData({
      searchKeyword: ''
    });
    this.filterOrders();
  },

  changeFilter: function(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({
      activeFilter: filter
    });
    this.filterOrders();
  },

  filterOrders: function() {
    const { searchKeyword, activeFilter, orders } = this.data;
    
    let filtered = orders.filter(order => {
      // 搜索筛选
      if (searchKeyword && !order.orderNo.includes(searchKeyword)) {
        return false;
      }
      
      return true;
    });
    
    this.setData({
      filteredOrders: filtered
    });
  },

  acceptOrder: function(e) {
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '确认接单',
      content: `确定要接受订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '2'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '接单成功',
                  icon: 'success',
                  duration: 2000
                });
                // 从列表中移除已接单的订单
                const orders = this.data.orders.filter(order => order.orderId !== orderId);
                this.setData({ orders, filteredOrders: orders });
              }
            });
          }, 500);
        }
      }
    });
  },

  confirmPayment: function(e) {
    let t = this;
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    const method = e.currentTarget.dataset.method;
    const amount = e.currentTarget.dataset.amount;
    // 解析金额，确保是数字格式
    const amountNum = parseFloat(amount) || 0;

    if(method == 1){
      //扫码支付
      wx.showModal({
        title: '确认支付',
        content: '请确认顾客已完成支付',
        success: (res) => {
          if (res.confirm) {
            setTimeout(() => {
              u.post(app.globalData.url + 'api/miniprogram/index', {
                'method': 'update_order_info',
                'id': orderId,
                'ordersn': orderSn,
                'paymethod': method,
                'status': '1'
              }).then(res => {
                if(res.data.code==0){
                  wx.showToast({
                    title: '支付已确认',
                    icon: 'success',
                    duration: 2000
                  });
                  // t.getOrder();
                }
              });
            }, 500);
          }
        }
      });
    }
    else if(method == 2){
      //现金支付
      t.setData({
        showPaymentModal: true,
        autoFocusIncome: true,
        currentPayment: {
          orderId: orderId,
          orderSn: orderSn,
          amount: amountNum.toFixed(2),
          income: '',
          change: '0.00'
        }
      });
    }
  },

  // 应收金额输入处理
  onAmountDueInput: function(e) {
    const value = e.detail.value;
    const income = parseFloat(this.data.currentPayment.income) || 0;
    const amountDue = parseFloat(value) || 0;
    const change = income - amountDue;
    
    this.setData({
      'currentPayment.amount': value,
      'currentPayment.change': change.toFixed(2)
    });
  },

  // 实收金额输入处理
  onIncomeInput: function(e) {
    const value = e.detail.value;
    const amountDue = parseFloat(this.data.currentPayment.amount) || 0;
    const income = parseFloat(value) || 0;
    const change = income - amountDue;
    
    this.setData({
      'currentPayment.income': value,
      'currentPayment.change': change.toFixed(2)
    });
  },

  // 确认支付提交
  confirmPaymentSubmit: function() {
    let t = this;
    const { orderId, orderSn, amount, income, change } = t.data.currentPayment;
    
    // 验证输入
    if (!income || parseFloat(income) <= 0) {
      wx.showToast({
        title: '请输入实收金额',
        icon: 'none'
      });
      return;
    }
    
    const incomeNum = parseFloat(income);
    const amountNum = parseFloat(amount);
    
    // 如果有欠款（找零为负），提示确认
    if (incomeNum < amountNum) {
      wx.showModal({
        title: '确认支付',
        content: `实收金额少于应收金额，差额为 ¥${(amountNum - incomeNum).toFixed(2)}，是否继续？`,
        success: (res) => {
          if (res.confirm) {
            t.submitPayment();
          }
        }
      });
    } else {
      t.submitPayment();
    }
  },

  // 提交支付到后端
  submitPayment: function() {
    let t = this;
    const { orderId, orderSn, amount, income, change } = t.data.currentPayment;
    
    wx.showLoading({
      title: '处理中...',
      mask: true
    });
    
    setTimeout(() => {
      u.post(app.globalData.url + 'api/miniprogram/index', {
        'method': 'update_order_info',
        'id': orderId,
        'ordersn': orderSn,
        'paymethod': 2,
        'status': '1',
        'amount_due': amount,
        'income': income,
        'change': change
      }).then(res => {
        wx.hideLoading();
        
        if(res.data.code == 0){
          wx.showToast({
            title: '收款已确认',
            icon: 'success',
            duration: 2000
          });
          
          // 关闭弹窗并刷新订单列表
          t.hidePaymentModal();
          t.getOrder();
        } else {
          wx.showToast({
            title: res.data.msg || '操作失败',
            icon: 'error',
            duration: 2000
          });
        }
      }).catch(err => {
        wx.hideLoading();
        wx.showToast({
          title: '网络错误',
          icon: 'error',
          duration: 2000
        });
      });
    }, 300);
  },

  // 隐藏支付确认弹窗
  hidePaymentModal: function() {
    this.setData({
      showPaymentModal: false,
      autoFocusIncome: false
    });
  },

  rejectOrder: function(e) {
    const orderId = e.currentTarget.dataset.id;
    const orderSn = e.currentTarget.dataset.ordersn;
    wx.showModal({
      title: '拒绝订单',
      content: `确定要拒绝订单 ${orderSn} 吗？`,
      success: (res) => {
        if (res.confirm) {
          // 在实际应用中，这里应该调用API更新订单状态
          setTimeout(() => {
            u.post(app.globalData.url + 'api/miniprogram/index', {
              'method': 'update_order_info',
              'id': orderId,
              'ordersn': orderSn,
              'status': '-1'
            }).then(res => {
              if(res.data.code==0){
                wx.showToast({
                  title: '订单已拒绝',
                  icon: 'success',
                  duration: 2000
                });
              }
            });
            const orders = this.data.orders.filter(order => order.orderId !== orderId);
            this.setData({ orders, filteredOrders: orders });
          }, 500);
        }
      }
    });
  }
});